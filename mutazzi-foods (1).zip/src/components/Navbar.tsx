import React, { useState } from 'react';
import { ShoppingBag, Search, Clock, Menu as MenuIcon, X, Globe, Dumbbell, LogOut, User as UserIcon, Heart, ShieldCheck, Crown } from 'lucide-react';
import { User } from 'firebase/auth';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenOrders: () => void;
  searchTerm: string;
  onSearchChange: (value: string) => void;
  lang: 'bn' | 'en';
  onToggleLang: () => void;
  ordersCount: number;
  currentUser: User | null;
  onLoginWithGoogle: () => void;
  onLogout: () => void;
  isAuthLoading?: boolean;
  favoritesCount: number;
  onOpenFavorites: () => void;
  isAdmin?: boolean;
  onOpenAdmin?: () => void;
  settings?: {
    parbatipurDelivery: number;
    outsideDelivery: number;
    freeDeliveryThreshold: number;
    bundleDiscountPct: number;
    bannerNoticeBn?: string;
    bannerNoticeEn?: string;
  };
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  onOpenCart,
  onOpenOrders,
  searchTerm,
  onSearchChange,
  lang,
  onToggleLang,
  ordersCount,
  currentUser,
  onLoginWithGoogle,
  onLogout,
  isAuthLoading,
  favoritesCount,
  onOpenFavorites,
  isAdmin,
  onOpenAdmin,
  settings,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSearchInput, setShowSearchInput] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const parbatipurFee = settings?.parbatipurDelivery ?? 100;
  const outsideFee = settings?.outsideDelivery ?? 120;
  const freeThreshold = settings?.freeDeliveryThreshold ?? 1500;
  const discountPct = settings?.bundleDiscountPct ?? 10;

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#EAE4D9] transition-all">
      {/* Top Banner Notice */}
      <div className="bg-[#2D160C] text-[#FAF8F5] text-xs py-1.5 px-4 text-center font-medium flex items-center justify-center gap-2">
        <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#EA580C]" />
        <span>
          {lang === 'bn'
            ? (settings?.bannerNoticeBn || `🚚 পার্বতীপুর (${parbatipurFee}৳) ও সারাদেশে (${outsideFee}৳) ১-৭ দিনে হোম ডেলিভারি · ${freeThreshold}৳+ অর্ডারে ফ্রি!`)
            : (settings?.bannerNoticeEn || `🚚 Delivery within 1-7 Days: Parbatipur ৳${parbatipurFee} · Outside ৳${outsideFee} · Free over ৳${freeThreshold}!`)}
        </span>
        <span className="hidden sm:inline text-xs text-[#EA580C] font-semibold">
          {lang === 'bn' ? `· ৩+ আইটেমে ${discountPct}% ছাড়` : `· ${discountPct}% Off on 3+ Items`}
        </span>
      </div>

      {/* Main Top Bar Contract: 3-Zone Layout */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        
        {/* Zone 1: Brand Wordmark & Logo */}
        <div className="flex items-center gap-3">
          <a href="#" className="flex items-center gap-3 group">
            <div className="w-12 h-12 rounded-xl bg-white border border-[#E8DFD3] shadow-sm flex items-center justify-center overflow-hidden p-1 transition-transform group-hover:scale-105">
              <img
                src="/assets/aistudio/IMG_20261027_161503_c549d1c8.png"
                alt="Mutazzi Foods Logo"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div className="flex flex-col">
              <span className="font-heading font-extrabold text-xl sm:text-2xl tracking-tight text-[#2D160C] flex items-center gap-1.5">
                Mutazzi
                <span className="text-[#EA580C] font-black text-xs tracking-widest uppercase bg-[#EA580C]/10 px-1.5 py-0.5 rounded">
                  Foods
                </span>
              </span>
              <span className="text-[10px] text-[#786154] font-medium tracking-wide">
                {lang === 'bn' ? 'শক্তি ও ১০০% অর্গানিক পুষ্টি' : 'Power & Pure Nutrition'}
              </span>
            </div>
          </a>
        </div>

        {/* Zone 2: Navigation Links (Desktop) */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-semibold text-[#4A3326]">
          <a href="#menu" className="hover:text-[#EA580C] transition-colors whitespace-nowrap">
            {lang === 'bn' ? 'মেনু ও পণ্য' : 'Menu & Catalog'}
          </a>
          <button
            onClick={onOpenFavorites}
            className="hover:text-[#EA580C] transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
          >
            <Heart className={`w-4 h-4 ${favoritesCount > 0 ? 'fill-[#DC2626] text-[#DC2626]' : 'text-[#786154]'}`} />
            <span>{lang === 'bn' ? 'আমার পছন্দ' : 'Favorites'}</span>
            {favoritesCount > 0 && (
              <span className="text-xs bg-red-100 text-red-700 px-1.5 py-0.2 rounded-full font-bold">
                {favoritesCount}
              </span>
            )}
          </button>
          <a href="#calculator" className="hover:text-[#EA580C] transition-colors whitespace-nowrap flex items-center gap-1">
            <Dumbbell className="w-4 h-4 text-[#EA580C]" />
            {lang === 'bn' ? 'ম্যাক্রো ক্যালকুলেটর' : 'Macro Calculator'}
          </a>
          <a href="#story" className="hover:text-[#EA580C] transition-colors whitespace-nowrap">
            {lang === 'bn' ? 'ব্র্যান্ড গল্প' : 'Brand Story'}
          </a>
          <button
            onClick={onOpenOrders}
            className="hover:text-[#EA580C] transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
          >
            <Clock className="w-4 h-4 text-[#786154]" />
            <span>{lang === 'bn' ? 'আমার অর্ডার' : 'My Orders'}</span>
            {ordersCount > 0 && (
              <span className="text-xs bg-[#2D160C] text-white px-1.5 py-0.2 rounded-full font-bold">
                {ordersCount}
              </span>
            )}
          </button>

          {/* Super Admin Trigger for mdlabiburrahman26@gmail.com */}
          {isAdmin && (
            <button
              onClick={onOpenAdmin}
              className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-600 hover:to-orange-700 text-white font-extrabold text-xs px-3 py-1.5 rounded-xl shadow-sm hover:shadow flex items-center gap-1.5 transition-all cursor-pointer ring-1 ring-amber-300/50 active:scale-95"
              title="Super Admin Control Panel"
            >
              <Crown className="w-3.5 h-3.5 text-yellow-200 fill-yellow-200" />
              <span>{lang === 'bn' ? 'এডমিন প্যানেল' : 'Admin'}</span>
            </button>
          )}
        </nav>

        {/* Zone 3: Primary Action & Tools */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Search Bar (Collapsible / Inline) */}
          <div className="relative">
            {showSearchInput ? (
              <div className="flex items-center bg-white border border-[#D5C9B8] rounded-lg px-2.5 py-1.5 shadow-sm w-44 sm:w-60 transition-all">
                <Search className="w-4 h-4 text-[#786154] shrink-0" />
                <input
                  type="text"
                  placeholder={lang === 'bn' ? 'পণ্য খুঁজুন...' : 'Search foods...'}
                  value={searchTerm}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="w-full bg-transparent border-none text-xs text-[#2D160C] focus:outline-none px-2"
                  autoFocus
                />
                <button
                  onClick={() => setShowSearchInput(false)}
                  className="text-[#786154] hover:text-[#2D160C] text-xs p-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowSearchInput(true)}
                aria-label="Search"
                className="p-2 text-[#4A3326] hover:text-[#EA580C] hover:bg-[#F2ECE1] rounded-lg transition-colors cursor-pointer"
              >
                <Search className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Language Switcher */}
          <button
            onClick={onToggleLang}
            className="hidden sm:flex items-center gap-1 text-xs font-bold text-[#4A3326] bg-[#F2ECE1] hover:bg-[#E8DFD0] px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer border border-[#E0D5C5]"
            title="Toggle Language"
          >
            <Globe className="w-3.5 h-3.5 text-[#EA580C]" />
            <span>{lang === 'bn' ? 'English' : 'বাংলা'}</span>
          </button>

          {/* Google Login / User Profile Area */}
          <div className="relative">
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="flex items-center gap-1.5 p-1 rounded-full hover:ring-2 hover:ring-[#EA580C]/40 transition cursor-pointer"
                  title={currentUser.displayName || currentUser.email || 'User Account'}
                >
                  {currentUser.photoURL ? (
                    <img
                      src={currentUser.photoURL}
                      alt={currentUser.displayName || 'Profile'}
                      className="w-8 h-8 rounded-full border-2 border-[#16A34A] object-cover shadow-xs"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-[#EA580C] text-white flex items-center justify-center font-bold text-xs shadow-xs">
                      {(currentUser.displayName || currentUser.email || 'U').charAt(0).toUpperCase()}
                    </div>
                  )}
                </button>

                {/* User Dropdown Menu */}
                {showUserDropdown && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-[#EAE4D9] p-3 space-y-2.5 z-50 animate-in fade-in zoom-in-95 duration-150">
                    <div className="border-b border-[#F2ECE1] pb-2">
                      <div className="font-bold text-xs text-[#2D160C] truncate">
                        {currentUser.displayName || 'সম্মানিত গ্রাহক'}
                      </div>
                      <div className="text-[11px] text-[#786154] truncate">
                        {currentUser.email}
                      </div>
                      <div className="text-[10px] text-[#16A34A] font-semibold flex items-center gap-1 mt-0.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#16A34A]" />
                        <span>Google দিয়ে সংযুক্ত</span>
                      </div>
                    </div>

                    {/* Admin Trigger in Dropdown */}
                    {isAdmin && (
                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          onOpenAdmin?.();
                        }}
                        className="w-full text-left text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 p-1.5 rounded-lg flex items-center gap-2 cursor-pointer border border-amber-200"
                      >
                        <Crown className="w-3.5 h-3.5 text-amber-600 fill-amber-600" />
                        <span>{lang === 'bn' ? '👑 এডমিন কন্ট্রোল প্যানেল' : '👑 Super Admin Panel'}</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onOpenOrders();
                      }}
                      className="w-full text-left text-xs font-semibold text-[#4A3326] hover:text-[#EA580C] hover:bg-[#FAF8F5] p-1.5 rounded flex items-center gap-2 cursor-pointer"
                    >
                      <Clock className="w-3.5 h-3.5 text-[#786154]" />
                      <span>{lang === 'bn' ? 'আমার অর্ডারসমূহ' : 'My Orders'}</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onOpenFavorites();
                      }}
                      className="w-full text-left text-xs font-semibold text-[#4A3326] hover:text-[#EA580C] hover:bg-[#FAF8F5] p-1.5 rounded flex items-center justify-between cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <Heart className={`w-3.5 h-3.5 ${favoritesCount > 0 ? 'fill-[#DC2626] text-[#DC2626]' : 'text-[#786154]'}`} />
                        <span>{lang === 'bn' ? 'আমার পছন্দের তালিকা' : 'My Favorites'}</span>
                      </span>
                      {favoritesCount > 0 && (
                        <span className="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.2 rounded-full font-bold">
                          {favoritesCount}
                        </span>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onLogout();
                      }}
                      className="w-full text-left text-xs font-semibold text-red-600 hover:bg-red-50 p-1.5 rounded flex items-center gap-2 cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>{lang === 'bn' ? 'লগআউট করুন' : 'Log Out'}</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onLoginWithGoogle}
                disabled={isAuthLoading}
                className="hidden sm:flex items-center gap-1.5 bg-white hover:bg-[#F5EFE6] text-[#2D160C] border border-[#D5C9B8] px-3 py-1.5 rounded-xl font-bold text-xs shadow-xs transition-all cursor-pointer"
                title={lang === 'bn' ? 'গুগল দিয়ে লগইন করুন' : 'Sign in with Google'}
              >
                {/* Clean Google G Icon */}
                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>{lang === 'bn' ? 'গুগল লগইন' : 'Google Login'}</span>
              </button>
            )}
          </div>

          {/* Cart Primary CTA */}
          <button
            onClick={onOpenCart}
            className="flex items-center gap-2 bg-[#EA580C] hover:bg-[#C2410C] active:scale-95 text-white px-3 sm:px-4 py-2 rounded-xl font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer whitespace-nowrap"
          >
            <ShoppingBag className="w-4 h-4 text-[#FFF2E8]" />
            <span className="hidden sm:inline">{lang === 'bn' ? 'কার্ট' : 'Cart'}</span>
            <span className="bg-white text-[#EA580C] text-xs font-black rounded-full px-2 py-0.5 shadow-sm">
              {cartCount}
            </span>
          </button>

          {/* 3-Line Menu Button (Visible on all devices: Mobile, Tablet & Desktop) */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="bg-[#FAF8F5] hover:bg-[#F2ECE1] active:scale-95 border border-[#D5C9B8] p-2 text-[#2D160C] rounded-xl cursor-pointer shadow-xs flex items-center justify-center shrink-0 transition-all"
            aria-label="Toggle menu"
            title={lang === 'bn' ? 'মেনু খুলুন' : 'Open Menu'}
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5 text-[#EA580C]" />
            ) : (
              <div className="w-5 h-5 flex flex-col justify-center items-center gap-1">
                <span className="w-4.5 h-0.5 bg-[#2D160C] rounded-full" />
                <span className="w-4.5 h-0.5 bg-[#2D160C] rounded-full" />
                <span className="w-4.5 h-0.5 bg-[#2D160C] rounded-full" />
              </div>
            )}
          </button>
        </div>
      </div>

      {/* Navigation Drawer Dropdown (Accessible on all screen sizes) */}
      {mobileMenuOpen && (
        <div className="bg-[#FAF8F5] border-b border-[#EAE4D9] px-4 sm:px-6 lg:px-8 pt-3 pb-5 space-y-3 shadow-xl animate-in slide-in-from-top duration-200">
          
          {/* User Auth Info Row on Mobile */}
          <div className="flex items-center justify-between pb-2 border-b border-[#EAE4D9]">
            {currentUser ? (
              <div className="flex items-center gap-2">
                {currentUser.photoURL ? (
                  <img src={currentUser.photoURL} className="w-7 h-7 rounded-full border border-[#16A34A]" />
                ) : (
                  <UserIcon className="w-6 h-6 text-[#786154]" />
                )}
                <div>
                  <div className="text-xs font-bold text-[#2D160C] leading-none">
                    {currentUser.displayName || 'User'}
                  </div>
                  <button onClick={onLogout} className="text-[10px] text-red-600 font-semibold underline mt-0.5">
                    {lang === 'bn' ? 'লগআউট' : 'Log Out'}
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onLoginWithGoogle();
                }}
                className="flex items-center gap-1.5 bg-white border border-[#D5C9B8] px-2.5 py-1 rounded-lg text-xs font-bold text-[#2D160C] shadow-xs"
              >
                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>{lang === 'bn' ? 'গুগল দিয়ে লগইন' : 'Google Login'}</span>
              </button>
            )}

            <button
              onClick={onToggleLang}
              className="flex items-center gap-1 text-xs font-bold text-[#2D160C] bg-[#F2ECE1] px-2 py-1 rounded border border-[#E0D5C5]"
            >
              <Globe className="w-3 h-3 text-[#EA580C]" />
              <span>{lang === 'bn' ? 'English' : 'বাংলা'}</span>
            </button>
          </div>

          <div className="flex flex-col gap-2.5 text-sm font-semibold text-[#4A3326]">
            {/* Super Admin Mobile Button */}
            {isAdmin && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAdmin?.();
                }}
                className="text-left px-2.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white font-extrabold flex items-center justify-between cursor-pointer shadow-sm"
              >
                <span className="flex items-center gap-2">
                  <Crown className="w-4 h-4 text-yellow-200 fill-yellow-200" />
                  <span>{lang === 'bn' ? 'এডমিন কন্ট্রোল প্যানেল' : 'Super Admin Panel'}</span>
                </span>
                <span className="bg-white/20 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">
                  ADMIN
                </span>
              </button>
            )}

            <a
              href="#menu"
              onClick={() => setMobileMenuOpen(false)}
              className="px-2 py-1.5 rounded hover:bg-[#F2ECE1] hover:text-[#EA580C]"
            >
              {lang === 'bn' ? '🥗 মেনু ও পণ্য তালিকা' : '🥗 Menu & Food Catalog'}
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenFavorites();
              }}
              className="text-left px-2 py-1.5 rounded hover:bg-[#F2ECE1] hover:text-[#EA580C] flex items-center justify-between cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Heart className={`w-4 h-4 ${favoritesCount > 0 ? 'fill-[#DC2626] text-[#DC2626]' : 'text-[#786154]'}`} />
                <span>{lang === 'bn' ? 'আমার পছন্দের তালিকা' : 'My Favorites'}</span>
              </span>
              {favoritesCount > 0 && (
                <span className="bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded-full font-bold">
                  {favoritesCount}
                </span>
              )}
            </button>
            <a
              href="#calculator"
              onClick={() => setMobileMenuOpen(false)}
              className="px-2 py-1.5 rounded hover:bg-[#F2ECE1] hover:text-[#EA580C] flex items-center gap-2"
            >
              <Dumbbell className="w-4 h-4 text-[#EA580C]" />
              {lang === 'bn' ? 'ম্যাক্রো ও প্রোটিন ক্যালকুলেটর' : 'Macro & Protein Calculator'}
            </a>
            <a
              href="#story"
              onClick={() => setMobileMenuOpen(false)}
              className="px-2 py-1.5 rounded hover:bg-[#F2ECE1] hover:text-[#EA580C]"
            >
              {lang === 'bn' ? '🌾 ব্র্যান্ড ও লোগো পরিচিতি' : '🌾 Brand & Logo Philosophy'}
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenOrders();
              }}
              className="text-left px-2 py-1.5 rounded hover:bg-[#F2ECE1] hover:text-[#EA580C] flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#786154]" />
                {lang === 'bn' ? 'আমার অর্ডার হিস্টোরি' : 'My Orders'}
              </span>
              {ordersCount > 0 && (
                <span className="bg-[#2D160C] text-white text-xs px-2 py-0.5 rounded-full font-bold">
                  {ordersCount}
                </span>
              )}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
