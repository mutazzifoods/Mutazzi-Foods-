import React, { useState } from 'react';
import { Dumbbell, Flame, Check, Plus, Sparkles, Activity } from 'lucide-react';
import { Product } from '../types';

interface MacroCalculatorProps {
  products: Product[];
  onAddBundleToCart: (products: Product[]) => void;
  lang: 'bn' | 'en';
}

export const MacroCalculator: React.FC<MacroCalculatorProps> = ({
  products,
  onAddBundleToCart,
  lang,
}) => {
  const [weightKg, setWeightKg] = useState<number>(68);
  const [goal, setGoal] = useState<'muscle' | 'fatloss' | 'vitality'>('muscle');
  const [activity, setActivity] = useState<'moderate' | 'high'>('moderate');
  const [bundleAdded, setBundleAdded] = useState(false);

  // Protein calculation:
  // Muscle Gain: ~1.8g to 2.0g per kg
  // Fat Loss: ~1.6g to 1.8g per kg (high protein to preserve muscle)
  // Vitality: ~1.2g to 1.4g per kg
  const proteinMultiplier = goal === 'muscle' ? 2.0 : goal === 'fatloss' ? 1.7 : 1.3;
  const targetProtein = Math.round(weightKg * proteinMultiplier);
  const targetCalories = Math.round(
    weightKg * (activity === 'high' ? 33 : 28) * (goal === 'muscle' ? 1.15 : goal === 'fatloss' ? 0.85 : 1.0)
  );

  // Recommended Mutazzi Combo: Bowl + Butter/Granola + Drink
  const recommendedItems = products.slice(0, 3);
  const totalBundleProtein = recommendedItems.reduce((acc, item) => acc + item.protein, 0);
  const totalBundlePrice = recommendedItems.reduce((acc, item) => acc + item.price, 0);

  const handleAddBundle = () => {
    onAddBundleToCart(recommendedItems);
    setBundleAdded(true);
    setTimeout(() => setBundleAdded(false), 2500);
  };

  return (
    <section id="calculator" className="py-12 bg-white border-y border-[#EAE4D9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-[#EA580C] uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>{lang === 'bn' ? 'স্মার্ট ফিটনেস নিউট্রিশন' : 'Smart Fitness Nutrition'}</span>
          </div>
          <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-[#2D160C]">
            {lang === 'bn' ? 'আপনার ব্যক্তিগত ম্যাক্রো ও প্রোটিন ক্যালকুলেটর' : 'Interactive Daily Macro & Protein Calculator'}
          </h2>
          <p className="text-xs sm:text-sm text-[#786154] leading-relaxed">
            {lang === 'bn'
              ? 'আপনার ওজন ও ফিটনেস লক্ষ্য অনুযায়ী দৈনিক প্রয়োজনীয় প্রোটিন ও ক্যালোরি জেনে নিন এবং মুতাযযির পারফেক্ট মিল বেছে নিন।'
              : 'Calculate your exact daily protein needs based on your body weight and training targets, then get the chef-crafted Mutazzi meal combo.'}
          </p>
        </div>

        {/* 2-Column Responsive Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Controls Left Column (7 cols) */}
          <div className="lg:col-span-7 bg-[#FAF8F5] rounded-2xl p-5 sm:p-6 border border-[#EAE4D9] space-y-5">
            
            {/* Weight Slider */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm font-bold text-[#2D160C]">
                <span>{lang === 'bn' ? 'আপনার বর্তমান ওজন (কেজি)' : 'Current Body Weight'}</span>
                <span className="font-heading font-extrabold text-lg text-[#EA580C] font-mono tabular-nums">
                  {weightKg} kg
                </span>
              </div>
              <input
                type="range"
                min="45"
                max="120"
                step="1"
                value={weightKg}
                onChange={(e) => setWeightKg(Number(e.target.value))}
                className="w-full accent-[#EA580C] cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-[#8A7669] font-mono">
                <span>45 kg</span>
                <span>80 kg</span>
                <span>120 kg</span>
              </div>
            </div>

            {/* Fitness Goal Segmented Buttons */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-[#2D160C]">
                {lang === 'bn' ? 'ফিটনেস লক্ষ্য নির্বাচন করুন' : 'Select Primary Fitness Goal'}
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setGoal('muscle')}
                  className={`p-3 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center gap-1.5 cursor-pointer ${
                    goal === 'muscle'
                      ? 'bg-white border-[#EA580C] text-[#EA580C] shadow-sm ring-1 ring-[#EA580C]'
                      : 'bg-white/60 border-[#D5C9B8] text-[#5C4537] hover:bg-white'
                  }`}
                >
                  <Dumbbell className="w-4 h-4" />
                  <span>{lang === 'bn' ? 'মাসল গেইন' : 'Muscle Gain'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setGoal('fatloss')}
                  className={`p-3 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center gap-1.5 cursor-pointer ${
                    goal === 'fatloss'
                      ? 'bg-white border-[#EA580C] text-[#EA580C] shadow-sm ring-1 ring-[#EA580C]'
                      : 'bg-white/60 border-[#D5C9B8] text-[#5C4537] hover:bg-white'
                  }`}
                >
                  <Flame className="w-4 h-4" />
                  <span>{lang === 'bn' ? 'ফ্যাট লস ও শ্রেন্ড' : 'Fat Loss / Shred'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setGoal('vitality')}
                  className={`p-3 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center gap-1.5 cursor-pointer ${
                    goal === 'vitality'
                      ? 'bg-white border-[#EA580C] text-[#EA580C] shadow-sm ring-1 ring-[#EA580C]'
                      : 'bg-white/60 border-[#D5C9B8] text-[#5C4537] hover:bg-white'
                  }`}
                >
                  <Activity className="w-4 h-4" />
                  <span>{lang === 'bn' ? 'ক্লিন এনার্জি' : 'Clean Energy'}</span>
                </button>
              </div>
            </div>

            {/* Activity Level */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-[#2D160C]">
                {lang === 'bn' ? 'শারীরিক পরিশ্রমের মাত্রা' : 'Weekly Activity Level'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setActivity('moderate')}
                  className={`p-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                    activity === 'moderate'
                      ? 'bg-white border-[#2D160C] text-[#2D160C] shadow-xs'
                      : 'bg-white/60 border-[#D5C9B8] text-[#5C4537]'
                  }`}
                >
                  {lang === 'bn' ? 'মাঝারি (সপ্তাহে ৩-৪ দিন ওয়ার্কআউট)' : 'Moderate (3-4 Days Active)'}
                </button>

                <button
                  type="button"
                  onClick={() => setActivity('high')}
                  className={`p-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                    activity === 'high'
                      ? 'bg-white border-[#2D160C] text-[#2D160C] shadow-xs'
                      : 'bg-white/60 border-[#D5C9B8] text-[#5C4537]'
                  }`}
                >
                  {lang === 'bn' ? 'উচ্চ (সপ্তাহে ৫-৬ দিন কঠোর প্রশিক্ষণ)' : 'High (5-6 Days Intense)'}
                </button>
              </div>
            </div>

            {/* Calculated Target Results Box */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="bg-white p-3.5 rounded-xl border border-[#EAE4D9] text-center shadow-xs">
                <div className="text-[11px] font-semibold text-[#786154] uppercase tracking-wider">
                  {lang === 'bn' ? 'দৈনিক লক্ষ্য প্রোটিন' : 'Target Daily Protein'}
                </div>
                <div className="font-heading font-black text-2xl sm:text-3xl text-[#EA580C] mt-1 tabular-nums font-mono">
                  {targetProtein}g
                </div>
                <div className="text-[10px] text-[#8A7669]">
                  {lang === 'bn' ? `প্রতি কেজিতে ${proteinMultiplier}g প্রোটিন` : `${proteinMultiplier}g per kg bodyweight`}
                </div>
              </div>

              <div className="bg-white p-3.5 rounded-xl border border-[#EAE4D9] text-center shadow-xs">
                <div className="text-[11px] font-semibold text-[#786154] uppercase tracking-wider">
                  {lang === 'bn' ? 'দৈনিক ক্যালোরি বাজেট' : 'Estimated Calories'}
                </div>
                <div className="font-heading font-black text-2xl sm:text-3xl text-[#2D160C] mt-1 tabular-nums font-mono">
                  {targetCalories}
                </div>
                <div className="text-[10px] text-[#8A7669]">
                  {lang === 'bn' ? 'সুষম স্বাস্থ্যকর শক্তি' : 'Balanced energy budget'}
                </div>
              </div>
            </div>

          </div>

          {/* Recommended Meal Pack Right Column (5 cols) */}
          <div className="lg:col-span-5 bg-gradient-to-br from-[#2D160C] to-[#451A03] text-white rounded-2xl p-6 shadow-xl space-y-4">
            
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#FB923C]">
                  {lang === 'bn' ? 'মুতাযযি রিকমেন্ডেড বান্ডেল' : 'Mutazzi Power Pack'}
                </span>
                <h3 className="font-heading font-bold text-lg text-white">
                  {lang === 'bn' ? 'দৈনিক প্রোটিন কম্বো মিল' : 'Daily High-Protein Trio'}
                </h3>
              </div>
              <div className="text-right">
                <div className="text-xs text-white/70">{lang === 'bn' ? 'প্রোটিন সাপোর্ট' : 'Delivers'}</div>
                <div className="font-mono font-black text-base text-[#FB923C]">{totalBundleProtein}g P</div>
              </div>
            </div>

            {/* Pack Items Preview */}
            <div className="space-y-2.5">
              {recommendedItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-white/10 rounded-xl p-2.5 flex items-center justify-between gap-3 text-xs border border-white/10"
                >
                  <div className="flex items-center gap-2.5">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-10 h-10 rounded-lg object-cover bg-black/20"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="font-bold text-white line-clamp-1">
                        {lang === 'bn' ? item.nameBn : item.name}
                      </div>
                      <div className="text-[11px] text-[#FB923C] font-mono">
                        {item.protein}g Protein · {item.calories} kcal
                      </div>
                    </div>
                  </div>
                  <div className="font-mono font-bold text-white tabular-nums">
                    ৳{item.price}
                  </div>
                </div>
              ))}
            </div>

            {/* Total Pricing & One-Click Add */}
            <div className="pt-2 border-t border-white/10 space-y-3">
              <div className="flex justify-between items-center text-sm">
                <span className="text-white/80">{lang === 'bn' ? 'বান্ডেল মূল্য:' : 'Bundle Total:'}</span>
                <span className="font-heading font-black text-xl text-[#FB923C] font-mono tabular-nums">
                  ৳{totalBundlePrice}
                </span>
              </div>

              <button
                onClick={handleAddBundle}
                className="w-full bg-[#EA580C] hover:bg-[#F97316] text-white font-bold py-3 px-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm"
              >
                {bundleAdded ? (
                  <>
                    <Check className="w-4 h-4 text-white" />
                    <span>{lang === 'bn' ? 'কার্টে যোগ করা হয়েছে!' : 'Pack Added to Cart!'}</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span>
                      {lang === 'bn' ? '৩টি পণ্য একসাথে কার্টে যোগ করুন' : 'Add 3-Item Pack to Cart'}
                    </span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
