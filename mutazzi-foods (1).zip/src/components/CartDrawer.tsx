import React, { useState, useMemo, useEffect } from 'react';
import { CartItem, Order } from '../types';
import { DISTRICTS, THANAS, POPULAR_VILLAGES } from '../data/locations';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, ShieldCheck, Tag, CheckCircle2, MapPin, Truck, UserCheck } from 'lucide-react';
import { User } from 'firebase/auth';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQty: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onOrderSuccess: (order: Order) => void;
  lang: 'bn' | 'en';
  currentUser?: User | null;
  onLoginWithGoogle?: () => void;
  settings?: {
    parbatipurDelivery: number;
    outsideDelivery: number;
    freeDeliveryThreshold: number;
    bundleDiscountPct: number;
  };
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
  onOrderSuccess,
  lang,
  currentUser,
  onLoginWithGoogle,
  settings,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  
  // Cascading Location States: জেলা -> থানা -> গ্রাম / এলাকা -> বিস্তারিত ঠিকানা
  const [selectedDistrict, setSelectedDistrict] = useState<string>('dinajpur');
  const [selectedThana, setSelectedThana] = useState<string>('parbatipur');
  const [selectedVillage, setSelectedVillage] = useState<string>('');
  const [customVillageDetails, setCustomVillageDetails] = useState<string>('');
  
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bkash' | 'nagad'>('cod');
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Auto-fill customer name if logged in with Google
  useEffect(() => {
    if (currentUser?.displayName && !name) {
      setName(currentUser.displayName);
    }
  }, [currentUser]);

  // Available thanas based on selected district
  const availableThanas = useMemo(() => {
    const list = THANAS.filter((t) => t.districtId === selectedDistrict);
    return list.length > 0
      ? list
      : [{ id: 'generic_' + selectedDistrict, districtId: selectedDistrict, name: 'Sadar / Local Thana', nameBn: 'সদর / স্থানীয় থানা', deliveryFee: 120 }];
  }, [selectedDistrict]);

  // Available popular villages / bazaars for selected thana
  const availableVillages = useMemo(() => {
    return POPULAR_VILLAGES[selectedThana] || [
      'সদর বাজার / প্রধান সড়ক',
      'কলেজ রোড / স্টেশন এলাকা',
      'অন্যান্য গ্রাম / বাজার (নিচে লিখুন)',
    ];
  }, [selectedThana]);

  // Handle District Change
  const handleDistrictChange = (districtId: string) => {
    setSelectedDistrict(districtId);
    const firstThana = THANAS.find((t) => t.districtId === districtId);
    const newThanaId = firstThana ? firstThana.id : 'generic_' + districtId;
    setSelectedThana(newThanaId);
    setSelectedVillage('');
  };

  // Handle Thana Change
  const handleThanaChange = (thanaId: string) => {
    setSelectedThana(thanaId);
    setSelectedVillage('');
  };

  const totalItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  
  // Bundle discount from settings or default 10%
  const discountRate = (settings?.bundleDiscountPct ?? 10) / 100;
  const discount = totalItemsCount >= 3 ? Math.round(subtotal * discountRate) : 0;
  
  // Delivery Fee Calculation from dynamic settings:
  const isParbatipur = selectedThana === 'parbatipur';
  const parbatipurFee = settings?.parbatipurDelivery ?? 100;
  const outsideFee = settings?.outsideDelivery ?? 120;
  const freeThreshold = settings?.freeDeliveryThreshold ?? 1500;

  const baseDeliveryFee = isParbatipur ? parbatipurFee : outsideFee;
  const isFreeDelivery = totalItemsCount > 0 && (subtotal - discount) >= freeThreshold;
  const deliveryFee = totalItemsCount === 0 ? 0 : (isFreeDelivery ? 0 : baseDeliveryFee);
  
  const grandTotal = Math.max(0, subtotal - discount + deliveryFee);

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (cart.length === 0) {
      setErrorMessage(lang === 'bn' ? 'আপনার কার্ট খালি রয়েছে!' : 'Your cart is empty!');
      return;
    }

    if (!name.trim()) {
      setErrorMessage(lang === 'bn' ? 'অনুগ্রহ করে আপনার পুরো নাম লিখুন।' : 'Please enter your full name.');
      return;
    }

    if (!phone.trim() || phone.trim().length < 11) {
      setErrorMessage(lang === 'bn' ? 'সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 017xxxxxxxx)।' : 'Please enter a valid 11-digit phone number.');
      return;
    }

    if (!selectedDistrict) {
      setErrorMessage(lang === 'bn' ? 'দয়া করে জেলা নির্বাচন করুন।' : 'Please select your District.');
      return;
    }

    if (!selectedThana) {
      setErrorMessage(lang === 'bn' ? 'দয়া করে থানা / উপজেলা নির্বাচন করুন।' : 'Please select your Thana / Upazila.');
      return;
    }

    if (!selectedVillage && !customVillageDetails.trim()) {
      setErrorMessage(lang === 'bn' ? 'দয়া করে গ্রাম বা এলাকা নির্বাচন করুন অথবা বিস্তারিত ঠিকানা লিখুন।' : 'Please select a village/area or write your address.');
      return;
    }

    setIsSubmitting(true);

    const currentDistrictObj = DISTRICTS.find((d) => d.id === selectedDistrict);
    const currentThanaObj = THANAS.find((t) => t.id === selectedThana);

    const districtName = lang === 'bn' ? (currentDistrictObj?.nameBn || selectedDistrict) : (currentDistrictObj?.name || selectedDistrict);
    const thanaName = lang === 'bn' ? (currentThanaObj?.nameBn || selectedThana) : (currentThanaObj?.name || selectedThana);

    const fullAddressText = [
      selectedVillage && selectedVillage !== 'অন্যান্য গ্রাম / বাজার (নিচে লিখুন)' ? selectedVillage : null,
      customVillageDetails.trim() || null,
      `${thanaName}, ${districtName}`,
    ]
      .filter(Boolean)
      .join(', ');

    const orderId = 'MTZ-' + Math.floor(100000 + Math.random() * 900000);
    const newOrder: Order = {
      id: orderId,
      date: new Date().toISOString(),
      customerName: name.trim(),
      phone: phone.trim(),
      address: fullAddressText,
      deliveryZone: isParbatipur
        ? (lang === 'bn' ? 'পার্বতীপুর (১০০৳)' : 'Parbatipur (৳100)')
        : (lang === 'bn' ? 'পার্বতীপুরের বাইরে (১২০৳)' : 'Outside Parbatipur (৳120)'),
      items: [...cart],
      subtotal,
      discount,
      deliveryFee,
      total: grandTotal,
      paymentMethod,
      status: 'Confirmed',
      userId: currentUser ? currentUser.uid : 'guest',
      userEmail: currentUser?.email || 'guest@mutazzifoods.com',
      isGuest: !currentUser,
      estimatedDelivery: '১-৭ কার্যদিবস (1-7 Business Days)',
    };

    setTimeout(() => {
      setIsSubmitting(false);
      onOrderSuccess(newOrder);
      onClearCart();
      onClose();
    }, 600);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div className="bg-[#FAF8F5] w-full max-w-md h-full flex flex-col shadow-2xl border-l border-[#E0D5C5] animate-in slide-in-from-right duration-300">
        
        {/* Drawer Header */}
        <div className="p-4 bg-white border-b border-[#EAE4D9] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#EA580C]" />
            <h2 className="font-heading font-bold text-lg text-[#2D160C]">
              {lang === 'bn' ? 'শপিং কার্ট' : 'Shopping Cart'}
            </h2>
            <span className="text-xs bg-[#F2ECE1] text-[#786154] font-mono px-2 py-0.5 rounded-full font-bold">
              {totalItemsCount}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#786154] hover:text-[#2D160C] hover:bg-[#F2ECE1] rounded-lg transition-colors cursor-pointer"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Guest or Logged In Notice */}
        <div className="bg-white border-b border-[#EAE4D9] px-4 py-2 text-xs flex items-center justify-between">
          {currentUser ? (
            <div className="flex items-center gap-1.5 text-[#16A34A] font-semibold">
              <UserCheck className="w-3.5 h-3.5" />
              <span className="truncate max-w-[240px]">
                {currentUser.displayName || currentUser.email} (লগইন করা আছে)
              </span>
            </div>
          ) : (
            <div className="flex items-center justify-between w-full">
              <span className="text-[#786154] text-[11px]">
                {lang === 'bn' ? 'লগইন ছাড়াই সরাসরি অর্ডার করা যাবে' : 'Guest checkout available'}
              </span>
              {onLoginWithGoogle && (
                <button
                  type="button"
                  onClick={onLoginWithGoogle}
                  className="text-[#EA580C] hover:underline font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                >
                  <svg className="w-3 h-3" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>গুগল লগইন</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Promo Notification */}
        {totalItemsCount < 3 ? (
          <div className="bg-[#FFF4ED] border-b border-[#FDDCC9] px-4 py-2 text-xs text-[#EA580C] font-semibold flex items-center gap-1.5">
            <Tag className="w-3.5 h-3.5 shrink-0" />
            <span>
              {lang === 'bn'
                ? `আর মাত্র ${3 - totalItemsCount}টি পণ্য যোগ করলেই সরাসরি ১০% ডিসকাউন্ট!`
                : `Add ${3 - totalItemsCount} more item(s) to unlock 10% Bundle Discount!`}
            </span>
          </div>
        ) : (
          <div className="bg-[#ECFDF5] border-b border-[#A7F3D0] px-4 py-2 text-xs text-[#065F46] font-semibold flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981] shrink-0" />
            <span>
              {lang === 'bn'
                ? 'অভিনন্দন! আপনি ১০% বান্ডেল ডিসকাউন্ট পেয়েছেন।'
                : 'Congrats! 10% Bundle Discount applied!'}
            </span>
          </div>
        )}

        {/* Delivery Rate Notice Banner */}
        <div className="bg-[#FAF4ED] border-b border-[#EAE0D2] px-4 py-2 text-[11px] text-[#6E4F3B] flex items-center justify-between">
          <span className="flex items-center gap-1 font-semibold">
            <Truck className="w-3.5 h-3.5 text-[#EA580C]" />
            <span>
              {lang === 'bn' ? 'ডেলিভারি ফি:' : 'Delivery Rates:'}{' '}
              <span className="text-[#2D160C] font-bold">পার্বতীপুর ১০০৳</span> ·{' '}
              <span className="text-[#2D160C] font-bold">বাইরে ১২০৳</span>
            </span>
          </span>
          <span className="text-[#16A34A] font-bold">
            {lang === 'bn' ? '১৫০০৳+ অর্ডারে ফ্রি!' : 'Free over ৳1500!'}
          </span>
        </div>

        {/* Unified Scrollable Container for Cart Items & Checkout Form */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 text-[#786154]">
              <div className="w-16 h-16 rounded-full bg-[#F2ECE1] flex items-center justify-center">
                <ShoppingBag className="w-8 h-8 text-[#A8988B]" />
              </div>
              <div className="font-heading font-bold text-base text-[#2D160C]">
                {lang === 'bn' ? 'আপনার কার্ট খালি রয়েছে' : 'Your cart is empty'}
              </div>
              <p className="text-xs text-[#786154] max-w-xs leading-relaxed">
                {lang === 'bn'
                  ? 'পুষ্টিকর হাই-প্রোটিন মিলস ও ফ্রেশ অর্গানিক ফুডস বেছে নিয়ে কার্টে যোগ করুন।'
                  : 'Explore our high-protein power bowls and organic pantry to get started.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-xl p-3 border border-[#EAE4D9] flex items-center gap-3 shadow-xs"
                >
                  <img
                    src={item.image}
                    alt={lang === 'bn' ? item.nameBn : item.name}
                    className="w-16 h-16 rounded-lg object-cover bg-[#F5EFE6] shrink-0"
                    referrerPolicy="no-referrer"
                  />

                  <div className="flex-1 min-w-0">
                    <h4 className="font-heading font-bold text-xs text-[#2D160C] truncate">
                      {lang === 'bn' ? item.nameBn : item.name}
                    </h4>
                    <div className="text-[11px] text-[#786154] font-medium">
                      {item.weight} · <span className="text-[#EA580C] font-semibold">{item.protein}g P</span>
                    </div>
                    <div className="font-heading font-bold text-xs text-[#2D160C] mt-1 tabular-nums">
                      ৳{item.price}
                    </div>
                  </div>

                  {/* Stepper & Remove */}
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-[#9E8B7F] hover:text-[#DC2626] p-1 transition-colors cursor-pointer"
                      title="Remove item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center border border-[#D5C9B8] rounded-md bg-[#FAF8F5]">
                      <button
                        onClick={() => onUpdateQty(item.id, -1)}
                        className="px-1.5 py-0.5 text-xs text-[#4A3326] hover:bg-[#EAE4D9] cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-2 text-xs font-mono font-bold text-[#2D160C] tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQty(item.id, 1)}
                        className="px-1.5 py-0.5 text-xs text-[#4A3326] hover:bg-[#EAE4D9] cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Checkout Form & Financial Summary */}
          {cart.length > 0 && (
            <form
              onSubmit={handleSubmitOrder}
              className="bg-white p-4 rounded-xl border border-[#EAE4D9] space-y-3 text-xs shadow-xs"
            >
            {/* Delivery Inputs */}
            <div className="space-y-2">
              <div className="font-bold text-[#2D160C] text-xs flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#EA580C]" />
                  <span>{lang === 'bn' ? 'ডেলিভারি ঠিকানা ও এলাকা' : 'Delivery Information'}</span>
                </span>
                <span className="text-[10px] text-[#16A34A] font-medium flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  {lang === 'bn' ? 'ক্যাশ অন ডেলিভারি' : 'COD Available'}
                </span>
              </div>

              {/* Name & Phone */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-semibold text-[#786154] mb-0.5">
                    {lang === 'bn' ? 'পূর্ণ নাম *' : 'Full Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={lang === 'bn' ? 'আপনার নাম' : 'Full Name'}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg text-xs bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-semibold text-[#786154] mb-0.5">
                    {lang === 'bn' ? 'মোবাইল নম্বর *' : 'Phone Number *'}
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder={lang === 'bn' ? '০১7xxxxxxxx' : '017xxxxxxxx'}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg text-xs bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                  />
                </div>
              </div>

              {/* 1. জেলা (District) & 2. থানা (Thana) Selectors */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-[#2D160C] mb-0.5">
                    {lang === 'bn' ? '১. জেলা নির্বাচন করুন *' : '1. Select District *'}
                  </label>
                  <select
                    value={selectedDistrict}
                    onChange={(e) => handleDistrictChange(e.target.value)}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg text-xs bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C] font-medium"
                  >
                    {DISTRICTS.map((d) => (
                      <option key={d.id} value={d.id}>
                        {lang === 'bn' ? d.nameBn : d.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-[#2D160C] mb-0.5">
                    {lang === 'bn' ? '২. থানা / উপজেলা *' : '2. Thana / Upazila *'}
                  </label>
                  <select
                    value={selectedThana}
                    onChange={(e) => handleThanaChange(e.target.value)}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg text-xs bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C] font-semibold text-[#2D160C]"
                  >
                    {availableThanas.map((t) => (
                      <option key={t.id} value={t.id}>
                        {lang === 'bn' ? t.nameBn : t.name} ({t.deliveryFee === 100 ? '১০০৳ ফি' : '১২০৳ ফি'})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* 3. গ্রাম / বাজার / এলাকা Selector */}
              <div>
                <label className="block text-[10px] font-bold text-[#2D160C] mb-0.5">
                  {lang === 'bn' ? '৩. গ্রাম / নির্দিষ্ট বাজার / এলাকা *' : '3. Village / Bazar / Area *'}
                </label>
                <select
                  value={selectedVillage}
                  onChange={(e) => setSelectedVillage(e.target.value)}
                  className="w-full p-2 border border-[#D5C9B8] rounded-lg text-xs bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                >
                  <option value="">{lang === 'bn' ? '-- নির্দিষ্ট গ্রাম বা বাজার বেছে নিন --' : '-- Choose Village / Bazar --'}</option>
                  {availableVillages.map((v, i) => (
                    <option key={i} value={v}>
                      {v}
                    </option>
                  ))}
                </select>
              </div>

              {/* 4. বিস্তারিত বাসা / রোড / গ্রাম এর নাম */}
              <div>
                <label className="block text-[10px] font-semibold text-[#786154] mb-0.5">
                  {lang === 'bn' ? '৪. গ্রাম / পাড়া / বাড়ি বা রোডের বিস্তারিত নাম' : '4. House / Street / Village Details'}
                </label>
                <input
                  type="text"
                  placeholder={lang === 'bn' ? 'যেমন: চাকলা বাজার সংলগ্ন, মনমথপুর / বাসা নং...' : 'e.g., Near Station, Chakla Bazar...'}
                  value={customVillageDetails}
                  onChange={(e) => setCustomVillageDetails(e.target.value)}
                  className="w-full p-2 border border-[#D5C9B8] rounded-lg text-xs bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                />
              </div>

              {/* Payment Method */}
              <div>
                <label className="block text-[10px] font-semibold text-[#786154] mb-0.5">
                  {lang === 'bn' ? 'পেমেন্ট পদ্ধতি' : 'Payment Method'}
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="w-full p-2 border border-[#D5C9B8] rounded-lg text-xs bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                >
                  <option value="cod">{lang === 'bn' ? 'ক্যাশ অন ডেলিভারি (Cash on Delivery)' : 'Cash on Delivery'}</option>
                  <option value="bkash">{lang === 'bn' ? 'বিকাশ (bKash Send Money)' : 'bKash'}</option>
                  <option value="nagad">{lang === 'bn' ? 'নগদ (Nagad Send Money)' : 'Nagad'}</option>
                </select>
              </div>

            </div>

            {/* Error notice */}
            {errorMessage && (
              <div className="p-2 bg-red-50 text-red-600 rounded text-[11px] font-medium">
                {errorMessage}
              </div>
            )}

            {/* Pricing Summary */}
            <div className="pt-2 border-t border-[#F2ECE1] space-y-1.5 font-medium text-[#5C4537]">
              <div className="flex justify-between">
                <span>{lang === 'bn' ? 'সাবটোটাল' : 'Subtotal'}</span>
                <span className="font-mono tabular-nums text-[#2D160C]">৳{subtotal}</span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-[#16A34A]">
                  <span>{lang === 'bn' ? 'বান্ডেল ডিসকাউন্ট (১০%)' : 'Bundle Discount (10%)'}</span>
                  <span className="font-mono tabular-nums">-৳{discount}</span>
                </div>
              )}

              <div className="flex justify-between items-center">
                <span>
                  {lang === 'bn' ? 'ডেলিভারি চার্জ:' : 'Delivery Fee:'}{' '}
                  <span className="text-[10px] text-[#786154]">
                    ({isParbatipur ? (lang === 'bn' ? 'পার্বতীপুর' : 'Parbatipur') : (lang === 'bn' ? 'পার্বতীপুরের বাইরে' : 'Outside Parbatipur')})
                  </span>
                </span>
                <span className="font-mono tabular-nums text-[#2D160C]">
                  {deliveryFee === 0 ? (
                    <span className="text-[#16A34A] font-bold">{lang === 'bn' ? 'ফ্রি (৳০)' : 'FREE (৳0)'}</span>
                  ) : (
                    `৳${deliveryFee}`
                  )}
                </span>
              </div>

              <div className="flex justify-between text-base font-extrabold text-[#2D160C] border-t border-[#EAE4D9] pt-1.5">
                <span>{lang === 'bn' ? 'সর্বমোট প্রদেয়' : 'Total Amount'}</span>
                <span className="text-[#EA580C] font-mono tabular-nums">৳{grandTotal}</span>
              </div>
            </div>

            {/* Delivery Timeframe Notice: 1-7 Days */}
            <div className="flex items-center gap-2 p-2 bg-[#EFF6FF] border border-[#DBEAFE] rounded-lg text-[11px] text-[#1E40AF]">
              <Truck className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />
              <span>
                {lang === 'bn'
                  ? 'ডেলিভারি সময়: অর্ডার করার ১ থেকে ৭ দিনের মধ্যে হোম ডেলিভারি পৌঁছে যাবে।'
                  : 'Delivery Time: Arrives within 1 to 7 business days.'}
              </span>
            </div>

            {/* Professional High-Converting Submit Button - Sleek & Compact */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#EA580C] hover:bg-[#C2410C] active:scale-98 disabled:opacity-50 text-white font-bold py-2.5 sm:py-3 px-3.5 rounded-lg sm:rounded-xl shadow-xs hover:shadow transition-all flex items-center justify-between cursor-pointer text-xs sm:text-sm select-none group"
            >
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-white/90" />
                <span>
                  {isSubmitting
                    ? (lang === 'bn' ? 'অর্ডার প্রক্রিয়াধীন...' : 'Processing...')
                    : (lang === 'bn' ? 'অর্ডার নিশ্চিত করুন' : 'Confirm Order')}
                </span>
              </div>
              
              <div className="flex items-center gap-1.5">
                <span className="font-mono bg-black/15 px-2 py-0.5 rounded text-xs sm:text-sm text-white">
                  ৳{grandTotal}
                </span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
              </div>
            </button>
          </form>
        )}

        </div>

      </div>
    </div>
  );
};
