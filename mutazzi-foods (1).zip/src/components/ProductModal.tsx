import React, { useState, useEffect, useMemo } from 'react';
import { Product, Order } from '../types';
import { X, Plus, Minus, ShoppingBag, ShieldCheck, Flame, Star, Send, CheckCircle2, MessageSquare, Heart, Lock, Share2, Copy, Check } from 'lucide-react';
import { User } from 'firebase/auth';

interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  verified?: boolean;
}

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  lang: 'bn' | 'en';
  currentUser?: User | null;
  orders?: Order[];
  onLoginWithGoogle?: () => void;
  isFavorite?: boolean;
  onToggleFavorite?: (productId: string) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
  lang,
  currentUser,
  orders = [],
  onLoginWithGoogle,
  isFavorite,
  onToggleFavorite,
}) => {
  const [qty, setQty] = useState(1);
  const [activeTab, setActiveTab] = useState<'info' | 'reviews'>('info');
  
  // Review form states
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [reviewerName, setReviewerName] = useState<string>('');
  const [reviewComment, setReviewComment] = useState<string>('');
  const [showReviewForm, setShowReviewForm] = useState<boolean>(false);
  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);
  const [copiedShareLink, setCopiedShareLink] = useState(false);

  // User reviews from localStorage (real customer reviews only)
  const [userReviews, setUserReviews] = useState<Review[]>([]);

  // Load reviews whenever product changes
  useEffect(() => {
    if (!product) return;
    try {
      const storageKey = `mutazzi_reviews_${product.id}`;
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        setUserReviews(JSON.parse(saved));
      } else {
        setUserReviews([]);
      }
    } catch {
      setUserReviews([]);
    }
  }, [product?.id]);

  // Pre-fill reviewer name if logged in
  useEffect(() => {
    if (currentUser?.displayName) {
      setReviewerName(currentUser.displayName);
    } else if (currentUser?.email) {
      setReviewerName(currentUser.email.split('@')[0]);
    }
  }, [currentUser]);

  // Reset states when product opens
  useEffect(() => {
    setQty(1);
    setActiveTab('info');
    setShowReviewForm(false);
    setSubmittedMessage(null);
  }, [product?.id]);

  // Check whether current logged-in user has purchased this product
  const hasPurchased = useMemo(() => {
    if (!currentUser || !product || !orders || orders.length === 0) return false;
    return orders.some((order) => {
      const isUserOrder =
        order.userId === currentUser.uid ||
        Boolean(currentUser.email && order.userEmail?.toLowerCase() === currentUser.email.toLowerCase());
      const isNotCancelled = order.status !== 'Cancelled';
      const hasItem = Boolean(order.items && order.items.some((item) => item.id === product.id));
      return isUserOrder && isNotCancelled && hasItem;
    });
  }, [currentUser, product, orders]);

  // Average Rating
  const averageRating = useMemo(() => {
    if (userReviews.length === 0) return null;
    const total = userReviews.reduce((sum, r) => sum + r.rating, 0);
    return (total / userReviews.length).toFixed(1);
  }, [userReviews]);

  if (!product) return null;

  const handleAdd = () => {
    onAddToCart(product, qty);
    onClose();
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      return;
    }
    if (!hasPurchased) {
      return;
    }
    if (!reviewComment.trim()) return;

    const authorName = currentUser.displayName || reviewerName.trim() || (currentUser.email ? currentUser.email.split('@')[0] : 'ক্রেতা');

    const newReview: Review = {
      id: 'rev-' + Date.now(),
      author: authorName,
      rating,
      date: new Date().toISOString().split('T')[0],
      comment: reviewComment.trim(),
      verified: true,
    };

    const updated = [newReview, ...userReviews];
    setUserReviews(updated);

    try {
      localStorage.setItem(`mutazzi_reviews_${product.id}`, JSON.stringify(updated));
    } catch (e) {
      console.warn('Storage error:', e);
    }

    setReviewComment('');
    setShowReviewForm(false);
    setSubmittedMessage(
      lang === 'bn' ? 'ধন্যবাদ! আপনার ভেরিফায়েড রিভিউটি যুক্ত করা হয়েছে।' : 'Thank you! Your verified review has been published.'
    );
    setTimeout(() => setSubmittedMessage(null), 3500);
  };

  const handleShare = async (platform: 'whatsapp' | 'facebook' | 'twitter' | 'native' | 'copy') => {
    if (!product) return;
    const shareUrl = window.location.origin + window.location.pathname + `#product-${product.id}`;
    const title = lang === 'bn' ? product.nameBn : product.name;
    const shareText = lang === 'bn'
      ? `মুতাযযি ফুডস থেকে সুস্বাদু ও পুষ্টিকর "${title}" (৳${product.price}) - ১০০% খাঁটি উপাদান ও হাই-প্রোটিন মিল!`
      : `Check out "${title}" (৳${product.price}) on Mutazzi Foods - High-Protein & 100% Real Nutrition!`;

    if (platform === 'native' && navigator.share) {
      try {
        await navigator.share({
          title,
          text: shareText,
          url: shareUrl,
        });
        return;
      } catch {
        // Fallback to copy if native share cancelled or fails
      }
    }

    if (platform === 'whatsapp') {
      const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + '\n' + shareUrl)}`;
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    } else if (platform === 'facebook') {
      const fbUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
      window.open(fbUrl, '_blank', 'noopener,noreferrer');
    } else if (platform === 'twitter') {
      const twUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
      window.open(twUrl, '_blank', 'noopener,noreferrer');
    } else if (platform === 'copy' || platform === 'native') {
      try {
        await navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
        setCopiedShareLink(true);
        setTimeout(() => setCopiedShareLink(false), 2500);
      } catch (e) {
        console.warn('Clipboard write error', e);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-[#FAF8F5] w-full max-w-2xl rounded-2xl overflow-hidden shadow-2xl border border-[#E0D5C5] max-h-[85vh] flex flex-col my-auto">
        
        {/* Modal Header */}
        <div className="px-5 py-3.5 border-b border-[#EAE4D9] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-white p-0.5 border border-[#E0D5C5] flex items-center justify-center shrink-0">
              <img
                src="/assets/aistudio/IMG_20261027_161503_c549d1c8.png"
                alt="Mutazzi Logo"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#786154]">
              <span className="font-heading font-extrabold text-[#2D160C]">Mutazzi Foods</span>
              <span aria-hidden="true">·</span>
              <span>{lang === 'bn' ? product.categoryLabelBn : product.categoryLabel}</span>
              <span aria-hidden="true">·</span>
              <span>{product.weight}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Tab Switcher: Info vs Reviews */}
            <div className="flex items-center bg-[#F2ECE1] p-1 rounded-lg text-xs font-bold">
              <button
                onClick={() => setActiveTab('info')}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  activeTab === 'info' ? 'bg-white text-[#2D160C] shadow-xs' : 'text-[#786154] hover:text-[#2D160C]'
                }`}
              >
                {lang === 'bn' ? 'পুষ্টি ও বিবরণ' : 'Details & Nutrition'}
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer flex items-center gap-1 ${
                  activeTab === 'reviews' ? 'bg-white text-[#EA580C] shadow-xs' : 'text-[#786154] hover:text-[#2D160C]'
                }`}
              >
                <Star className="w-3 h-3 fill-[#F59E0B] text-[#F59E0B]" />
                <span>{lang === 'bn' ? `রিভিউ (${userReviews.length})` : `Reviews (${userReviews.length})`}</span>
              </button>
            </div>

            {/* Favorite Heart Button */}
            <button
              type="button"
              onClick={() => onToggleFavorite?.(product.id)}
              className={`p-1.5 rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold ${
                isFavorite
                  ? 'bg-red-50 border-red-200 text-red-600'
                  : 'bg-[#FAF8F5] border-[#E0D5C5] text-[#786154] hover:text-red-600'
              }`}
              title={isFavorite ? (lang === 'bn' ? 'পছন্দ থেকে সরান' : 'Remove Favorite') : (lang === 'bn' ? 'পছন্দের তালিকায় রাখুন' : 'Save to Favorites')}
              aria-label="Toggle Favorite"
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-[#DC2626] text-[#DC2626]' : ''}`} />
              <span className="hidden sm:inline">
                {isFavorite ? (lang === 'bn' ? 'পছন্দ' : 'Saved') : (lang === 'bn' ? 'পছন্দ' : 'Favorite')}
              </span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-[#786154] hover:text-[#2D160C] hover:bg-[#F2ECE1] rounded-lg transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1">
          
          {submittedMessage && (
            <div className="bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] p-3 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
              <span>{submittedMessage}</span>
            </div>
          )}

          {activeTab === 'info' ? (
            /* TAB 1: PRODUCT DETAILS & NUTRITION */
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 items-start">
              
              {/* Image (5 cols) */}
              <div className="relative sm:col-span-5 rounded-xl overflow-hidden border border-[#EAE4D9] bg-white group">
                <img
                  src={product.image}
                  alt={lang === 'bn' ? product.nameBn : product.name}
                  className="w-full h-56 sm:h-64 object-cover"
                  referrerPolicy="no-referrer"
                />

                {/* Official Brand Seal Badge over modal photo */}
                <div className="absolute top-2.5 right-2.5 bg-white/95 backdrop-blur-xs rounded-full p-1 shadow-md border border-[#EAE4D9] flex items-center gap-1.5 pr-2.5">
                  <img
                    src="/assets/aistudio/IMG_20261027_161503_c549d1c8.png"
                    alt="Mutazzi Seal"
                    className="w-5 h-5 object-contain rounded-full"
                    referrerPolicy="no-referrer"
                  />
                  <span className="font-heading font-black text-xs text-[#2D160C]">Mutazzi</span>
                </div>
              </div>

              {/* Info (7 cols) */}
              <div className="sm:col-span-7 space-y-3">
                
                {/* Product Brand Seal Tag */}
                <div className="flex items-center gap-2 p-2 bg-[#FAF8F5] rounded-xl border border-[#EAE4D9]">
                  <div className="w-8 h-8 rounded-lg bg-white p-1 border border-[#EAE4D9] shrink-0 flex items-center justify-center">
                    <img
                      src="/assets/aistudio/IMG_20261027_161503_c549d1c8.png"
                      alt="Logo"
                      className="w-full h-full object-contain"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="text-xs">
                    <div className="font-bold text-[#2D160C]">
                      {lang === 'bn' ? 'মুতাযযি ফুডস ১০০% খাঁটি পণ্য' : 'Mutazzi Foods Certified Original'}
                    </div>
                    <div className="text-[10px] text-[#786154]">
                      {lang === 'bn' ? 'অর্গানিক কোয়ালিটি নিশ্চিতকৃত উপাদান' : '100% Quality Inspected Nutrition'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <h2 className="font-heading font-extrabold text-xl text-[#2D160C] leading-snug">
                    {lang === 'bn' ? product.nameBn : product.name}
                  </h2>
                </div>

                {/* Star rating summary clickable to tab */}
                <button
                  type="button"
                  onClick={() => setActiveTab('reviews')}
                  className="flex items-center gap-1.5 text-xs text-[#786154] hover:text-[#EA580C] transition-colors cursor-pointer"
                >
                  <div className="flex items-center text-[#F59E0B]">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-3.5 h-3.5 ${
                          averageRating && star <= Math.round(Number(averageRating))
                            ? 'fill-[#F59E0B] text-[#F59E0B]'
                            : 'text-[#D5C9B8]'
                        }`}
                      />
                    ))}
                  </div>
                  {averageRating ? (
                    <span className="font-mono font-bold text-[#2D160C]">{averageRating}</span>
                  ) : (
                    <span className="font-bold text-[#EA580C] text-[11px]">{lang === 'bn' ? 'নতুন খাদ্য' : 'New'}</span>
                  )}
                  <span className="text-[11px] underline">({userReviews.length} {lang === 'bn' ? 'গ্রাহক রিভিউ' : 'reviews'})</span>
                </button>

                <div className="flex items-baseline gap-2">
                  <span className="font-heading font-black text-2xl text-[#2D160C]">
                    ৳{product.price}
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm text-[#9E8B7F] line-through">
                      ৳{product.originalPrice}
                    </span>
                  )}
                </div>

                <p className="text-xs text-[#5C4537] leading-relaxed">
                  {lang === 'bn' ? product.descriptionBn : product.description}
                </p>

                {/* Nutritional Highlight Grid */}
                <div className="p-3 bg-white rounded-xl border border-[#EAE4D9] space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-[#2D160C] border-b border-[#F2ECE1] pb-1.5">
                    <span className="flex items-center gap-1.5 text-[#EA580C]">
                      <Flame className="w-4 h-4" />
                      {lang === 'bn' ? 'ম্যাক্রো পুষ্টিমান (প্রতি পরিবেশন)' : 'Macro Nutrition Facts'}
                    </span>
                    <span className="font-mono text-[11px] text-[#786154]">{product.weight}</span>
                  </div>

                  <div className="grid grid-cols-4 gap-2 text-center pt-1 font-mono tabular-nums">
                    <div className="p-1.5 bg-[#FAF8F5] rounded-lg">
                      <div className="text-[10px] text-[#786154] uppercase font-sans">Protein</div>
                      <div className="font-extrabold text-sm text-[#EA580C]">{product.protein}g</div>
                    </div>
                    <div className="p-1.5 bg-[#FAF8F5] rounded-lg">
                      <div className="text-[10px] text-[#786154] uppercase font-sans">Calories</div>
                      <div className="font-extrabold text-sm text-[#2D160C]">{product.calories}</div>
                    </div>
                    <div className="p-1.5 bg-[#FAF8F5] rounded-lg">
                      <div className="text-[10px] text-[#786154] uppercase font-sans">Carbs</div>
                      <div className="font-extrabold text-sm text-[#2D160C]">{product.carbs}g</div>
                    </div>
                    <div className="p-1.5 bg-[#FAF8F5] rounded-lg">
                      <div className="text-[10px] text-[#786154] uppercase font-sans">Fats</div>
                      <div className="font-extrabold text-sm text-[#2D160C]">{product.fats}g</div>
                    </div>
                  </div>
                </div>

                {/* Clean Ingredients */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#2D160C]">
                    <ShieldCheck className="w-4 h-4 text-[#16A34A]" />
                    <span>{lang === 'bn' ? '১০০% খাঁটি উপাদানসমূহ' : '100% Clean Ingredients'}</span>
                  </div>
                  <div className="text-xs text-[#5C4537] leading-relaxed">
                    {(lang === 'bn' ? product.ingredientsBn : product.ingredients).join(', ')}
                  </div>
                </div>

                {/* Social Media Sharing Section */}
                <div className="pt-2 border-t border-[#EAE4D9] space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-[#2D160C] flex items-center gap-1.5">
                      <Share2 className="w-3.5 h-3.5 text-[#EA580C]" />
                      <span>{lang === 'bn' ? 'বন্ধুদের সাথে শেয়ার করুন' : 'Share with Friends'}</span>
                    </span>
                    {copiedShareLink && (
                      <span className="text-[11px] font-bold text-[#16A34A] flex items-center gap-1 animate-in fade-in">
                        <Check className="w-3.5 h-3.5" />
                        <span>{lang === 'bn' ? 'লিঙ্ক কপি হয়েছে!' : 'Link Copied!'}</span>
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-4 gap-2">
                    {/* WhatsApp */}
                    <button
                      type="button"
                      onClick={() => handleShare('whatsapp')}
                      className="flex items-center justify-center gap-1.5 py-1.5 px-2 bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/30 text-[#128C7E] rounded-lg text-xs font-bold transition-colors cursor-pointer"
                      title="Share on WhatsApp"
                    >
                      <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
                        <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2zm0 17.82c-1.52 0-3-.4-4.3-1.17l-.31-.18-3.19.84.85-3.11-.2-.32a8.04 8.04 0 01-1.23-4.26c0-4.46 3.63-8.09 8.09-8.09 2.16 0 4.19.84 5.72 2.37 1.53 1.53 2.37 3.56 2.37 5.72 0 4.46-3.63 8.09-8.1 8.09zm4.43-6.07c-.24-.12-1.44-.71-1.66-.79-.22-.08-.38-.12-.55.12-.16.24-.63.79-.78.95-.14.16-.29.18-.53.06-.24-.12-1.02-.38-1.95-1.2-.72-.64-1.21-1.44-1.35-1.68-.14-.24-.02-.37.1-.49.11-.11.24-.29.37-.43.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.55-1.32-.75-1.81-.2-.48-.4-.41-.55-.42-.14-.01-.3-.01-.46-.01-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2.01s.86 2.33.98 2.5c.12.16 1.7 2.6 4.12 3.64.58.25 1.03.4 1.38.51.58.18 1.11.16 1.53.1.47-.07 1.44-.59 1.64-1.16.2-.57.2-1.06.14-1.16-.06-.1-.22-.16-.46-.28z"/>
                      </svg>
                      <span className="hidden xs:inline">WhatsApp</span>
                    </button>

                    {/* Facebook */}
                    <button
                      type="button"
                      onClick={() => handleShare('facebook')}
                      className="flex items-center justify-center gap-1.5 py-1.5 px-2 bg-[#1877F2]/10 hover:bg-[#1877F2]/20 border border-[#1877F2]/30 text-[#1877F2] rounded-lg text-xs font-bold transition-colors cursor-pointer"
                      title="Share on Facebook"
                    >
                      <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                      </svg>
                      <span className="hidden xs:inline">Facebook</span>
                    </button>

                    {/* Twitter / X */}
                    <button
                      type="button"
                      onClick={() => handleShare('twitter')}
                      className="flex items-center justify-center gap-1.5 py-1.5 px-2 bg-neutral-900/10 hover:bg-neutral-900/20 border border-neutral-300 text-neutral-800 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                      title="Share on X"
                    >
                      <svg className="w-3.5 h-3.5 fill-current shrink-0" viewBox="0 0 24 24">
                        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                      </svg>
                      <span className="hidden xs:inline">X (Twitter)</span>
                    </button>

                    {/* Copy Link / Native Share */}
                    <button
                      type="button"
                      onClick={() => handleShare('copy')}
                      className="flex items-center justify-center gap-1.5 py-1.5 px-2 bg-[#FAF8F5] hover:bg-[#F2ECE1] border border-[#D5C9B8] text-[#2D160C] rounded-lg text-xs font-bold transition-colors cursor-pointer"
                      title="Copy Link"
                    >
                      {copiedShareLink ? (
                        <Check className="w-3.5 h-3.5 text-[#16A34A] shrink-0" />
                      ) : (
                        <Copy className="w-3.5 h-3.5 text-[#786154] shrink-0" />
                      )}
                      <span className="truncate">{copiedShareLink ? (lang === 'bn' ? 'কপি!' : 'Copied!') : (lang === 'bn' ? 'কপি লিঙ্ক' : 'Copy Link')}</span>
                    </button>
                  </div>
                </div>

              </div>

            </div>
          ) : (
            /* TAB 2: STAR RATING & CUSTOMER REVIEWS */
            <div className="space-y-4">
              
              {/* Rating Summary Header */}
              <div className="bg-white p-4 rounded-xl border border-[#EAE4D9] flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="text-center sm:text-left">
                    <div className="font-heading font-black text-2xl sm:text-3xl text-[#2D160C] font-mono">
                      {averageRating || (lang === 'bn' ? 'নতুন' : 'New')}
                    </div>
                    <div className="flex items-center text-[#F59E0B] justify-center sm:justify-start mt-0.5">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star
                          key={s}
                          className={`w-4 h-4 ${
                            averageRating && s <= Math.round(Number(averageRating))
                              ? 'fill-[#F59E0B] text-[#F59E0B]'
                              : 'text-[#D5C9B8]'
                          }`}
                        />
                      ))}
                    </div>
                    <div className="text-[11px] text-[#786154] mt-0.5 font-medium">
                      {userReviews.length > 0
                        ? (lang === 'bn' ? `${userReviews.length} জন ক্রেতার রিভিউ` : `Based on ${userReviews.length} reviews`)
                        : (lang === 'bn' ? 'এখনও কোনো রিভিউ নেই' : 'No customer reviews yet')}
                    </div>
                  </div>
                  
                  <div className="border-l border-[#EAE4D9] pl-4 hidden sm:block text-xs text-[#786154] space-y-1">
                    <div className="flex items-center gap-1.5 text-[#16A34A] font-semibold">
                      <ShieldCheck className="w-4 h-4" />
                      <span>{lang === 'bn' ? 'শুধুমাত্র ভেরিফাইড ক্রেতাদের রিভিউ' : '100% Verified Buyer Reviews'}</span>
                    </div>
                    <p className="text-[11px]">
                      {lang === 'bn'
                        ? 'শুধুমাত্র গুগল লগইন করা ক্রেতারা পণ্যটি অর্ডার করার পরই রিভিউ দিতে পারেন।'
                        : 'Only Google logged-in customers who ordered this item can leave a review.'}
                    </p>
                  </div>
                </div>

                {/* Top Action Button if verified buyer */}
                {currentUser && hasPurchased && (
                  <button
                    onClick={() => setShowReviewForm(!showReviewForm)}
                    className="bg-[#EA580C] hover:bg-[#C2410C] active:scale-95 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>{showReviewForm ? (lang === 'bn' ? 'ফর্ম বন্ধ করুন' : 'Close Form') : (lang === 'bn' ? 'রিভিউ লিখুন' : 'Write a Review')}</span>
                  </button>
                )}
              </div>

              {/* Toast Submitted Notification */}
              {submittedMessage && (
                <div className="bg-[#16A34A]/10 border border-[#16A34A]/30 text-[#16A34A] text-xs font-semibold p-3 rounded-xl flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{submittedMessage}</span>
                </div>
              )}

              {/* Review Permission & Submission Cards */}
              {!currentUser ? (
                /* 1. NOT LOGGED IN WITH GMAIL */
                <div className="bg-white p-4 rounded-xl border border-[#EAE4D9] text-center space-y-2.5 shadow-xs">
                  <div className="w-10 h-10 rounded-full bg-amber-50 text-[#EA580C] mx-auto flex items-center justify-center border border-amber-200">
                    <Lock className="w-5 h-5 text-[#EA580C]" />
                  </div>
                  <div>
                    <div className="font-heading font-bold text-sm text-[#2D160C]">
                      {lang === 'bn' ? 'রিভিউ দিতে গুগল (Gmail) দিয়ে লগইন করুন' : 'Sign in with Google to Leave a Review'}
                    </div>
                    <p className="text-[11px] text-[#786154] max-w-sm mx-auto mt-0.5 leading-relaxed">
                      {lang === 'bn'
                        ? 'প্রকৃত ও বিশ্বাসযোগ্য ফিডব্যাকের জন্য জিমেইল লগইন এবং খাবারটি অর্ডার করা আবশ্যক।'
                        : 'To maintain verified authenticity, please log in with your Gmail account to review meals you have ordered.'}
                    </p>
                  </div>
                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={onLoginWithGoogle}
                      className="inline-flex items-center gap-2 bg-white hover:bg-[#FAF8F5] text-[#2D160C] border border-[#D5C9B8] px-4 py-2 rounded-xl font-bold text-xs shadow-xs cursor-pointer transition-all active:scale-95"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                      </svg>
                      <span>{lang === 'bn' ? 'গুগল দিয়ে লগইন করুন' : 'Sign in with Google'}</span>
                    </button>
                  </div>
                </div>
              ) : !hasPurchased ? (
                /* 2. LOGGED IN, BUT HAS NOT PURCHASED THIS PRODUCT */
                <div className="bg-white p-4 rounded-xl border border-[#EAE4D9] text-center space-y-2 shadow-xs">
                  <div className="w-10 h-10 rounded-full bg-[#EA580C]/10 text-[#EA580C] mx-auto flex items-center justify-center">
                    <ShieldCheck className="w-5 h-5 text-[#EA580C]" />
                  </div>
                  <div>
                    <div className="font-heading font-bold text-sm text-[#2D160C]">
                      {lang === 'bn' ? 'শুধুমাত্র এই খাবারটির ক্রেতারা রিভিউ দিতে পারবেন' : 'Verified Purchasers Only'}
                    </div>
                    <p className="text-[11px] text-[#786154] max-w-sm mx-auto mt-0.5 leading-relaxed">
                      {lang === 'bn'
                        ? `আপনি "${product.nameBn}" এখনও অর্ডার করেননি। মুতাযযি ফুডস-এর সততার নিয়মানুযায়ী শুধুমাত্র যেসকল ক্রেতা এই খাবারটি অর্ডার করেছেন তারাই রিভিউ লিখতে পারবেন।`
                        : `You have not ordered "${product.name}" yet. Only verified customers who purchased this meal can leave reviews.`}
                    </p>
                  </div>
                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={handleAdd}
                      className="inline-flex items-center gap-1.5 bg-[#EA580C] hover:bg-[#C2410C] text-white px-4 py-2 rounded-xl text-xs font-bold shadow-xs cursor-pointer transition-all active:scale-95"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>{lang === 'bn' ? 'আগে খাবারটি ট্রাই করতে অর্ডার দিন' : 'Order this food to try'}</span>
                    </button>
                  </div>
                </div>
              ) : showReviewForm ? (
                /* 3. LOGGED IN AND VERIFIED PURCHASER - FORM OPEN */
                <form
                  onSubmit={handleReviewSubmit}
                  className="bg-white p-4 rounded-xl border border-[#EA580C]/30 shadow-md space-y-3 animate-in fade-in duration-200"
                >
                  <div className="font-bold text-xs text-[#2D160C] flex items-center justify-between border-b border-[#F2ECE1] pb-2">
                    <div className="flex items-center gap-1.5">
                      <Star className="w-4 h-4 fill-[#F59E0B] text-[#F59E0B]" />
                      <span>{lang === 'bn' ? 'আপনার রেটিং ও মতামত দিন' : 'Rate & Leave Feedback'}</span>
                    </div>
                    <span className="text-[10px] bg-green-50 text-green-700 px-2 py-0.5 rounded font-bold border border-green-200">
                      {lang === 'bn' ? '✓ ভেরিফাইড ক্রেতা' : '✓ Verified Buyer'}
                    </span>
                  </div>

                  {/* Interactive Star Selector */}
                  <div className="space-y-1">
                    <label className="block text-[11px] font-semibold text-[#786154]">
                      {lang === 'bn' ? 'স্টার রেটিং দিন (১ থেকে ৫ স্টার):' : 'Select Star Rating (1 to 5):'}
                    </label>
                    <div className="flex items-center gap-1.5">
                      {[1, 2, 3, 4, 5].map((starIndex) => {
                        const isFilled = starIndex <= (hoverRating || rating);
                        return (
                          <button
                            type="button"
                            key={starIndex}
                            onMouseEnter={() => setHoverRating(starIndex)}
                            onMouseLeave={() => setHoverRating(0)}
                            onClick={() => setRating(starIndex)}
                            className="p-1 hover:scale-115 transition-transform cursor-pointer"
                            aria-label={`Rate ${starIndex} stars`}
                          >
                            <Star
                              className={`w-6 h-6 transition-colors ${
                                isFilled
                                  ? 'fill-[#F59E0B] text-[#F59E0B]'
                                  : 'text-[#D5C9B8]'
                              }`}
                            />
                          </button>
                        );
                      })}
                      <span className="ml-2 font-mono font-bold text-xs text-[#EA580C]">
                        {rating} / 5
                      </span>
                    </div>
                  </div>

                  {/* Reviewer Name Display */}
                  <div className="bg-[#FAF8F5] p-2 rounded-lg border border-[#EAE4D9] flex items-center justify-between text-xs">
                    <span className="text-[#786154] font-medium">{lang === 'bn' ? 'আপনার নাম:' : 'Reviewer:'}</span>
                    <span className="font-bold text-[#2D160C]">
                      {currentUser?.displayName || currentUser?.email || 'ভেরিফাইড ক্রেতা'}
                    </span>
                  </div>

                  {/* Review Comment */}
                  <div>
                    <label className="block text-[11px] font-semibold text-[#786154] mb-1">
                      {lang === 'bn' ? 'আপনার অভিজ্ঞতা ও স্বাদ সম্পর্কে মন্তব্য *' : 'Your Review / Feedback *'}
                    </label>
                    <textarea
                      required
                      rows={3}
                      placeholder={
                        lang === 'bn'
                          ? 'খাবারটির স্বাদ, প্রোটিনের মান এবং ফ্রেশনেস কেমন লেগেছে বিস্তারিত জানান...'
                          : 'Write your thoughts on taste, nutrition, packaging, and fitness benefits...'
                      }
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg text-xs bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowReviewForm(false)}
                      className="px-3 py-1.5 rounded-lg border border-[#D5C9B8] text-xs font-semibold text-[#786154] hover:bg-[#FAF8F5] cursor-pointer"
                    >
                      {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                    </button>
                    <button
                      type="submit"
                      className="bg-[#EA580C] hover:bg-[#C2410C] active:scale-95 text-white font-bold text-xs py-1.5 px-4 rounded-lg shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{lang === 'bn' ? 'রিভিউ সাবমিট করুন' : 'Submit Review'}</span>
                    </button>
                  </div>
                </form>
              ) : null}

              {/* Reviews List */}
              {userReviews.length === 0 ? (
                <div className="bg-white p-8 rounded-xl border border-[#EAE4D9] text-center space-y-2 shadow-xs">
                  <MessageSquare className="w-8 h-8 text-[#D5C9B8] mx-auto" />
                  <div className="font-heading font-bold text-xs sm:text-sm text-[#2D160C]">
                    {lang === 'bn' ? 'এখনও কোনো রিভিউ যুক্ত হয়নি' : 'No Reviews Yet'}
                  </div>
                  <p className="text-[11px] text-[#786154] max-w-xs mx-auto">
                    {lang === 'bn'
                      ? 'এই খাবারটি সফলভাবে অর্ডার করে থাকলে আপনার মূল্যবান অভিজ্ঞতা প্রথম ক্রেতা হিসেবে শেয়ার করুন।'
                      : 'Be the first verified customer to share feedback on this meal!'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {userReviews.map((rev) => (
                    <div
                      key={rev.id}
                      className="bg-white p-3.5 rounded-xl border border-[#EAE4D9] space-y-2 shadow-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-[#EA580C]/10 text-[#EA580C] font-bold text-xs flex items-center justify-center font-heading">
                            {rev.author.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-bold text-xs text-[#2D160C] flex items-center gap-1.5">
                              <span>{rev.author}</span>
                              {rev.verified && (
                                <span className="text-[10px] bg-green-50 text-green-700 px-1.5 py-0.2 rounded font-medium border border-green-200">
                                  {lang === 'bn' ? 'ভেরিফাইড ক্রেতা' : 'Verified Buyer'}
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-[#8A7669]">{rev.date}</div>
                          </div>
                        </div>

                        {/* Stars */}
                        <div className="flex items-center text-[#F59E0B]">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`w-3.5 h-3.5 ${
                                s <= rev.rating
                                  ? 'fill-[#F59E0B] text-[#F59E0B]'
                                  : 'text-[#D5C9B8]'
                              }`}
                            />
                          ))}
                        </div>
                      </div>

                      <p className="text-xs text-[#5C4537] leading-relaxed pl-9">
                        {rev.comment}
                      </p>
                    </div>
                  ))}
                </div>
              )}

            </div>
          )}

        </div>

        {/* Modal Footer / Add to Cart Actions */}
        <div className="p-3 sm:p-3.5 bg-white border-t border-[#EAE4D9] flex items-center justify-between gap-2.5 shrink-0">
          {/* Quantity Stepper */}
          <div className="flex items-center border border-[#D5C9B8] rounded-lg overflow-hidden bg-[#FAF8F5]">
            <button
              onClick={() => setQty(Math.max(1, qty - 1))}
              className="p-1.5 sm:p-2 text-[#4A3326] hover:bg-[#EAE4D9] transition-colors cursor-pointer"
              aria-label="Decrease quantity"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="px-2.5 sm:px-3 font-mono font-bold text-xs sm:text-sm text-[#2D160C] tabular-nums">
              {qty}
            </span>
            <button
              onClick={() => setQty(qty + 1)}
              className="p-1.5 sm:p-2 text-[#4A3326] hover:bg-[#EAE4D9] transition-colors cursor-pointer"
              aria-label="Increase quantity"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Add to Cart CTA - sleek and compact */}
          <button
            onClick={handleAdd}
            className="flex-1 bg-[#EA580C] hover:bg-[#C2410C] active:scale-98 text-white font-bold py-2 sm:py-2.5 px-3.5 rounded-lg shadow-xs hover:shadow transition-all flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm select-none group"
          >
            <ShoppingBag className="w-4 h-4 text-[#FFF2E8] shrink-0" />
            <span className="tracking-tight whitespace-nowrap">
              {lang === 'bn'
                ? `অর্ডার করুন · ৳${product.price * qty}`
                : `Order Now · ৳${product.price * qty}`}
            </span>
          </button>
        </div>

      </div>
    </div>
  );
};
