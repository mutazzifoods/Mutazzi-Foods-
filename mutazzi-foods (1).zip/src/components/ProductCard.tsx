import React from 'react';
import { Product } from '../types';
import { Plus, Info, Dumbbell, Heart } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
  lang: 'bn' | 'en';
  isFavorite: boolean;
  onToggleFavorite: (productId: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onViewDetails,
  lang,
  isFavorite,
  onToggleFavorite,
}) => {
  return (
    <div className="bg-white rounded-xl sm:rounded-2xl border border-[#EAE4D9] overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-md transition-all duration-200 hover:-translate-y-0.5 group">
      
      {/* Product Image Area */}
      <div
        onClick={() => onViewDetails(product)}
        className="relative aspect-4/3 w-full bg-[#F5EFE6] cursor-pointer overflow-hidden"
      >
        <img
          src={product.image}
          alt={lang === 'bn' ? product.nameBn : product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />

        {/* Favorite Heart Button on Image (Top-Left) */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(product.id);
          }}
          className="absolute top-1.5 left-1.5 sm:top-2.5 sm:left-2.5 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white/95 backdrop-blur-xs shadow-md border border-[#EAE4D9] flex items-center justify-center transition-all hover:scale-110 active:scale-90 cursor-pointer z-10"
          title={isFavorite ? (lang === 'bn' ? 'প্রিয় তালিকা থেকে সরান' : 'Remove from Favorites') : (lang === 'bn' ? 'পছন্দের তালিকায় রাখুন' : 'Save to Favorites')}
          aria-label="Toggle Favorite"
        >
          <Heart
            className={`w-3.5 h-3.5 sm:w-4 sm:h-4 transition-colors ${
              isFavorite
                ? 'fill-[#DC2626] text-[#DC2626]'
                : 'text-[#786154] hover:text-[#DC2626]'
            }`}
          />
        </button>

        {/* Official Brand Logo Seal on every product (Top-Right) */}
        <div className="absolute top-1.5 right-1.5 sm:top-2.5 sm:right-2.5 bg-white/95 backdrop-blur-xs rounded-full p-0.5 sm:p-1 shadow-md border border-[#EAE4D9] flex items-center gap-1 pr-1.5 sm:pr-2 z-10">
          <img
            src="/assets/aistudio/IMG_20261027_161503_c549d1c8.png"
            alt="Mutazzi Foods Logo"
            className="w-4 h-4 sm:w-5 sm:h-5 object-contain rounded-full"
            referrerPolicy="no-referrer"
          />
          <span className="font-heading font-black text-[8px] sm:text-[10px] text-[#2D160C] tracking-tight">
            Mutazzi
          </span>
        </div>

        {/* Minimal text indicator for special items */}
        {product.isPopular && (
          <div className="absolute top-1.5 left-9 sm:top-2.5 sm:left-11 bg-[#2D160C] text-[#FAF8F5] text-[9px] sm:text-[11px] font-bold px-1.5 sm:px-2 py-0.5 rounded tracking-wide shadow-sm">
            {lang === 'bn' ? 'বেস্টসেলার' : 'Bestseller'}
          </div>
        )}

        {product.isNew && (
          <div className="absolute top-1.5 left-9 sm:top-2.5 sm:left-11 bg-[#16A34A] text-white text-[9px] sm:text-[11px] font-bold px-1.5 sm:px-2 py-0.5 rounded tracking-wide shadow-sm">
            {lang === 'bn' ? 'নতুন' : 'New'}
          </div>
        )}

        {/* Weight info */}
        <div className="absolute bottom-1.5 right-1.5 sm:bottom-2.5 sm:right-2.5 bg-black/60 backdrop-blur-xs text-white text-[9px] sm:text-[11px] font-mono px-1.5 py-0.5 rounded">
          {product.weight}
        </div>
      </div>

      {/* Card Content & Metadata */}
      <div className="p-2.5 sm:p-4 flex-1 flex flex-col justify-between space-y-2 sm:space-y-3">
        
        <div>
          {/* Brand & Category Line with Logo Mini Mark */}
          <div className="flex items-center justify-between text-[10px] sm:text-xs text-[#786154] pb-0.5 sm:pb-1 font-medium">
            <div className="flex items-center gap-1 font-bold text-[#EA580C] truncate max-w-[55%]">
              <img
                src="/assets/aistudio/IMG_20261027_161503_c549d1c8.png"
                alt="Brand"
                className="w-3 h-3 sm:w-3.5 sm:h-3.5 object-contain shrink-0"
              />
              <span className="truncate">{lang === 'bn' ? product.categoryLabelBn : product.categoryLabel}</span>
            </div>
            
            <span className="flex items-center gap-0.5 sm:gap-1 text-[#EA580C] font-semibold shrink-0">
              <Dumbbell className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              <span>{product.protein}g {lang === 'bn' ? 'প্রোটিন' : 'P'}</span>
            </span>
          </div>

          {/* Product Title */}
          <h3
            onClick={() => onViewDetails(product)}
            className="font-heading font-bold text-xs sm:text-base text-[#2D160C] hover:text-[#EA580C] transition-colors cursor-pointer line-clamp-2 leading-snug sm:leading-normal"
          >
            {lang === 'bn' ? product.nameBn : product.name}
          </h3>

          {/* Short Description */}
          <p className="text-[11px] sm:text-xs text-[#5C4537] line-clamp-1 sm:line-clamp-2 mt-0.5 sm:mt-1 leading-relaxed hidden xs:block">
            {lang === 'bn' ? product.descriptionBn : product.description}
          </p>

          {/* Macro breakdown line */}
          <div className="mt-1 sm:mt-2 text-[9px] sm:text-[11px] font-mono tabular-nums text-[#8A7669] flex items-center gap-1.5">
            <span>{product.calories} kcal</span>
            <span aria-hidden="true">·</span>
            <span>{product.carbs}g C</span>
            <span aria-hidden="true" className="hidden sm:inline">·</span>
            <span className="hidden sm:inline">{product.fats}g F</span>
          </div>
        </div>

        {/* Bottom Price & Action Zone */}
        <div className="pt-1.5 sm:pt-2 border-t border-[#F2ECE1] flex items-center justify-between gap-1">
          
          <div className="flex flex-col min-w-0">
            <div className="flex items-baseline gap-1">
              <span className="font-heading font-extrabold text-sm sm:text-base text-[#2D160C] tabular-nums tracking-tight">
                ৳{product.price}
              </span>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-[10px] sm:text-xs text-[#9E8B7F] line-through tabular-nums">
                  ৳{product.originalPrice}
                </span>
              )}
            </div>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-[9px] text-[#16A34A] font-bold hidden sm:inline">
                {lang === 'bn' ? '৳' + (product.originalPrice - product.price) + ' ছাড়' : 'Save ৳' + (product.originalPrice - product.price)}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={() => onViewDetails(product)}
              className="p-1 sm:p-1.5 text-[#786154] hover:text-[#2D160C] hover:bg-[#F2ECE1] rounded-lg transition-colors cursor-pointer shrink-0"
              title={lang === 'bn' ? 'পুষ্টি উপাদান ও বিস্তারিত' : 'Nutrition Details'}
              aria-label="View Nutrition Details"
            >
              <Info className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>

            <button
              type="button"
              onClick={() => onAddToCart(product)}
              className="bg-[#EA580C] hover:bg-[#C2410C] active:scale-95 text-white font-bold text-[11px] sm:text-xs px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-1 shrink-0 cursor-pointer select-none group/btn"
              title={lang === 'bn' ? 'অর্ডার করুন' : 'Order Now'}
            >
              <Plus className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0 transition-transform group-hover/btn:rotate-90 duration-200" />
              <span className="whitespace-nowrap tracking-tight">
                {lang === 'bn' ? 'অর্ডার' : 'Order'}
                <span className="hidden sm:inline">{lang === 'bn' ? ' করুন' : ''}</span>
              </span>
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
