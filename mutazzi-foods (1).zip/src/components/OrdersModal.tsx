import React, { useState } from 'react';
import { Order } from '../types';
import { X, Package, Clock, Copy, Check, UserCheck, Truck, Ban, AlertTriangle, FileText } from 'lucide-react';
import { User } from 'firebase/auth';

interface OrdersModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  lang: 'bn' | 'en';
  currentUser?: User | null;
  onLoginWithGoogle?: () => void;
  onCancelOrder: (orderId: string) => void;
}

export const OrdersModal: React.FC<OrdersModalProps> = ({
  isOpen,
  onClose,
  orders,
  lang,
  currentUser,
  onLoginWithGoogle,
  onCancelOrder,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [confirmCancelId, setConfirmCancelId] = useState<string | null>(null);
  const [orderFilterTab, setOrderFilterTab] = useState<'all' | 'pending' | 'delivered'>('all');

  if (!isOpen) return null;

  const handleCopy = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleConfirmCancel = (id: string) => {
    onCancelOrder(id);
    setConfirmCancelId(null);
  };

  const filteredOrders = orders.filter((order) => {
    if (orderFilterTab === 'pending') {
      return order.status !== 'Delivered' && order.status !== 'Cancelled';
    }
    if (orderFilterTab === 'delivered') {
      return order.status === 'Delivered';
    }
    return true; // 'all'
  });

  const handleDownloadInvoice = (order: Order) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert(lang === 'bn' ? 'ইনভয়েস প্রিন্ট করার জন্য পপআপ (Pop-up) অনুমতি দিন।' : 'Please allow popups to download/print the invoice.');
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Mutazzi Foods - Invoice #${order.id}</title>
        <style>
          body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; color: #2D160C; margin: 0; padding: 20px; background: #fff; }
          .invoice-container { max-width: 750px; margin: auto; padding: 30px; border: 1px solid #EAE4D9; border-radius: 12px; background: #FAF8F5; }
          .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #EA580C; padding-bottom: 20px; margin-bottom: 25px; }
          .brand-title { font-size: 24px; font-weight: 900; color: #2D160C; }
          .brand-sub { font-size: 12px; color: #786154; margin-top: 2px; }
          .invoice-meta { text-align: right; font-size: 13px; color: #4A3326; line-height: 1.5; }
          .grid-info { display: flex; justify-content: space-between; margin-bottom: 25px; background: #fff; padding: 15px; border-radius: 8px; border: 1px solid #EAE4D9; font-size: 13px; }
          .grid-info div { flex: 1; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 25px; background: #fff; border-radius: 8px; overflow: hidden; border: 1px solid #EAE4D9; }
          th, td { padding: 12px 15px; text-align: left; font-size: 13px; border-bottom: 1px solid #F2ECE1; }
          th { background: #2D160C; color: #FAF8F5; font-weight: bold; }
          .totals { width: 300px; margin-left: auto; background: #fff; padding: 15px; border-radius: 8px; border: 1px solid #EAE4D9; font-size: 13px; }
          .total-row { display: flex; justify-content: space-between; padding: 5px 0; font-weight: 600; color: #4A3326; }
          .grand-total { font-size: 16px; font-weight: 900; color: #EA580C; border-top: 2px solid #2D160C; padding-top: 8px; margin-top: 8px; }
          .footer { text-align: center; margin-top: 40px; font-size: 11px; color: #786154; border-top: 1px solid #EAE4D9; padding-top: 15px; }
          @media print {
            body { padding: 0; background: #fff; }
            .invoice-container { border: none; box-shadow: none; padding: 0; background: #fff; }
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="invoice-container">
          <div class="header">
            <div>
              <div class="brand-title">Mutazzi <span style="color: #EA580C;">Foods</span></div>
              <div class="brand-sub">${lang === 'bn' ? '১০০% হালাল, অর্গানিক ও হাই-প্রোটিন পুষ্টি' : '100% Halal, Organic & High-Protein Nutrition'}</div>
            </div>
            <div class="invoice-meta">
              <strong>Invoice / Order ID: #${order.id}</strong><br>
              <span>Date: ${new Date(order.date).toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US')}</span><br>
              <span>Status: <strong>${order.status}</strong></span>
            </div>
          </div>

          <div class="grid-info">
            <div>
              <strong style="color: #2D160C; display: block; margin-bottom: 4px;">${lang === 'bn' ? 'বিলিং ও ডেলিভারি ঠিকানা:' : 'Bill To:'}</strong>
              ${order.customerName}<br>
              Phone: ${order.phone}<br>
              Address: ${order.address}
            </div>
            <div>
              <strong style="color: #2D160C; display: block; margin-bottom: 4px;">${lang === 'bn' ? 'অর্ডার তথ্য:' : 'Order Info:'}</strong>
              Delivery Zone: ${order.deliveryZone}<br>
              Payment: ${order.paymentMethod.toUpperCase()}<br>
              Support: 01611222170
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>${lang === 'bn' ? 'পণ্যের নাম' : 'Item Description'}</th>
                <th>${lang === 'bn' ? 'ওজন' : 'Weight'}</th>
                <th>${lang === 'bn' ? 'পরিমাণ' : 'Qty'}</th>
                <th>${lang === 'bn' ? 'মূল্য' : 'Price'}</th>
                <th>${lang === 'bn' ? 'মোট' : 'Total'}</th>
              </tr>
            </thead>
            <tbody>
              ${order.items.map(item => `
                <tr>
                  <td><strong>${lang === 'bn' ? item.nameBn : item.name}</strong></td>
                  <td>${item.weight}</td>
                  <td>${item.quantity}</td>
                  <td>৳${item.price}</td>
                  <td><strong>৳${item.price * item.quantity}</strong></td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div class="totals">
            <div class="total-row">
              <span>${lang === 'bn' ? 'সাবটোটাল:' : 'Subtotal:'}</span>
              <span>৳${order.subtotal}</span>
            </div>
            ${order.discount > 0 ? `
              <div class="total-row" style="color: #16A34A;">
                <span>${lang === 'bn' ? 'ডিসকাউন্ট:' : 'Discount:'}</span>
                <span>-৳${order.discount}</span>
              </div>
            ` : ''}
            <div class="total-row">
              <span>${lang === 'bn' ? 'ডেলিভারি চার্জ:' : 'Delivery Fee:'}</span>
              <span>${order.deliveryFee === 0 ? 'FREE (৳0)' : `৳${order.deliveryFee}`}</span>
            </div>
            <div class="total-row grand-total">
              <span>${lang === 'bn' ? 'সর্বমোট পরিশোধযোগ্য:' : 'Grand Total:'}</span>
              <span>৳${order.total}</span>
            </div>
          </div>

          <div style="clear: both;"></div>

          <div class="footer">
            ${lang === 'bn' ? 'মুতাযযি ফুডস থেকে কেনাকাটা করার জন্য আপনাকে ধন্যবাদ! হেল্পলাইন: 01611222170' : 'Thank you for choosing Mutazzi Foods! Helpline: 01611222170'}<br>
            Parbatipur, Dinajpur · support@mutazzifoods.com
          </div>
        </div>

        <div style="text-align: center; margin-top: 20px;" class="no-print">
          <button onclick="window.print()" style="background: #EA580C; color: white; border: none; padding: 10px 20px; font-weight: bold; border-radius: 8px; cursor: pointer; font-size: 14px;">
            ${lang === 'bn' ? '🖨️ প্রিন্ট করুন বা PDF সেভ করুন' : '🖨️ Print / Save as PDF'}
          </button>
        </div>

        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 500);
          }
        </script>
      </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-[#FAF8F5] w-full max-w-2xl rounded-2xl overflow-hidden shadow-2xl border border-[#E0D5C5] max-h-[85vh] flex flex-col">
        
        {/* Header */}
        <div className="px-5 py-4 bg-white border-b border-[#EAE4D9] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-[#EA580C]" />
            <h2 className="font-heading font-bold text-lg text-[#2D160C]">
              {lang === 'bn' ? 'আমার অর্ডার হিস্টোরি' : 'My Order History'}
            </h2>
            <span className="text-xs bg-[#F2ECE1] text-[#786154] font-mono px-2 py-0.5 rounded-full font-bold">
              {orders.length}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#786154] hover:text-[#2D160C] hover:bg-[#F2ECE1] rounded-lg transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Account Bar */}
        <div className="px-5 py-2.5 bg-white border-b border-[#EAE4D9] flex flex-wrap items-center justify-between gap-2 text-xs">
          {currentUser ? (
            <div className="flex items-center gap-2 text-[#16A34A] font-medium">
              <UserCheck className="w-4 h-4" />
              <span>
                {lang === 'bn' ? 'সংযুক্ত অ্যাকাউন্ট:' : 'Connected Account:'}{' '}
                <strong className="text-[#2D160C]">{currentUser.email}</strong>
              </span>
            </div>
          ) : (
            <div className="flex items-center justify-between w-full">
              <span className="text-[#786154]">
                {lang === 'bn' ? 'লগইন ছাড়াই এই ডিভাইসের সকল অর্ডার সংরক্ষিত আছে' : 'Local orders stored on this device'}
              </span>
              {onLoginWithGoogle && (
                <button
                  onClick={onLoginWithGoogle}
                  className="text-[#EA580C] hover:underline font-bold flex items-center gap-1 cursor-pointer"
                >
                  <svg className="w-3 h-3" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>{lang === 'bn' ? 'গুগল দিয়ে লগইন করুন' : 'Sign in with Google'}</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Tab-based Filter Bar (All, Pending, Delivered) */}
        {orders.length > 0 && (
          <div className="px-5 py-2.5 bg-[#FAF8F5] border-b border-[#EAE4D9] flex items-center gap-2 text-xs shrink-0 overflow-x-auto">
            <span className="text-[#786154] font-bold mr-1">
              {lang === 'bn' ? 'ফিল্টার:' : 'Filter:'}
            </span>
            <button
              onClick={() => setOrderFilterTab('all')}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer whitespace-nowrap ${
                orderFilterTab === 'all'
                  ? 'bg-[#2D160C] text-white shadow-xs'
                  : 'bg-white text-[#786154] hover:bg-[#F2ECE1] border border-[#EAE4D9]'
              }`}
            >
              {lang === 'bn' ? `সকল (${orders.length})` : `All (${orders.length})`}
            </button>
            <button
              onClick={() => setOrderFilterTab('pending')}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer whitespace-nowrap ${
                orderFilterTab === 'pending'
                  ? 'bg-[#EA580C] text-white shadow-xs'
                  : 'bg-white text-[#786154] hover:bg-orange-50 border border-[#EAE4D9]'
              }`}
            >
              {lang === 'bn'
                ? `চলমান / পেন্ডিং (${orders.filter(o => o.status !== 'Delivered' && o.status !== 'Cancelled').length})`
                : `Active / Pending (${orders.filter(o => o.status !== 'Delivered' && o.status !== 'Cancelled').length})`}
            </button>
            <button
              onClick={() => setOrderFilterTab('delivered')}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer whitespace-nowrap ${
                orderFilterTab === 'delivered'
                  ? 'bg-[#16A34A] text-white shadow-xs'
                  : 'bg-white text-[#786154] hover:bg-green-50 border border-[#EAE4D9]'
              }`}
            >
              {lang === 'bn'
                ? `সম্পন্ন / ডেলিভার্ড (${orders.filter(o => o.status === 'Delivered').length})`
                : `Delivered (${orders.filter(o => o.status === 'Delivered').length})`}
            </button>
          </div>
        )}

        {/* Scrollable Content */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {orders.length === 0 ? (
            <div className="text-center py-12 space-y-3 text-[#786154]">
              <div className="w-12 h-12 rounded-full bg-[#F2ECE1] mx-auto flex items-center justify-center">
                <Clock className="w-6 h-6 text-[#A8988B]" />
              </div>
              <div className="font-heading font-bold text-base text-[#2D160C]">
                {lang === 'bn' ? 'কোনো পূর্ববর্তী অর্ডার নেই' : 'No previous orders found'}
              </div>
              <p className="text-xs text-[#786154] max-w-sm mx-auto">
                {lang === 'bn'
                  ? 'আপনি যখন কোনো খাবার বা প্যাকেজ অর্ডার করবেন, তার বিস্তারিত ও ট্র্যাকিং এখানে দেখতে পাবেন।'
                  : 'Your completed and pending orders will appear here automatically.'}
              </p>
            </div>
          ) : filteredOrders.length === 0 ? (
            <div className="text-center py-12 space-y-2 text-[#786154]">
              <div className="font-heading font-bold text-sm text-[#2D160C]">
                {lang === 'bn' ? 'এই ফিল্টারে কোনো অর্ডার নেই' : 'No orders in this filter category'}
              </div>
              <button
                onClick={() => setOrderFilterTab('all')}
                className="text-xs text-[#EA580C] font-bold underline cursor-pointer"
              >
                {lang === 'bn' ? 'সকল অর্ডার দেখুন' : 'View all orders'}
              </button>
            </div>
          ) : (
            filteredOrders.map((order) => {
              const isCancelled = order.status === 'Cancelled';
              return (
                <div
                  key={order.id}
                  className={`bg-white rounded-xl border p-4 shadow-xs space-y-3 transition-all ${
                    isCancelled ? 'border-red-200 bg-red-50/20 opacity-80' : 'border-[#EAE4D9]'
                  }`}
                >
                  {/* Order Top Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#F2ECE1] pb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-xs text-[#2D160C]">
                        #{order.id}
                      </span>
                      <button
                        onClick={() => handleCopy(order.id)}
                        className="p-1 text-[#786154] hover:text-[#2D160C] transition-colors cursor-pointer"
                        title="Copy Order ID"
                      >
                        {copiedId === order.id ? (
                          <Check className="w-3.5 h-3.5 text-[#16A34A]" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                      {order.isGuest && (
                        <span className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.2 rounded font-medium">
                          {lang === 'bn' ? 'গেস্ট অর্ডার' : 'Guest'}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-[#8A7669]">
                        {new Date(order.date).toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                      
                      {/* Status Badge */}
                      {isCancelled ? (
                        <span className="text-xs bg-red-100 text-red-700 font-bold px-2.5 py-0.5 rounded-full border border-red-200 flex items-center gap-1">
                          <Ban className="w-3 h-3" />
                          <span>{lang === 'bn' ? 'বাতিলকৃত' : 'Cancelled'}</span>
                        </span>
                      ) : order.status === 'Processing' ? (
                        <span className="text-xs bg-amber-100 text-amber-800 font-bold px-2.5 py-0.5 rounded-full border border-amber-300 flex items-center gap-1.5 shadow-xs">
                          <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping shrink-0" />
                          <span>{lang === 'bn' ? 'প্রসেসিং চলছে' : 'Processing'}</span>
                        </span>
                      ) : order.status === 'Delivering' ? (
                        <span className="text-xs bg-blue-100 text-blue-800 font-bold px-2.5 py-0.5 rounded-full border border-blue-300 flex items-center gap-1">
                          <Truck className="w-3.5 h-3.5 text-blue-600 animate-bounce" />
                          <span>{lang === 'bn' ? 'ডেলিভারিতে বের হয়েছে' : 'Out for Delivery'}</span>
                        </span>
                      ) : order.status === 'Delivered' ? (
                        <span className="text-xs bg-green-100 text-green-800 font-bold px-2.5 py-0.5 rounded-full border border-green-300 flex items-center gap-1">
                          <Check className="w-3.5 h-3.5 text-green-600" />
                          <span>{lang === 'bn' ? 'ডেলিভারি সম্পন্ন' : 'Delivered'}</span>
                        </span>
                      ) : (
                        <span className="text-xs bg-[#ECFDF5] text-[#065F46] font-bold px-2.5 py-0.5 rounded-full border border-[#A7F3D0]">
                          {lang === 'bn' ? 'অর্ডার নিশ্চিতকৃত' : 'Confirmed'}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Order Progress Stepper / Live Timeline */}
                  {!isCancelled && (
                    <div className="bg-[#FAF8F5] rounded-xl p-3 border border-[#EAE4D9] space-y-2">
                      <div className="flex items-center justify-between text-[10px] sm:text-xs font-bold text-[#786154]">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-[#EA580C]" />
                          <span>{lang === 'bn' ? 'অর্ডারের বর্তমান অবস্থা:' : 'Live Order Status:'}</span>
                        </span>
                        <span className="font-mono text-[#2D160C]">
                          {order.status === 'Delivered'
                            ? (lang === 'bn' ? '৪/৪ সম্পন্ন' : '4/4 Completed')
                            : order.status === 'Delivering'
                            ? (lang === 'bn' ? '৩/৪ ডেলিভারিতে' : '3/4 On the way')
                            : order.status === 'Processing'
                            ? (lang === 'bn' ? '২/৪ প্রসেসিং' : '2/4 Processing')
                            : (lang === 'bn' ? '১/৪ নিশ্চিতকৃত' : '1/4 Confirmed')}
                        </span>
                      </div>

                      {/* 4-Step Tracker Bar */}
                      <div className="grid grid-cols-4 gap-1 sm:gap-2 pt-1">
                        {/* Step 1: Confirmed */}
                        <div className="flex flex-col items-center text-center gap-1">
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-colors ${
                            order.status === 'Confirmed' || order.status === 'Processing' || order.status === 'Delivering' || order.status === 'Delivered'
                              ? 'bg-[#16A34A] text-white shadow-xs'
                              : 'bg-gray-200 text-gray-600'
                          }`}>
                            ✓
                          </div>
                          <span className="text-[9px] sm:text-[11px] font-bold text-[#2D160C] leading-tight">
                            {lang === 'bn' ? 'অর্ডার গৃহীত' : 'Placed'}
                          </span>
                        </div>

                        {/* Step 2: Processing */}
                        <div className="flex flex-col items-center text-center gap-1">
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-colors ${
                            order.status === 'Processing'
                              ? 'bg-amber-500 text-white ring-2 ring-amber-300 animate-pulse'
                              : order.status === 'Delivering' || order.status === 'Delivered'
                              ? 'bg-[#16A34A] text-white'
                              : 'bg-gray-200 text-gray-500'
                          }`}>
                            {order.status === 'Delivering' || order.status === 'Delivered' ? '✓' : '২'}
                          </div>
                          <span className={`text-[9px] sm:text-[11px] font-bold leading-tight ${
                            order.status === 'Processing' ? 'text-amber-700' : 'text-[#786154]'
                          }`}>
                            {lang === 'bn' ? 'প্রসেসিং' : 'Cooking'}
                          </span>
                        </div>

                        {/* Step 3: Delivering */}
                        <div className="flex flex-col items-center text-center gap-1">
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-colors ${
                            order.status === 'Delivering'
                              ? 'bg-blue-600 text-white ring-2 ring-blue-300 animate-pulse'
                              : order.status === 'Delivered'
                              ? 'bg-[#16A34A] text-white'
                              : 'bg-gray-200 text-gray-500'
                          }`}>
                            {order.status === 'Delivered' ? '✓' : '৩'}
                          </div>
                          <span className={`text-[9px] sm:text-[11px] font-bold leading-tight ${
                            order.status === 'Delivering' ? 'text-blue-700' : 'text-[#786154]'
                          }`}>
                            {lang === 'bn' ? 'ডেলিভারিতে' : 'Shipping'}
                          </span>
                        </div>

                        {/* Step 4: Delivered */}
                        <div className="flex flex-col items-center text-center gap-1">
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-colors ${
                            order.status === 'Delivered'
                              ? 'bg-[#16A34A] text-white ring-2 ring-green-300'
                              : 'bg-gray-200 text-gray-500'
                          }`}>
                            {order.status === 'Delivered' ? '✓' : '৪'}
                          </div>
                          <span className={`text-[9px] sm:text-[11px] font-bold leading-tight ${
                            order.status === 'Delivered' ? 'text-green-700' : 'text-[#786154]'
                          }`}>
                            {lang === 'bn' ? 'ডেলিভার্ড' : 'Delivered'}
                          </span>
                        </div>
                      </div>

                      {/* Informative Status Message Box */}
                      <div className="mt-1 pt-1.5 border-t border-[#EAE4D9] text-[11px] leading-snug">
                        {order.status === 'Processing' ? (
                          <div className="text-amber-800 bg-amber-50/80 p-2 rounded-lg border border-amber-200 flex items-center gap-1.5 font-medium">
                            <span className="text-base">👨‍🍳</span>
                            <span>
                              {lang === 'bn'
                                ? 'মুতাযযি কিচেনে আপনার অর্ডারটি ফ্রেশ প্রস্তুত ও স্বাস্থ্যকর উপায়ে প্যাকিং চলছে।'
                                : 'Chef is freshly preparing and packing your meal bowl.'}
                            </span>
                          </div>
                        ) : order.status === 'Delivering' ? (
                          <div className="text-blue-800 bg-blue-50/80 p-2 rounded-lg border border-blue-200 flex items-center gap-1.5 font-medium">
                            <Truck className="w-4 h-4 text-blue-600 shrink-0" />
                            <span>
                              {lang === 'bn'
                                ? 'আপনার পার্সেল ডেলিভারির পথে রয়েছে। ডেলিভারি রাইডার শিগগিরই আপনার সাথে যোগাযোগ করবেন।'
                                : 'Your package is on the way! Rider will contact you upon arrival.'}
                            </span>
                          </div>
                        ) : order.status === 'Delivered' ? (
                          <div className="text-green-800 bg-green-50/80 p-2 rounded-lg border border-green-200 flex items-center gap-1.5 font-medium">
                            <Check className="w-4 h-4 text-green-600 shrink-0" />
                            <span>
                              {lang === 'bn'
                                ? 'অর্ডারটি সফলভাবে ডেলিভারি সম্পন্ন হয়েছে! সুস্থ থাকুন মুতাযযি ফুডস-এর খাঁটি পুষ্টির সাথে।'
                                : 'Order successfully delivered. Enjoy your high-protein meal!'}
                            </span>
                          </div>
                        ) : (
                          <div className="text-[#1E40AF] bg-[#EFF6FF] p-2 rounded-lg border border-[#DBEAFE] flex items-center gap-1.5 font-medium">
                            <Truck className="w-4 h-4 text-[#2563EB] shrink-0" />
                            <span>
                              {lang === 'bn'
                                ? 'অর্ডার নিশ্চিত হয়েছে। ১ থেকে ৭ দিনের মধ্যে আপনার ঠিকানায় পৌঁছে দেওয়া হবে।'
                                : 'Order confirmed. Delivery will arrive within 1-7 business days.'}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Customer Details */}
                  <div className="text-xs text-[#5C4537] space-y-1">
                    <div>
                      <span className="font-semibold text-[#2D160C]">{lang === 'bn' ? 'গ্রাহক:' : 'Customer:'}</span>{' '}
                      {order.customerName} ({order.phone})
                    </div>
                    <div>
                      <span className="font-semibold text-[#2D160C]">{lang === 'bn' ? 'ঠিকানা:' : 'Address:'}</span>{' '}
                      {order.address} · {order.deliveryZone}
                    </div>
                  </div>

                  {/* Items preview */}
                  <div className="bg-[#FAF8F5] rounded-lg p-2.5 space-y-1 text-xs">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-center text-[#4A3326]">
                        <span className="line-clamp-1">
                          {lang === 'bn' ? item.nameBn : item.name} × {item.quantity}
                        </span>
                        <span className="font-mono tabular-nums font-semibold shrink-0">
                          ৳{item.price * item.quantity}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Totals & Cancel Order Option */}
                  <div className="flex flex-wrap justify-between items-center text-xs pt-2 border-t border-[#F2ECE1] gap-2">
                    <span className="text-[#786154]">
                      {lang === 'bn' ? 'পেমেন্ট মেথড:' : 'Payment:'} <span className="uppercase font-semibold">{order.paymentMethod}</span>
                    </span>

                    <div className="flex items-center gap-2.5 flex-wrap">
                      <div>
                        <span className="text-[#786154] mr-1.5">{lang === 'bn' ? 'সর্বমোট:' : 'Total:'}</span>
                        <span className="font-heading font-extrabold text-sm text-[#EA580C] font-mono tabular-nums">
                          ৳{order.total}
                        </span>
                      </div>

                      {/* Download Invoice PDF Button */}
                      <button
                        onClick={() => handleDownloadInvoice(order)}
                        className="bg-white hover:bg-[#FAF8F5] text-[#2D160C] border border-[#D5C9B8] px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                        title="Download Invoice PDF"
                      >
                        <FileText className="w-3.5 h-3.5 text-[#EA580C]" />
                        <span>{lang === 'bn' ? 'ইনভয়েস PDF' : 'Download Invoice'}</span>
                      </button>

                      {/* Cancel Order Button */}
                      {!isCancelled && order.status !== 'Delivered' && (
                        <div>
                          {confirmCancelId === order.id ? (
                            <div className="flex items-center gap-1.5 bg-red-50 p-1 rounded-lg border border-red-200">
                              <span className="text-[10px] text-red-700 font-bold">
                                {lang === 'bn' ? 'বাতিল নিশ্চিত?' : 'Confirm?'}
                              </span>
                              <button
                                onClick={() => handleConfirmCancel(order.id)}
                                className="px-2 py-0.5 bg-red-600 hover:bg-red-700 text-white rounded text-[10px] font-bold cursor-pointer"
                              >
                                {lang === 'bn' ? 'হ্যাঁ' : 'Yes'}
                              </button>
                              <button
                                onClick={() => setConfirmCancelId(null)}
                                className="px-2 py-0.5 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded text-[10px] cursor-pointer"
                              >
                                {lang === 'bn' ? 'না' : 'No'}
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setConfirmCancelId(order.id)}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50 px-2.5 py-1 rounded border border-red-200 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Ban className="w-3 h-3" />
                              <span>{lang === 'bn' ? 'অর্ডার বাতিল' : 'Cancel'}</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {isCancelled && (
                    <div className="text-[11px] text-red-600 italic bg-red-50/50 p-1.5 rounded">
                      {lang === 'bn'
                        ? '🚫 এই অর্ডারটি বাতিল করা হয়েছে। নতুন পণ্য নিতে চাইলে পুনরায় অর্ডার করতে পারেন।'
                        : '🚫 This order has been cancelled.'}
                    </div>
                  )}

                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-white border-t border-[#EAE4D9] flex justify-end">
          <button
            onClick={onClose}
            className="bg-[#2D160C] hover:bg-black text-white font-bold text-xs px-5 py-2 rounded-xl transition-colors cursor-pointer"
          >
            {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>

      </div>
    </div>
  );
};
