import React from 'react';
import { Order } from '../types';
import { CheckCircle2, Truck, Phone, MapPin, Calendar, Clock, ShoppingBag, X, Copy, Check } from 'lucide-react';

interface OrderSuccessModalProps {
  order: Order | null;
  onClose: () => void;
  onViewOrders: () => void;
  lang: 'bn' | 'en';
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  onClose,
  onViewOrders,
  lang,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!order) return null;

  const handleCopyId = () => {
    navigator.clipboard?.writeText(order.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative bg-[#FAF8F5] rounded-2xl max-w-lg w-full shadow-2xl border border-[#EAE4D9] overflow-hidden my-6">
        
        {/* Top Decorative Banner with Brand Colors */}
        <div className="bg-gradient-to-r from-[#2D160C] via-[#4A2411] to-[#2D160C] p-6 text-center text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/70 hover:text-white bg-black/20 hover:bg-black/40 rounded-full p-1.5 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Official Mutazzi Foods Brand Logo */}
          <div className="w-20 h-20 mx-auto rounded-full bg-white p-1.5 shadow-xl border-2 border-[#EA580C] mb-3 relative group">
            <img
              src="/assets/aistudio/IMG_20261027_161503_c549d1c8.png"
              alt="Mutazzi Foods Official Logo"
              className="w-full h-full object-contain rounded-full"
              referrerPolicy="no-referrer"
            />
            <div className="absolute -bottom-1 -right-1 bg-[#16A34A] text-white p-1 rounded-full shadow-md">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>

          <div className="text-xs uppercase tracking-widest text-[#FB923C] font-extrabold">
            Mutazzi Foods · খাঁটি অর্গানিক পুষ্টি
          </div>

          <h2 className="font-heading font-extrabold text-xl sm:text-2xl mt-1 text-white">
            {lang === 'bn' ? 'অর্ডার সফলভাবে নিশ্চিত হয়েছে!' : 'Order Placed Successfully!'}
          </h2>

          <p className="text-xs sm:text-sm text-[#F5EFE6] mt-1.5 max-w-sm mx-auto leading-relaxed font-medium">
            {lang === 'bn'
              ? 'মুতাযযি ফুডস-এর সাথে থাকার জন্য আপনাকে আন্তরিক ধন্যবাদ! আপনার সুস্থতা ও শক্তির অঙ্গীকার রক্ষায় আমরা নিবেদিত।'
              : 'Thank you for choosing Mutazzi Foods! We are committed to fueling your strength with 100% clean nutrition.'}
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-4 max-h-[68vh] overflow-y-auto">
          
          {/* Order ID & Status Ribbon */}
          <div className="bg-white p-3.5 rounded-xl border border-[#EAE4D9] flex items-center justify-between shadow-xs">
            <div>
              <div className="text-[11px] text-[#786154] font-medium">
                {lang === 'bn' ? 'অর্ডার নম্বর (Order ID)' : 'Order Reference'}
              </div>
              <div className="font-mono font-extrabold text-base text-[#2D160C] flex items-center gap-2">
                <span>#{order.id}</span>
                <button
                  onClick={handleCopyId}
                  className="text-xs text-[#EA580C] hover:text-[#C2410C] flex items-center gap-1 font-sans font-bold cursor-pointer"
                  title="Copy ID"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#16A34A]" />
                      <span className="text-[10px] text-[#16A34A]">{lang === 'bn' ? 'কপি হয়েছে' : 'Copied'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span className="text-[10px]">{lang === 'bn' ? 'কপি' : 'Copy'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="text-right">
              <span className="inline-flex items-center gap-1 bg-[#16A34A]/10 text-[#16A34A] text-xs font-bold px-2.5 py-1 rounded-full">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {lang === 'bn' ? 'কনফার্মড' : 'Confirmed'}
              </span>
            </div>
          </div>

          {/* Delivery Promise Card (1-7 Days) */}
          <div className="bg-[#FFF7ED] border border-[#FFEDD5] rounded-xl p-3.5 flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#EA580C] text-white flex items-center justify-center shrink-0 shadow-xs">
              <Truck className="w-4 h-4" />
            </div>
            <div className="text-xs space-y-0.5">
              <div className="font-bold text-[#9A3412]">
                {lang === 'bn' ? 'হোম ডেলিভারি সময়সীমা: ১-৭ দিন' : 'Home Delivery: 1-7 Business Days'}
              </div>
              <div className="text-[#786154] leading-relaxed">
                {lang === 'bn'
                  ? 'আপনার অর্ডারটি নিরাপদে প্রস্তুত করে আগামী ১ থেকে ৭ দিনের মধ্যে আপনার উল্লিখিত ঠিকানায় পৌঁছে দেওয়া হবে।'
                  : 'Your fresh order is being packed and will be delivered to your door within 1-7 days.'}
              </div>
            </div>
          </div>

          {/* Customer & Delivery Summary */}
          <div className="bg-white rounded-xl border border-[#EAE4D9] p-3.5 space-y-2 text-xs">
            <div className="font-heading font-bold text-xs text-[#2D160C] border-b border-[#F2ECE1] pb-1.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#EA580C]" />
              <span>{lang === 'bn' ? 'ডেলিভারি বিবরণ' : 'Delivery Details'}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-0.5">
              <div>
                <span className="text-[11px] text-[#786154] block">{lang === 'bn' ? 'গ্রাহকের নাম:' : 'Customer:'}</span>
                <span className="font-bold text-[#2D160C]">{order.customerName}</span>
              </div>
              <div>
                <span className="text-[11px] text-[#786154] block">{lang === 'bn' ? 'মোবাইল নম্বর:' : 'Phone:'}</span>
                <span className="font-bold font-mono text-[#2D160C]">{order.phone}</span>
              </div>
            </div>

            <div className="pt-1">
              <span className="text-[11px] text-[#786154] block">{lang === 'bn' ? 'ঠিকানা:' : 'Address:'}</span>
              <span className="font-medium text-[#2D160C] leading-snug">{order.address}</span>
            </div>

            <div className="pt-1 flex items-center justify-between text-[11px] border-t border-[#F2ECE1] mt-1 pt-1.5">
              <span className="text-[#786154]">{lang === 'bn' ? 'পেমেন্ট মেথড:' : 'Payment Method:'}</span>
              <span className="font-bold text-[#2D160C] uppercase">
                {order.paymentMethod === 'cod' ? (lang === 'bn' ? 'ক্যাশ অন ডেলিভারি (COD)' : 'Cash on Delivery') : order.paymentMethod}
              </span>
            </div>
          </div>

          {/* Ordered Items Summary */}
          <div className="bg-white rounded-xl border border-[#EAE4D9] p-3.5 space-y-2 text-xs">
            <div className="font-heading font-bold text-xs text-[#2D160C] border-b border-[#F2ECE1] pb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ShoppingBag className="w-3.5 h-3.5 text-[#EA580C]" />
                <span>{lang === 'bn' ? 'অর্ডারকৃত খাদ্যতালিকা' : 'Ordered Items'}</span>
              </span>
              <span className="text-[#786154] font-mono text-[11px]">{order.items.length} {lang === 'bn' ? 'টি আইটেম' : 'items'}</span>
            </div>

            <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
              {order.items.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between py-1 border-b border-[#FAF8F5] last:border-none">
                  <div className="flex items-center gap-2">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-7 h-7 rounded-md object-cover border border-[#EAE4D9]"
                    />
                    <div>
                      <div className="font-semibold text-[#2D160C] line-clamp-1">
                        {lang === 'bn' ? item.nameBn : item.name}
                      </div>
                      <div className="text-[10px] text-[#786154]">
                        ৳{item.price} × {item.quantity}
                      </div>
                    </div>
                  </div>
                  <div className="font-mono font-bold text-[#2D160C] tabular-nums">
                    ৳{item.price * item.quantity}
                  </div>
                </div>
              ))}
            </div>

            {/* Total Calculation */}
            <div className="border-t border-[#F2ECE1] pt-2 space-y-1 font-medium">
              <div className="flex justify-between text-[11px] text-[#786154]">
                <span>{lang === 'bn' ? 'সাবটোটাল' : 'Subtotal'}</span>
                <span className="font-mono tabular-nums">৳{order.subtotal}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-[11px] text-[#16A34A]">
                  <span>{lang === 'bn' ? 'ডিসকাউন্ট' : 'Discount'}</span>
                  <span className="font-mono tabular-nums">-৳{order.discount}</span>
                </div>
              )}
              <div className="flex justify-between text-[11px] text-[#786154]">
                <span>{lang === 'bn' ? 'ডেলিভারি চার্জ' : 'Delivery Fee'}</span>
                <span className="font-mono tabular-nums">{order.deliveryFee === 0 ? (lang === 'bn' ? 'ফ্রি' : 'Free') : `৳${order.deliveryFee}`}</span>
              </div>
              <div className="flex justify-between text-sm font-extrabold text-[#2D160C] pt-1 border-t border-[#EAE4D9]">
                <span>{lang === 'bn' ? 'সর্বমোট প্রদেয়' : 'Total Payable'}</span>
                <span className="font-mono text-[#EA580C] text-base tabular-nums">৳{order.total}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer Action Buttons */}
        <div className="p-4 bg-white border-t border-[#EAE4D9] flex flex-col sm:flex-row items-center gap-2.5">
          <button
            onClick={() => {
              onClose();
              onViewOrders();
            }}
            className="w-full sm:flex-1 bg-gradient-to-r from-[#2D160C] to-[#4A2411] hover:from-[#1F0E07] hover:to-[#381B0D] text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md transition-all active:scale-95 cursor-pointer"
          >
            <Clock className="w-4 h-4 text-[#FB923C]" />
            <span>{lang === 'bn' ? 'আমার অর্ডার ট্র্যাক করুন' : 'Track My Orders'}</span>
          </button>

          <button
            onClick={onClose}
            className="w-full sm:flex-1 bg-[#EA580C] hover:bg-[#C2410C] text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md transition-all active:scale-95 cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>{lang === 'bn' ? 'আরো কেনাকাটা করুন' : 'Continue Shopping'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
