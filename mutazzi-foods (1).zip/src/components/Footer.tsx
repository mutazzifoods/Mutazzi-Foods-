import React from 'react';
import { Phone, Mail, MapPin, ShieldCheck } from 'lucide-react';

interface FooterProps {
  lang: 'bn' | 'en';
}

export const Footer: React.FC<FooterProps> = ({ lang }) => {
  return (
    <footer className="bg-[#2D160C] text-[#FAF8F5] pt-12 pb-8 border-t border-[#3D2012]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Grid: 4 columns on desktop, 2 on tablet, 1 on mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-10 border-b border-white/10">
          
          {/* Col 1: Brand Wordmark & Mission */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white p-1 flex items-center justify-center shrink-0">
                <img
                  src="/assets/aistudio/IMG_20261027_161503_c549d1c8.png"
                  alt="Mutazzi Foods Logo"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="font-heading font-extrabold text-xl text-white tracking-tight">
                Mutazzi <span className="text-[#EA580C]">Foods</span>
              </div>
            </div>

            <p className="text-xs text-[#C5B8A8] leading-relaxed">
              {lang === 'bn'
                ? 'শারীরিক সক্ষমতা ও খাঁটি সুস্থতার জন্য হাই-প্রোটিন মিলস, অর্গানিক নাট বাটার, সুপারফুড গ্রানোলা ও সুন্দরবনের র মধু প্রস্তুতকারক।'
                : 'Pioneering chef-crafted high-protein meals, artisanal organic nut butters, and clean superfoods for athletes and health advocates.'}
            </p>

            <div className="flex items-center gap-2 text-xs text-[#16A34A] font-semibold">
              <ShieldCheck className="w-4 h-4" />
              <span>BSTI & Food Safety Standard Compliant</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="font-heading font-bold text-sm text-white tracking-wider uppercase text-[#FB923C]">
              {lang === 'bn' ? 'কুইক ন্যাভিগেশন' : 'Navigation'}
            </h4>
            <ul className="space-y-2 text-xs text-[#C5B8A8]">
              <li>
                <a href="#menu" className="hover:text-[#EA580C] transition-colors">
                  {lang === 'bn' ? 'সকল পাওয়ার ফুডস ও মেনু' : 'All Power Foods & Menu'}
                </a>
              </li>
              <li>
                <a href="#calculator" className="hover:text-[#EA580C] transition-colors">
                  {lang === 'bn' ? 'দৈনিক প্রোটিন ক্যালকুলেটর' : 'Daily Protein Calculator'}
                </a>
              </li>
              <li>
                <a href="#story" className="hover:text-[#EA580C] transition-colors">
                  {lang === 'bn' ? 'ব্র্যান্ড দর্শন ও লোগোর তাৎপর্য' : 'Brand Story & Logo Philosophy'}
                </a>
              </li>
              <li>
                <span className="text-white/60">
                  {lang === 'bn' ? 'ক্যাশ অন ডেলিভারি ও বিকাশ' : 'Cash on Delivery & bKash'}
                </span>
              </li>
            </ul>
          </div>

          {/* Col 3: Kitchen & Delivery Coverage */}
          <div className="space-y-3">
            <h4 className="font-heading font-bold text-sm text-white tracking-wider uppercase text-[#FB923C]">
              {lang === 'bn' ? 'ডেলিভারি এরিয়া' : 'Delivery Coverage'}
            </h4>
            <p className="text-xs text-[#C5B8A8] leading-relaxed">
              {lang === 'bn'
                ? 'পার্বতীপুর এলাকায় দ্রুততম হোম ডেলিভারি মাত্র ১০০ টাকা এবং পার্বতীপুরের বাইরে দেশের যেকোনো স্থানে ১২০ টাকা। যেকোনো ১৫০০ টাকার বেশি অর্ডারে ফ্রি ডেলিভারি!'
                : 'Fast fresh delivery: Parbatipur ৳100, Anywhere outside Parbatipur ৳120. Free delivery on all orders over ৳1500.'}
            </p>
            <div className="text-[11px] text-[#A8988B] font-mono">
              Daily Kitchen Hours: 8:00 AM – 10:00 PM
            </div>
          </div>

          {/* Col 4: Contact & Order Helpline */}
          <div className="space-y-3">
            <h4 className="font-heading font-bold text-sm text-white tracking-wider uppercase text-[#FB923C]">
              {lang === 'bn' ? 'যোগাযোগ ও সাপোর্ট' : 'Support & Orders'}
            </h4>
            <div className="space-y-2 text-xs text-[#C5B8A8]">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#EA580C]" />
                <span className="font-mono">01611222170 / +880 1611-222170</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#EA580C]" />
                <span>support@mutazzifoods.com</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#EA580C] shrink-0 mt-0.5" />
                <span>Banani / Dhanmondi Gourmet Cloud Kitchen, Dhaka, Bangladesh</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Tagline */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-[#A8988B] gap-3">
          <div>
            © {new Date().getFullYear()} Mutazzi Foods Ltd. All rights reserved.
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Privacy Policy</span>
            <span aria-hidden="true">·</span>
            <span>Terms of Service</span>
            <span aria-hidden="true">·</span>
            <span className="text-[#EA580C] font-semibold">100% Halal & Organic</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
