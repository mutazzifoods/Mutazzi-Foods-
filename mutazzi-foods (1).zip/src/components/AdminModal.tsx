import React, { useState } from 'react';
import { Product, Order } from '../types';
import { CATEGORIES } from '../data/products';
import { 
  X, Plus, Edit2, Trash2, Save, RotateCcw, ShieldCheck, 
  Settings, Package, DollarSign, Truck, Sparkles, AlertTriangle, 
  Search, CheckCircle2, ChevronDown, ChevronUp, Image as ImageIcon,
  Phone, MapPin, Copy, Check, Clock, Calendar, ExternalLink, RefreshCw, Send, Ban, ShoppingBag, UserCheck
} from 'lucide-react';

export interface AppSettings {
  parbatipurDelivery: number;
  outsideDelivery: number;
  freeDeliveryThreshold: number;
  bundleDiscountPct: number;
  bannerNoticeBn?: string;
  bannerNoticeEn?: string;
}

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onAddProduct: (newProduct: Product) => void;
  onUpdateProduct: (updatedProduct: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onResetProducts: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: Order['status']) => void;
  lang: 'bn' | 'en';
}

const PRESET_IMAGES = [
  { label: 'Bowl 1 (Chicken & Quinoa)', url: '/src/assets/images/hero_mutazzi_healthy_bowl_1793165771441.jpg' },
  { label: 'Bowl 2 (Beef Steak)', url: '/src/assets/images/product_lean_beef_sweet_potato_1793165787093.jpg' },
  { label: 'Peanut Butter', url: '/src/assets/images/product_organic_peanut_butter_1793165803274.jpg' },
  { label: 'Granola', url: '/src/assets/images/product_artisan_granola_cluster_1793165819078.jpg' },
  { label: 'Forest Honey', url: '/src/assets/images/product_raw_sundarban_honey_1793165834898.jpg' },
  { label: 'Whey Smoothie', url: '/src/assets/images/product_whey_berry_smoothie_1793165851457.jpg' },
  { label: 'Salmon Rice', url: '/src/assets/images/product_teriyaki_salmon_brown_rice_1793165867389.jpg' },
  { label: 'Almond Butter', url: '/src/assets/images/product_almond_crunch_butter_1793165883701.jpg' },
];

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onResetProducts,
  settings,
  onUpdateSettings,
  orders = [],
  onUpdateOrderStatus,
  lang,
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'settings'>('orders');
  const [searchTerm, setSearchTerm] = useState('');
  const [orderSearch, setOrderSearch] = useState('');
  const [orderFilter, setOrderFilter] = useState<'all' | 'Confirmed' | 'Processing' | 'Delivering' | 'Delivered' | 'Cancelled'>('all');
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Settings State
  const [editSettings, setEditSettings] = useState<AppSettings>(settings);

  // New Product Form State
  const [newProd, setNewProd] = useState<Partial<Product>>({
    name: '',
    nameBn: '',
    category: 'bowls',
    categoryLabel: 'Power Bowls',
    categoryLabelBn: 'পাওয়ার বাউলস',
    price: 350,
    originalPrice: 400,
    image: PRESET_IMAGES[0].url,
    description: '',
    descriptionBn: '',
    protein: 35,
    calories: 480,
    carbs: 45,
    fats: 12,
    weight: '450g',
    isPopular: false,
    isNew: true,
    ingredients: ['Chicken Breast', 'Organic Rice', 'Seasonal Greens'],
    ingredientsBn: ['চিকেন ব্রেস্ট', 'অর্গানিক চাল', 'তাজা সবুজ শাকসবজি'],
  });

  const [ingredientsInput, setIngredientsInput] = useState('Chicken Breast, Organic Rice, Seasonal Greens');
  const [ingredientsBnInput, setIngredientsBnInput] = useState('চিকেন ব্রেস্ট, অর্গানিক চাল, তাজা সবুজ শাকসবজি');

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(editSettings);
    showToast(lang === 'bn' ? 'ডেলিভারি ও ডিসকাউন্ট সেটিংস সংরক্ষিত হয়েছে!' : 'Settings updated successfully!');
  };

  const handleCopyOrderId = (id: string) => {
    navigator.clipboard?.writeText(id);
    setCopiedOrderId(id);
    setTimeout(() => setCopiedOrderId(null), 2000);
  };

  const handleStatusChange = (orderId: string, newStatus: Order['status']) => {
    onUpdateOrderStatus(orderId, newStatus);
    const label =
      newStatus === 'Processing'
        ? (lang === 'bn' ? 'প্রসেসিং চলছে' : 'Processing')
        : newStatus === 'Delivered'
        ? (lang === 'bn' ? 'ডেলিভারি সম্পন্ন' : 'Delivered')
        : newStatus === 'Delivering'
        ? (lang === 'bn' ? 'ডেলিভারিতে বের হয়েছে' : 'Out for Delivery')
        : newStatus === 'Confirmed'
        ? (lang === 'bn' ? 'কনফার্মড' : 'Confirmed')
        : (lang === 'bn' ? 'বাতিল' : 'Cancelled');
    showToast(
      lang === 'bn'
        ? `অর্ডার #${orderId}-এর স্ট্যাটাস "${label}" করা হয়েছে (গ্রাহক এখন দেখতে পাবেন)`
        : `Order #${orderId} status changed to "${label}" (Customer can see now)`
    );
  };

  // Stats calculation
  const totalOrdersCount = orders.length;
  const pendingCount = orders.filter((o) => o.status === 'Confirmed').length;
  const processingCount = orders.filter((o) => o.status === 'Processing').length;
  const deliveringCount = orders.filter((o) => o.status === 'Delivering').length;
  const deliveredCount = orders.filter((o) => o.status === 'Delivered').length;
  const cancelledCount = orders.filter((o) => o.status === 'Cancelled').length;
  const totalRevenue = orders
    .filter((o) => o.status !== 'Cancelled')
    .reduce((sum, o) => sum + o.total, 0);

  // Filtered orders list
  const filteredOrders = orders.filter((o) => {
    const matchesFilter = orderFilter === 'all' || o.status === orderFilter;
    const q = orderSearch.toLowerCase().trim();
    if (!q) return matchesFilter;
    const matchesSearch =
      o.id.toLowerCase().includes(q) ||
      o.customerName.toLowerCase().includes(q) ||
      o.phone.includes(q) ||
      o.address.toLowerCase().includes(q) ||
      o.deliveryZone.toLowerCase().includes(q) ||
      o.items.some(
        (it) =>
          it.name.toLowerCase().includes(q) ||
          it.nameBn.toLowerCase().includes(q)
      );
    return matchesFilter && matchesSearch;
  });

  const handleCategorySelect = (catId: any, isEditMode = false) => {
    const selectedCat = CATEGORIES.find((c) => c.id === catId);
    if (!selectedCat) return;

    if (isEditMode && editingProduct) {
      setEditingProduct({
        ...editingProduct,
        category: catId,
        categoryLabel: selectedCat.label,
        categoryLabelBn: selectedCat.labelBn,
      });
    } else {
      setNewProd((prev) => ({
        ...prev,
        category: catId,
        categoryLabel: selectedCat.label,
        categoryLabelBn: selectedCat.labelBn,
      }));
    }
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProd.name || !newProd.nameBn || !newProd.price) {
      alert(lang === 'bn' ? 'দয়া করে পণ্যের নাম ও দাম লিখুন।' : 'Please enter product name and price.');
      return;
    }

    const created: Product = {
      id: 'prod_' + Date.now(),
      name: newProd.name.trim(),
      nameBn: newProd.nameBn.trim(),
      category: (newProd.category as any) || 'bowls',
      categoryLabel: newProd.categoryLabel || 'Power Bowls',
      categoryLabelBn: newProd.categoryLabelBn || 'পাওয়ার বাউলস',
      price: Number(newProd.price),
      originalPrice: newProd.originalPrice ? Number(newProd.originalPrice) : undefined,
      image: newProd.image || PRESET_IMAGES[0].url,
      description: newProd.description?.trim() || 'High protein nutritious food.',
      descriptionBn: newProd.descriptionBn?.trim() || 'উচ্চ প্রোটিন সমৃদ্ধ স্বাস্থ্যকর খাদ্য।',
      protein: Number(newProd.protein || 30),
      calories: Number(newProd.calories || 450),
      carbs: Number(newProd.carbs || 40),
      fats: Number(newProd.fats || 10),
      weight: newProd.weight?.trim() || '450g',
      isPopular: Boolean(newProd.isPopular),
      isNew: Boolean(newProd.isNew),
      ingredients: ingredientsInput.split(',').map((s) => s.trim()).filter(Boolean),
      ingredientsBn: ingredientsBnInput.split(',').map((s) => s.trim()).filter(Boolean),
    };

    onAddProduct(created);
    setIsAddingNew(false);
    showToast(lang === 'bn' ? `"${created.nameBn}" পণ্যটি সফলভাবে যুক্ত হয়েছে!` : `Product "${created.name}" added!`);
  };

  const handleSaveEditProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    onUpdateProduct(editingProduct);
    setEditingProduct(null);
    showToast(lang === 'bn' ? `"${editingProduct.nameBn}" আপডেট করা হয়েছে!` : `Product updated!`);
  };

  const filtered = products.filter((p) => {
    const q = searchTerm.toLowerCase().trim();
    if (!q) return true;
    return (
      p.name.toLowerCase().includes(q) ||
      p.nameBn.toLowerCase().includes(q) ||
      p.categoryLabel.toLowerCase().includes(q) ||
      p.descriptionBn.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative bg-[#FAF8F5] rounded-2xl max-w-4xl w-full shadow-2xl border border-[#EAE4D9] overflow-hidden my-4 sm:my-6 flex flex-col max-h-[92vh]">
        
        {/* Header Ribbon */}
        <div className="bg-[#2D160C] text-white p-4 sm:p-5 flex items-center justify-between border-b border-[#4A2411] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#EA580C] to-[#FB923C] flex items-center justify-center text-white shadow-md">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-heading font-extrabold text-base sm:text-lg">
                  {lang === 'bn' ? 'সুপার এডমিন কন্ট্রোল প্যানেল' : 'Super Admin Control Panel'}
                </h2>
                <span className="bg-[#EA580C] text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Admin
                </span>
              </div>
              <div className="text-xs text-[#C5B8A8] font-mono mt-0.5">
                লগইন: <span className="text-[#FB923C] font-semibold">mdlabiburrahman26@gmail.com</span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-white/70 hover:text-white bg-white/10 hover:bg-white/20 p-2 rounded-xl transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast Alert */}
        {toastMessage && (
          <div className="bg-[#16A34A] text-white text-xs font-semibold px-4 py-2.5 flex items-center gap-2 animate-in slide-in-from-top duration-150">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Tab Bar */}
        <div className="flex items-center border-b border-[#EAE4D9] bg-white px-3 sm:px-6 shrink-0 overflow-x-auto">
          <button
            onClick={() => setActiveTab('orders')}
            className={`py-3 px-3 sm:px-4 text-xs sm:text-sm font-bold flex items-center gap-1.5 sm:gap-2 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'orders'
                ? 'border-[#EA580C] text-[#EA580C]'
                : 'border-transparent text-[#786154] hover:text-[#2D160C]'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>{lang === 'bn' ? `অর্ডারসমূহ (${orders.length})` : `Orders (${orders.length})`}</span>
            {pendingCount + processingCount > 0 && (
              <span className="bg-[#EA580C] text-white text-[10px] font-mono px-1.5 py-0.2 rounded-full font-bold animate-pulse">
                {pendingCount + processingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`py-3 px-3 sm:px-4 text-xs sm:text-sm font-bold flex items-center gap-1.5 sm:gap-2 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'products'
                ? 'border-[#EA580C] text-[#EA580C]'
                : 'border-transparent text-[#786154] hover:text-[#2D160C]'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>{lang === 'bn' ? `পণ্য ব্যবস্থাপনা (${products.length}টি)` : `Products (${products.length})`}</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`py-3 px-3 sm:px-4 text-xs sm:text-sm font-bold flex items-center gap-1.5 sm:gap-2 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'settings'
                ? 'border-[#EA580C] text-[#EA580C]'
                : 'border-transparent text-[#786154] hover:text-[#2D160C]'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>{lang === 'bn' ? 'ডেলিভারি চার্জ ও ডিসকাউন্ট' : 'Delivery & Discount Settings'}</span>
          </button>
        </div>

        {/* TAB 0: ORDERS MANAGEMENT & LIVE STATUS CONTROLS */}
        {activeTab === 'orders' && (
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
            
            {/* Quick Stats Overview */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-white p-3 rounded-xl border border-[#EAE4D9] shadow-xs">
                <div className="text-[11px] text-[#786154] font-medium flex items-center justify-between">
                  <span>{lang === 'bn' ? 'সর্বমোট অর্ডার' : 'Total Orders'}</span>
                  <ShoppingBag className="w-3.5 h-3.5 text-[#EA580C]" />
                </div>
                <div className="font-heading font-black text-xl text-[#2D160C] mt-1 font-mono">
                  {totalOrdersCount}
                </div>
              </div>

              <div className="bg-white p-3 rounded-xl border border-amber-200 bg-amber-50/20 shadow-xs">
                <div className="text-[11px] text-amber-800 font-medium flex items-center justify-between">
                  <span>{lang === 'bn' ? 'চলমান প্রসেসিং' : 'Processing'}</span>
                  <RefreshCw className="w-3.5 h-3.5 text-amber-600 animate-spin" />
                </div>
                <div className="font-heading font-black text-xl text-amber-700 mt-1 font-mono">
                  {processingCount}
                </div>
              </div>

              <div className="bg-white p-3 rounded-xl border border-green-200 bg-green-50/20 shadow-xs">
                <div className="text-[11px] text-green-800 font-medium flex items-center justify-between">
                  <span>{lang === 'bn' ? 'ডেলিভারি সম্পন্ন' : 'Delivered'}</span>
                  <Check className="w-3.5 h-3.5 text-green-600" />
                </div>
                <div className="font-heading font-black text-xl text-green-700 mt-1 font-mono">
                  {deliveredCount}
                </div>
              </div>

              <div className="bg-white p-3 rounded-xl border border-[#EAE4D9] shadow-xs">
                <div className="text-[11px] text-[#786154] font-medium flex items-center justify-between">
                  <span>{lang === 'bn' ? 'মোট বিক্রয় মূল্য' : 'Total Sales'}</span>
                  <DollarSign className="w-3.5 h-3.5 text-[#16A34A]" />
                </div>
                <div className="font-heading font-black text-xl text-[#16A34A] mt-1 font-mono">
                  ৳{totalRevenue}
                </div>
              </div>
            </div>

            {/* Filter Chips & Search Bar */}
            <div className="bg-white p-3.5 rounded-xl border border-[#EAE4D9] space-y-3 shadow-xs">
              {/* Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-[#786154] absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder={lang === 'bn' ? 'গ্রাহকের নাম, মোবাইল নম্বর, ঠিকানা, বা খাবারের নাম দিয়ে খুঁজুন...' : 'Search by name, phone, address, or meal...'}
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                />
                {orderSearch && (
                  <button
                    onClick={() => setOrderSearch('')}
                    className="absolute right-2.5 top-2 text-[#786154] hover:text-[#2D160C] text-xs"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Status Filter Chips */}
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                <span className="text-[#786154] font-medium mr-1 text-[11px]">
                  {lang === 'bn' ? 'ফিল্টার:' : 'Filter:'}
                </span>

                <button
                  type="button"
                  onClick={() => setOrderFilter('all')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    orderFilter === 'all'
                      ? 'bg-[#2D160C] text-white shadow-xs'
                      : 'bg-[#FAF8F5] text-[#786154] hover:bg-[#F2ECE1] border border-[#EAE4D9]'
                  }`}
                >
                  {lang === 'bn' ? `সকল (${totalOrdersCount})` : `All (${totalOrdersCount})`}
                </button>

                <button
                  type="button"
                  onClick={() => setOrderFilter('Confirmed')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    orderFilter === 'Confirmed'
                      ? 'bg-[#16A34A] text-white shadow-xs'
                      : 'bg-[#FAF8F5] text-[#16A34A] hover:bg-green-50 border border-green-200'
                  }`}
                >
                  {lang === 'bn' ? `নতুন নিশ্চিত (${pendingCount})` : `Confirmed (${pendingCount})`}
                </button>

                <button
                  type="button"
                  onClick={() => setOrderFilter('Processing')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    orderFilter === 'Processing'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-[#FAF8F5] text-amber-700 hover:bg-amber-50 border border-amber-300'
                  }`}
                >
                  {lang === 'bn' ? `প্রসেসিং (${processingCount})` : `Processing (${processingCount})`}
                </button>

                <button
                  type="button"
                  onClick={() => setOrderFilter('Delivering')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    orderFilter === 'Delivering'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-[#FAF8F5] text-blue-700 hover:bg-blue-50 border border-blue-200'
                  }`}
                >
                  {lang === 'bn' ? `ডেলিভারিতে (${deliveringCount})` : `Delivering (${deliveringCount})`}
                </button>

                <button
                  type="button"
                  onClick={() => setOrderFilter('Delivered')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    orderFilter === 'Delivered'
                      ? 'bg-green-700 text-white shadow-xs'
                      : 'bg-[#FAF8F5] text-green-700 hover:bg-green-50 border border-green-300'
                  }`}
                >
                  {lang === 'bn' ? `ডেলিভার্ড (${deliveredCount})` : `Delivered (${deliveredCount})`}
                </button>

                <button
                  type="button"
                  onClick={() => setOrderFilter('Cancelled')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    orderFilter === 'Cancelled'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'bg-[#FAF8F5] text-red-600 hover:bg-red-50 border border-red-200'
                  }`}
                >
                  {lang === 'bn' ? `বাতিল (${cancelledCount})` : `Cancelled (${cancelledCount})`}
                </button>
              </div>
            </div>

            {/* Orders List */}
            {filteredOrders.length === 0 ? (
              <div className="bg-white p-10 rounded-xl border border-[#EAE4D9] text-center space-y-2 text-[#786154] shadow-xs">
                <ShoppingBag className="w-10 h-10 text-[#D5C9B8] mx-auto" />
                <div className="font-heading font-bold text-base text-[#2D160C]">
                  {lang === 'bn' ? 'কোনো অর্ডার পাওয়া যায়নি' : 'No orders found'}
                </div>
                <p className="text-xs max-w-sm mx-auto">
                  {lang === 'bn'
                    ? 'গ্রাহক যখন ওয়েবসাইট থেকে অর্ডার করবেন, তখন তার নাম, ঠিকানা, ফোন ও পণ্যের তালিকা এখানে স্বয়ংক্রিয়ভাবে দেখতে পাবেন।'
                    : 'Customer orders with phone, address, and products will appear here immediately.'}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredOrders.map((order) => {
                  const cleanPhone = order.phone.replace(/[^0-9]/g, '');
                  const waNumber = cleanPhone.startsWith('880')
                    ? cleanPhone
                    : cleanPhone.startsWith('0')
                    ? `88${cleanPhone}`
                    : `880${cleanPhone}`;
                  const isCancelled = order.status === 'Cancelled';

                  return (
                    <div
                      key={order.id}
                      className={`bg-white rounded-xl border p-4 shadow-sm space-y-3.5 transition-all ${
                        order.status === 'Processing'
                          ? 'border-amber-300 ring-1 ring-amber-200'
                          : order.status === 'Delivered'
                          ? 'border-green-300'
                          : isCancelled
                          ? 'border-red-200 opacity-80'
                          : 'border-[#EAE4D9]'
                      }`}
                    >
                      {/* Order Card Top Bar */}
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#F2ECE1] pb-3">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-sm text-[#2D160C]">
                            #{order.id}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCopyOrderId(order.id)}
                            className="p-1 text-[#786154] hover:text-[#2D160C] transition-colors cursor-pointer"
                            title="Copy Order ID"
                          >
                            {copiedOrderId === order.id ? (
                              <Check className="w-3.5 h-3.5 text-[#16A34A]" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                          {order.isGuest ? (
                            <span className="text-[10px] bg-gray-100 text-gray-700 font-semibold px-2 py-0.5 rounded">
                              {lang === 'bn' ? 'গেস্ট ক্রেতা' : 'Guest'}
                            </span>
                          ) : (
                            <span className="text-[10px] bg-green-50 text-green-700 font-semibold px-2 py-0.5 rounded border border-green-200 flex items-center gap-1">
                              <UserCheck className="w-3 h-3" />
                              <span>{lang === 'bn' ? 'লগইনকৃত' : 'Member'}</span>
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-xs text-[#8A7669] flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>
                              {new Date(order.date).toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </span>

                          {/* Live Status Badge */}
                          {order.status === 'Processing' ? (
                            <span className="text-xs bg-amber-100 text-amber-800 font-extrabold px-2.5 py-1 rounded-full border border-amber-300 flex items-center gap-1.5 shadow-xs">
                              <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
                              <span>{lang === 'bn' ? 'প্রসেসিং চলছে' : 'Processing'}</span>
                            </span>
                          ) : order.status === 'Delivering' ? (
                            <span className="text-xs bg-blue-100 text-blue-800 font-extrabold px-2.5 py-1 rounded-full border border-blue-300 flex items-center gap-1 shadow-xs">
                              <Truck className="w-3.5 h-3.5 text-blue-600" />
                              <span>{lang === 'bn' ? 'ডেলিভারিতে' : 'Out for Delivery'}</span>
                            </span>
                          ) : order.status === 'Delivered' ? (
                            <span className="text-xs bg-green-100 text-green-800 font-extrabold px-2.5 py-1 rounded-full border border-green-300 flex items-center gap-1 shadow-xs">
                              <Check className="w-3.5 h-3.5 text-green-600" />
                              <span>{lang === 'bn' ? 'ডেলিভারি সম্পন্ন' : 'Delivered'}</span>
                            </span>
                          ) : isCancelled ? (
                            <span className="text-xs bg-red-100 text-red-700 font-extrabold px-2.5 py-1 rounded-full border border-red-200 flex items-center gap-1 shadow-xs">
                              <Ban className="w-3 h-3" />
                              <span>{lang === 'bn' ? 'বাতিল' : 'Cancelled'}</span>
                            </span>
                          ) : (
                            <span className="text-xs bg-emerald-50 text-emerald-800 font-extrabold px-2.5 py-1 rounded-full border border-emerald-300 shadow-xs">
                              {lang === 'bn' ? 'নতুন নিশ্চিত' : 'Confirmed'}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Customer Details Box & Direct Calling/WhatsApp */}
                      <div className="bg-[#FAF8F5] rounded-xl p-3 border border-[#EAE4D9] grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                        <div className="space-y-1">
                          <div className="font-bold text-[#2D160C] text-sm flex items-center gap-2">
                            <span>👤 {order.customerName}</span>
                            {order.userEmail && order.userEmail !== 'guest@mutazzifoods.com' && (
                              <span className="text-[10px] text-[#786154] font-normal font-mono">
                                ({order.userEmail})
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2 pt-1">
                            <span className="font-mono font-extrabold text-[#2D160C] text-xs">
                              📞 {order.phone}
                            </span>
                            <a
                              href={`tel:${order.phone}`}
                              className="px-2 py-0.5 bg-white border border-[#D5C9B8] rounded text-[11px] font-bold text-[#2D160C] hover:bg-[#F2ECE1] transition-colors flex items-center gap-1 cursor-pointer"
                              title="Direct Phone Call"
                            >
                              <Phone className="w-3 h-3 text-[#EA580C]" />
                              <span>{lang === 'bn' ? 'কল দিন' : 'Call'}</span>
                            </a>
                            <a
                              href={`https://wa.me/${waNumber}`}
                              target="_blank"
                              rel="noreferrer"
                              className="px-2 py-0.5 bg-[#25D366]/10 border border-[#25D366]/40 rounded text-[11px] font-bold text-[#128C7E] hover:bg-[#25D366]/20 transition-colors flex items-center gap-1 cursor-pointer"
                              title="Message on WhatsApp"
                            >
                              <span className="w-2 h-2 rounded-full bg-[#25D366]" />
                              <span>WhatsApp</span>
                            </a>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <div className="flex items-start gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-[#EA580C] shrink-0 mt-0.5" />
                            <div>
                              <span className="font-bold text-[#2D160C]">{lang === 'bn' ? 'ঠিকানা:' : 'Address:'}</span>{' '}
                              <span className="text-[#5C4537] leading-snug">{order.address}</span>
                            </div>
                          </div>
                          <div className="text-[11px] text-[#786154] pl-5 flex items-center gap-2">
                            <span>{lang === 'bn' ? 'ডেলিভারি এলাকা:' : 'Area:'} <strong className="text-[#2D160C]">{order.deliveryZone}</strong></span>
                            <span>·</span>
                            <span>{lang === 'bn' ? 'পেমেন্ট:' : 'Payment:'} <strong className="text-[#2D160C] uppercase">{order.paymentMethod}</strong></span>
                          </div>
                        </div>
                      </div>

                      {/* Itemized Food List */}
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-bold text-[#786154] uppercase tracking-wide flex items-center justify-between">
                          <span>{lang === 'bn' ? 'অর্ডারকৃত খাবার ও পরিমাণ' : 'Ordered Food Items'}</span>
                          <span>{order.items.length} {lang === 'bn' ? 'টি আইটেম' : 'items'}</span>
                        </div>

                        <div className="divide-y divide-[#F2ECE1] border border-[#EAE4D9] rounded-xl overflow-hidden bg-white">
                          {order.items.map((item, idx) => (
                            <div key={idx} className="p-2.5 flex items-center justify-between text-xs">
                              <div className="flex items-center gap-2.5">
                                <img
                                  src={item.image}
                                  alt={item.name}
                                  className="w-10 h-10 rounded-lg object-cover border border-[#EAE4D9] shrink-0"
                                />
                                <div>
                                  <div className="font-bold text-[#2D160C]">
                                    {lang === 'bn' ? item.nameBn : item.name}
                                  </div>
                                  <div className="text-[10px] text-[#786154]">
                                    {item.weight} · {item.protein}g Protein · ৳{item.price} প্রতি মিল
                                  </div>
                                </div>
                              </div>

                              <div className="text-right">
                                <div className="font-mono font-extrabold text-[#2D160C]">
                                  ৳{item.price * item.quantity}
                                </div>
                                <div className="text-[10px] text-[#EA580C] font-bold">
                                  {item.quantity} {lang === 'bn' ? 'টি' : 'qty'}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Pricing Summary */}
                      <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#EAE4D9] text-xs flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-3 text-[#786154]">
                          <span>{lang === 'bn' ? 'সাবটোটাল:' : 'Subtotal:'} <strong className="text-[#2D160C]">৳{order.subtotal}</strong></span>
                          {order.discount > 0 && (
                            <span className="text-[#16A34A]">{lang === 'bn' ? 'ডিসকাউন্ট:' : 'Discount:'} <strong>-৳{order.discount}</strong></span>
                          )}
                          <span>{lang === 'bn' ? 'ডেলিভারি ফি:' : 'Delivery:'} <strong className="text-[#2D160C]">{order.deliveryFee === 0 ? 'ফ্রি' : `৳${order.deliveryFee}`}</strong></span>
                        </div>

                        <div className="flex items-center gap-1.5 font-bold">
                          <span className="text-[#2D160C]">{lang === 'bn' ? 'সর্বমোট পরিশোধযোগ্য:' : 'Total Payable:'}</span>
                          <span className="font-heading font-black text-base text-[#EA580C] font-mono">
                            ৳{order.total}
                          </span>
                        </div>
                      </div>

                      {/* INTERACTIVE STATUS CONTROLS - EXACT USER REQUIREMENT */}
                      <div className="pt-2 border-t border-[#F2ECE1] space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-[#2D160C] flex items-center gap-1.5">
                            <RefreshCw className="w-3.5 h-3.5 text-[#EA580C]" />
                            <span>{lang === 'bn' ? 'অর্ডার স্ট্যাটাস আপডেট করুন (ক্লিক করলে গ্রাহক তাৎক্ষণিক দেখতে পাবেন):' : 'Update Order Status (Live for Customer):'}</span>
                          </span>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          
                          {/* 1. Processing Button */}
                          <button
                            type="button"
                            onClick={() => handleStatusChange(order.id, 'Processing')}
                            className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs ${
                              order.status === 'Processing'
                                ? 'bg-amber-500 text-white ring-2 ring-amber-300 ring-offset-1 font-black shadow-md'
                                : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 active:scale-95'
                            }`}
                          >
                            <RefreshCw className={`w-3.5 h-3.5 ${order.status === 'Processing' ? 'animate-spin' : ''}`} />
                            <span>{lang === 'bn' ? '🔄 প্রসেসিং (Cooking)' : 'Processing'}</span>
                            {order.status === 'Processing' && <Check className="w-3.5 h-3.5 shrink-0" />}
                          </button>

                          {/* 2. Delivering Button */}
                          <button
                            type="button"
                            onClick={() => handleStatusChange(order.id, 'Delivering')}
                            className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs ${
                              order.status === 'Delivering'
                                ? 'bg-blue-600 text-white ring-2 ring-blue-300 ring-offset-1 font-black shadow-md'
                                : 'bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-300 active:scale-95'
                            }`}
                          >
                            <Truck className="w-3.5 h-3.5" />
                            <span>{lang === 'bn' ? '🚚 ডেলিভারিতে পাঠান' : 'Out for Delivery'}</span>
                            {order.status === 'Delivering' && <Check className="w-3.5 h-3.5 shrink-0" />}
                          </button>

                          {/* 3. Delivered Button */}
                          <button
                            type="button"
                            onClick={() => handleStatusChange(order.id, 'Delivered')}
                            className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs ${
                              order.status === 'Delivered'
                                ? 'bg-green-600 text-white ring-2 ring-green-300 ring-offset-1 font-black shadow-md'
                                : 'bg-green-50 hover:bg-green-100 text-green-900 border border-green-300 active:scale-95'
                            }`}
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>{lang === 'bn' ? '✅ ডেলিভারি সম্পন্ন' : 'Delivered'}</span>
                            {order.status === 'Delivered' && <Check className="w-3.5 h-3.5 shrink-0" />}
                          </button>

                          {/* 4. Cancel / Re-confirm */}
                          {order.status === 'Cancelled' ? (
                            <button
                              type="button"
                              onClick={() => handleStatusChange(order.id, 'Confirmed')}
                              className="py-2 px-2.5 rounded-xl text-xs font-bold bg-gray-100 hover:bg-gray-200 text-gray-800 border border-gray-300 transition-all flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              <span>{lang === 'bn' ? 'পুনরায় সক্রিয় করুন' : 'Reactivate'}</span>
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleStatusChange(order.id, 'Cancelled')}
                              className="py-2 px-2.5 rounded-xl text-xs font-bold bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 transition-all flex items-center justify-center gap-1 cursor-pointer active:scale-95"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>{lang === 'bn' ? 'অর্ডার বাতিল (Cancel)' : 'Cancel Order'}</span>
                            </button>
                          )}

                        </div>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}

          </div>
        )}

        {/* Tab 2: Products Management */}
        {activeTab === 'products' && (
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
            
            {/* Top Product Controls Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-[#EAE4D9] shadow-xs">
              
              {/* Search input */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-[#786154] absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder={lang === 'bn' ? 'পণ্য খুঁজুন (নাম, ক্যাটেগরি)...' : 'Search products...'}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 bg-[#FAF8F5] border border-[#D5C9B8] rounded-lg text-xs text-[#2D160C] focus:outline-none focus:border-[#EA580C]"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAddingNew(!isAddingNew)}
                  className="bg-[#EA580C] hover:bg-[#C2410C] text-white font-bold text-xs py-2 px-3.5 rounded-lg flex items-center gap-1.5 shadow-xs transition-all active:scale-95 cursor-pointer whitespace-nowrap"
                >
                  <Plus className="w-4 h-4" />
                  <span>{lang === 'bn' ? 'নতুন পণ্য যোগ করুন' : 'Add New Product'}</span>
                </button>

                <button
                  onClick={() => {
                    if (window.confirm(lang === 'bn' ? 'আপনি কি আদি ডিফল্ট পণ্যগুলো ফিরিয়ে আনতে চান?' : 'Restore original default products?')) {
                      onResetProducts();
                      showToast(lang === 'bn' ? 'আদি পণ্যসমূহ ফিরিয়ে আনা হয়েছে।' : 'Default products restored.');
                    }
                  }}
                  className="bg-[#FAF8F5] hover:bg-[#EAE4D9] text-[#786154] border border-[#D5C9B8] p-2 rounded-lg transition-colors cursor-pointer"
                  title={lang === 'bn' ? 'ডিফল্ট পণ্য রিস্টোর' : 'Reset to Default'}
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

            </div>

            {/* Add New Product Form (Collapsible) */}
            {isAddingNew && (
              <form
                onSubmit={handleCreateProduct}
                className="bg-white p-4 sm:p-5 rounded-xl border-2 border-[#EA580C] shadow-md space-y-4 animate-in slide-in-from-top-2 duration-150"
              >
                <div className="flex items-center justify-between border-b border-[#F2ECE1] pb-2">
                  <h3 className="font-heading font-extrabold text-sm sm:text-base text-[#2D160C] flex items-center gap-2">
                    <Plus className="w-4 h-4 text-[#EA580C]" />
                    <span>{lang === 'bn' ? 'নতুন খাবার / পণ্য যোগ করার ফর্ম' : 'Create New Food Item'}</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setIsAddingNew(false)}
                    className="text-[#786154] hover:text-[#2D160C] text-xs font-semibold cursor-pointer"
                  >
                    {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {/* Name (Bengali) */}
                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'পণ্যের নাম (বাংলা) *' : 'Product Name (Bengali) *'}
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="যেমন: গ্রিলড হার্ব চিকেন বাওল"
                      value={newProd.nameBn || ''}
                      onChange={(e) => setNewProd({ ...newProd, nameBn: e.target.value })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                    />
                  </div>

                  {/* Name (English) */}
                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'পণ্যের নাম (English) *' : 'Product Name (English) *'}
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Grilled Herb Chicken Bowl"
                      value={newProd.name || ''}
                      onChange={(e) => setNewProd({ ...newProd, name: e.target.value })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                    />
                  </div>

                  {/* Category */}
                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'ক্যাটেগরি *' : 'Category *'}
                    </label>
                    <select
                      value={newProd.category || 'bowls'}
                      onChange={(e) => handleCategorySelect(e.target.value)}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                    >
                      {CATEGORIES.filter((c) => c.id !== 'all').map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.labelBn} ({cat.label})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Weight / Serving size */}
                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'পরিমাণ / ওজন *' : 'Weight / Serving *'}
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="যেমন: 450g / 350ml / 500g"
                      value={newProd.weight || ''}
                      onChange={(e) => setNewProd({ ...newProd, weight: e.target.value })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C]"
                    />
                  </div>

                  {/* Price (Tk) */}
                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'বিক্রয় মূল্য (৳) *' : 'Selling Price (৳) *'}
                    </label>
                    <input
                      type="number"
                      required
                      min={1}
                      placeholder="350"
                      value={newProd.price || ''}
                      onChange={(e) => setNewProd({ ...newProd, price: Number(e.target.value) })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C] font-mono font-bold text-[#EA580C]"
                    />
                  </div>

                  {/* Original / Discount Price */}
                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'আসল মূল্য / ছাড় পূর্বের মূল্য (৳)' : 'Original / Strike-through Price (৳)'}
                    </label>
                    <input
                      type="number"
                      min={0}
                      placeholder="400"
                      value={newProd.originalPrice || ''}
                      onChange={(e) => setNewProd({ ...newProd, originalPrice: Number(e.target.value) })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] focus:outline-none focus:border-[#EA580C] font-mono"
                    />
                  </div>

                  {/* Macro: Protein */}
                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'প্রোটিন (গ্রাম)' : 'Protein (g)'}
                    </label>
                    <input
                      type="number"
                      placeholder="38"
                      value={newProd.protein || ''}
                      onChange={(e) => setNewProd({ ...newProd, protein: Number(e.target.value) })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] font-mono"
                    />
                  </div>

                  {/* Macro: Calories */}
                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'ক্যালোরি (kcal)' : 'Calories (kcal)'}
                    </label>
                    <input
                      type="number"
                      placeholder="520"
                      value={newProd.calories || ''}
                      onChange={(e) => setNewProd({ ...newProd, calories: Number(e.target.value) })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] font-mono"
                    />
                  </div>
                </div>

                {/* Image Selection */}
                <div className="text-xs space-y-1.5">
                  <label className="font-bold text-[#2D160C] block">
                    {lang === 'bn' ? 'ছবির লিংক / প্রিসেট নির্বাচন' : 'Image URL / Preset'}
                  </label>
                  <div className="flex flex-wrap gap-1.5 pb-1">
                    {PRESET_IMAGES.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setNewProd({ ...newProd, image: preset.url })}
                        className={`px-2 py-1 rounded text-[10px] font-semibold border transition-colors cursor-pointer ${
                          newProd.image === preset.url
                            ? 'bg-[#EA580C] text-white border-[#EA580C]'
                            : 'bg-[#FAF8F5] text-[#5C4537] border-[#D5C9B8] hover:bg-[#F2ECE1]'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    placeholder="অথবা কাস্টম ছবির URL দিন"
                    value={newProd.image || ''}
                    onChange={(e) => setNewProd({ ...newProd, image: e.target.value })}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] font-mono text-[11px]"
                  />
                </div>

                {/* Description (Bengali) */}
                <div className="text-xs">
                  <label className="font-bold text-[#2D160C] block mb-1">
                    {lang === 'bn' ? 'খাবারের বিবরণ (বাংলা) *' : 'Description (Bengali) *'}
                  </label>
                  <textarea
                    rows={2}
                    placeholder="খাবারের স্বাস্থ্যকর বৈশিষ্ট্য, স্বাদ এবং উপকারের বর্ণনা..."
                    value={newProd.descriptionBn || ''}
                    onChange={(e) => setNewProd({ ...newProd, descriptionBn: e.target.value })}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5]"
                  />
                </div>

                {/* Description (English) */}
                <div className="text-xs">
                  <label className="font-bold text-[#2D160C] block mb-1">
                    {lang === 'bn' ? 'খাবারের বিবরণ (English)' : 'Description (English)'}
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Healthy fitness meal description..."
                    value={newProd.description || ''}
                    onChange={(e) => setNewProd({ ...newProd, description: e.target.value })}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5]"
                  />
                </div>

                {/* Badges Toggle */}
                <div className="flex items-center gap-6 text-xs font-semibold text-[#2D160C]">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={Boolean(newProd.isPopular)}
                      onChange={(e) => setNewProd({ ...newProd, isPopular: e.target.checked })}
                      className="rounded text-[#EA580C] focus:ring-[#EA580C]"
                    />
                    <span>{lang === 'bn' ? 'জনপ্রিয় / বেস্টসেলার ব্যাজ' : 'Popular / Bestseller Badge'}</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={Boolean(newProd.isNew)}
                      onChange={(e) => setNewProd({ ...newProd, isNew: e.target.checked })}
                      className="rounded text-[#16A34A] focus:ring-[#16A34A]"
                    />
                    <span>{lang === 'bn' ? 'নতুন আইটেম ব্যাজ' : 'New Item Badge'}</span>
                  </label>
                </div>

                {/* Submit Action */}
                <div className="flex justify-end gap-2 pt-2 border-t border-[#F2ECE1]">
                  <button
                    type="button"
                    onClick={() => setIsAddingNew(false)}
                    className="px-4 py-2 rounded-lg border border-[#D5C9B8] text-xs font-bold text-[#786154] hover:bg-[#FAF8F5] cursor-pointer"
                  >
                    {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="bg-[#EA580C] hover:bg-[#C2410C] text-white font-bold text-xs py-2 px-5 rounded-lg flex items-center gap-1.5 shadow-sm cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>{lang === 'bn' ? 'পণ্য সেভ করুন' : 'Save Product'}</span>
                  </button>
                </div>
              </form>
            )}

            {/* Edit Existing Product Inline Form */}
            {editingProduct && (
              <form
                onSubmit={handleSaveEditProduct}
                className="bg-amber-50/50 p-4 sm:p-5 rounded-xl border-2 border-[#D97706] shadow-md space-y-4 animate-in slide-in-from-top-2 duration-150"
              >
                <div className="flex items-center justify-between border-b border-amber-200 pb-2">
                  <h3 className="font-heading font-extrabold text-sm sm:text-base text-[#2D160C] flex items-center gap-2">
                    <Edit2 className="w-4 h-4 text-[#D97706]" />
                    <span>
                      {lang === 'bn'
                        ? `সম্পাদনা করুন: ${editingProduct.nameBn}`
                        : `Edit Product: ${editingProduct.name}`}
                    </span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setEditingProduct(null)}
                    className="text-[#786154] hover:text-[#2D160C] text-xs font-semibold cursor-pointer"
                  >
                    {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'পণ্যের নাম (বাংলা) *' : 'Name (Bengali) *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={editingProduct.nameBn}
                      onChange={(e) => setEditingProduct({ ...editingProduct, nameBn: e.target.value })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-white"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'পণ্যের নাম (English) *' : 'Name (English) *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={editingProduct.name}
                      onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-white"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'ক্যাটেগরি *' : 'Category *'}
                    </label>
                    <select
                      value={editingProduct.category}
                      onChange={(e) => handleCategorySelect(e.target.value, true)}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-white"
                    >
                      {CATEGORIES.filter((c) => c.id !== 'all').map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.labelBn} ({cat.label})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'পরিমাণ / ওজন' : 'Weight / Size'}
                    </label>
                    <input
                      type="text"
                      value={editingProduct.weight}
                      onChange={(e) => setEditingProduct({ ...editingProduct, weight: e.target.value })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-white"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'বিক্রয় মূল্য (৳) *' : 'Price (৳) *'}
                    </label>
                    <input
                      type="number"
                      required
                      value={editingProduct.price}
                      onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-white font-mono font-bold text-[#EA580C]"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'আসল মূল্য / ছাড় পূর্বের মূল্য (৳)' : 'Original Price (৳)'}
                    </label>
                    <input
                      type="number"
                      value={editingProduct.originalPrice || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, originalPrice: Number(e.target.value) || undefined })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'প্রোটিন (g)' : 'Protein (g)'}
                    </label>
                    <input
                      type="number"
                      value={editingProduct.protein}
                      onChange={(e) => setEditingProduct({ ...editingProduct, protein: Number(e.target.value) })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-[#2D160C] block mb-1">
                      {lang === 'bn' ? 'ক্যালোরি' : 'Calories'}
                    </label>
                    <input
                      type="number"
                      value={editingProduct.calories}
                      onChange={(e) => setEditingProduct({ ...editingProduct, calories: Number(e.target.value) })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-white font-mono"
                    />
                  </div>
                </div>

                <div className="text-xs">
                  <label className="font-bold text-[#2D160C] block mb-1">
                    {lang === 'bn' ? 'ছবির URL' : 'Image URL'}
                  </label>
                  <input
                    type="text"
                    value={editingProduct.image}
                    onChange={(e) => setEditingProduct({ ...editingProduct, image: e.target.value })}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-white font-mono text-[11px]"
                  />
                </div>

                <div className="text-xs">
                  <label className="font-bold text-[#2D160C] block mb-1">
                    {lang === 'bn' ? 'বিবরণ (বাংলা)' : 'Description (Bengali)'}
                  </label>
                  <textarea
                    rows={2}
                    value={editingProduct.descriptionBn}
                    onChange={(e) => setEditingProduct({ ...editingProduct, descriptionBn: e.target.value })}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-white"
                  />
                </div>

                <div className="flex items-center gap-6 text-xs font-semibold text-[#2D160C]">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={Boolean(editingProduct.isPopular)}
                      onChange={(e) => setEditingProduct({ ...editingProduct, isPopular: e.target.checked })}
                    />
                    <span>{lang === 'bn' ? 'বেস্টসেলার' : 'Bestseller'}</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={Boolean(editingProduct.isNew)}
                      onChange={(e) => setEditingProduct({ ...editingProduct, isNew: e.target.checked })}
                    />
                    <span>{lang === 'bn' ? 'নতুন আইটেম' : 'New'}</span>
                  </label>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-amber-200">
                  <button
                    type="button"
                    onClick={() => setEditingProduct(null)}
                    className="px-4 py-2 rounded-lg border border-[#D5C9B8] text-xs font-bold text-[#786154] hover:bg-white cursor-pointer"
                  >
                    {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="bg-[#D97706] hover:bg-[#B45309] text-white font-bold text-xs py-2 px-5 rounded-lg flex items-center gap-1.5 shadow-sm cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>{lang === 'bn' ? 'পরিবর্তন সংরক্ষণ করুন' : 'Update Product'}</span>
                  </button>
                </div>
              </form>
            )}

            {/* Products List Table / Cards */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-[#786154] px-1">
                <span>
                  {lang === 'bn' ? `তালিকায় মোট পণ্য: ${filtered.length} টি` : `Total items: ${filtered.length}`}
                </span>
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm('')}
                    className="text-[#EA580C] underline cursor-pointer"
                  >
                    {lang === 'bn' ? 'ক্লিয়ার ফিল্টার' : 'Clear filter'}
                  </button>
                )}
              </div>

              {filtered.map((prod) => (
                <div
                  key={prod.id}
                  className="bg-white p-3 sm:p-4 rounded-xl border border-[#EAE4D9] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs hover:border-[#D5C9B8] transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={prod.image}
                      alt={prod.name}
                      className="w-14 h-14 rounded-lg object-cover border border-[#EAE4D9] shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-heading font-bold text-sm text-[#2D160C]">
                          {prod.nameBn}
                        </span>
                        <span className="text-[10px] bg-[#FAF8F5] text-[#786154] px-2 py-0.5 rounded border border-[#EAE4D9] font-medium">
                          {prod.categoryLabelBn}
                        </span>
                        {prod.isPopular && (
                          <span className="text-[9px] bg-[#2D160C] text-white px-1.5 py-0.2 rounded font-bold">
                            বেস্টসেলার
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-[#786154] font-medium mt-0.5">
                        {prod.name} · {prod.weight} · <strong className="text-[#EA580C]">{prod.protein}g প্রোটিন</strong>
                      </div>
                      <div className="flex items-baseline gap-2 mt-1">
                        <span className="font-mono font-bold text-sm text-[#2D160C] tabular-nums">
                          ৳{prod.price}
                        </span>
                        {prod.originalPrice && (
                          <span className="text-[11px] text-[#9E8B7F] line-through font-mono">
                            ৳{prod.originalPrice}
                          </span>
                        )}
                        {prod.originalPrice && prod.originalPrice > prod.price && (
                          <span className="text-[10px] text-[#16A34A] font-bold">
                            (৳{prod.originalPrice - prod.price} ছাড়)
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      onClick={() => setEditingProduct(prod)}
                      className="bg-[#FAF8F5] hover:bg-[#F2ECE1] text-[#2D160C] border border-[#D5C9B8] px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-[#D97706]" />
                      <span>{lang === 'bn' ? 'এডিট' : 'Edit'}</span>
                    </button>

                    <button
                      onClick={() => {
                        if (window.confirm(lang === 'bn' ? `আপনি কি নিশ্চিতভাবে "${prod.nameBn}" পণ্যটি মুছে ফেলতে চান?` : `Delete "${prod.name}"?`)) {
                          onDeleteProduct(prod.id);
                          showToast(lang === 'bn' ? `"${prod.nameBn}" মুছে ফেলা হয়েছে!` : `Product deleted.`);
                        }
                      }}
                      className="bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{lang === 'bn' ? 'মুছে ফেলুন' : 'Delete'}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* Tab 2: Delivery & Discount Settings */}
        {activeTab === 'settings' && (
          <form onSubmit={handleSaveSettings} className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-5">
            
            {/* Top Banner Notice Settings */}
            <div className="bg-white p-4 sm:p-5 rounded-xl border border-[#EAE4D9] space-y-4 shadow-xs">
              <h3 className="font-heading font-extrabold text-sm sm:text-base text-[#2D160C] flex items-center gap-2 border-b border-[#F2ECE1] pb-2">
                <Sparkles className="w-4 h-4 text-[#D97706]" />
                <span>{lang === 'bn' ? 'টপ ব্যানার নোটিশ সেটিংস' : 'Top Banner Notice Settings'}</span>
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="font-bold text-[#2D160C] block mb-1">
                    {lang === 'bn' ? 'ব্যানার নোটিশ (বাংলা)' : 'Banner Notice (Bengali)'}
                  </label>
                  <input
                    type="text"
                    value={editSettings.bannerNoticeBn || ''}
                    onChange={(e) => setEditSettings({ ...editSettings, bannerNoticeBn: e.target.value })}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] text-xs font-medium"
                    placeholder="পার্বতীপুরে হোম ডেলিভারি মাত্র ১০০ টাকা · ১৫০০ টাকার অর্ডারে ফ্রি!"
                  />
                </div>

                <div>
                  <label className="font-bold text-[#2D160C] block mb-1">
                    {lang === 'bn' ? 'ব্যানার নোটিশ (English)' : 'Banner Notice (English)'}
                  </label>
                  <input
                    type="text"
                    value={editSettings.bannerNoticeEn || ''}
                    onChange={(e) => setEditSettings({ ...editSettings, bannerNoticeEn: e.target.value })}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] text-xs font-medium"
                    placeholder="Parbatipur delivery ৳100 · FREE delivery on orders over ৳1500!"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white p-4 sm:p-5 rounded-xl border border-[#EAE4D9] space-y-4 shadow-xs">
              <h3 className="font-heading font-extrabold text-sm sm:text-base text-[#2D160C] flex items-center gap-2 border-b border-[#F2ECE1] pb-2">
                <Truck className="w-4 h-4 text-[#EA580C]" />
                <span>{lang === 'bn' ? 'হোম ডেলিভারি চার্জ সেটিংস' : 'Delivery Charges'}</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="font-bold text-[#2D160C] block mb-1">
                    {lang === 'bn' ? 'পার্বতীপুর ডেলিভারি চার্জ (৳)' : 'Parbatipur Delivery Fee (৳)'}
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      required
                      min={0}
                      value={editSettings.parbatipurDelivery}
                      onChange={(e) => setEditSettings({ ...editSettings, parbatipurDelivery: Number(e.target.value) })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] font-mono font-bold text-sm text-[#2D160C]"
                    />
                    <span className="absolute right-3 top-2 text-[#786154] font-bold">টাকা</span>
                  </div>
                  <span className="text-[11px] text-[#786154] mt-1 block">
                    ডিফল্ট: ১০০৳ (পার্বতীপুর থানা এলাকার গ্রাহকদের জন্য)
                  </span>
                </div>

                <div>
                  <label className="font-bold text-[#2D160C] block mb-1">
                    {lang === 'bn' ? 'পার্বতীপুরের বাইরে সারাদেশে ডেলিভারি চার্জ (৳)' : 'Outside Delivery Fee (৳)'}
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      required
                      min={0}
                      value={editSettings.outsideDelivery}
                      onChange={(e) => setEditSettings({ ...editSettings, outsideDelivery: Number(e.target.value) })}
                      className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] font-mono font-bold text-sm text-[#2D160C]"
                    />
                    <span className="absolute right-3 top-2 text-[#786154] font-bold">টাকা</span>
                  </div>
                  <span className="text-[11px] text-[#786154] mt-1 block">
                    ডিফল্ট: ১২০৳ (অন্যান্য সকল জেলা ও থানার জন্য)
                  </span>
                </div>
              </div>

              <div className="pt-2">
                <label className="font-bold text-[#2D160C] block mb-1 text-xs">
                  {lang === 'bn' ? 'ফ্রি ডেলিভারির ন্যূনতম অর্ডার মূল্য (৳)' : 'Free Delivery Order Threshold (৳)'}
                </label>
                <div className="relative max-w-sm">
                  <input
                    type="number"
                    required
                    min={0}
                    value={editSettings.freeDeliveryThreshold}
                    onChange={(e) => setEditSettings({ ...editSettings, freeDeliveryThreshold: Number(e.target.value) })}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] font-mono font-bold text-sm text-[#16A34A]"
                  />
                  <span className="absolute right-3 top-2 text-[#786154] font-bold">টাকা</span>
                </div>
                <span className="text-[11px] text-[#786154] mt-1 block">
                  গ্রাহক এই পরিমাণের বা তার বেশি অর্ডার করলে স্বয়ংক্রিয়ভাবে ডেলিভারি ফ্রি হবে (বর্তমান: ১৫০০৳)।
                </span>
              </div>
            </div>

            <div className="bg-white p-4 sm:p-5 rounded-xl border border-[#EAE4D9] space-y-4 shadow-xs">
              <h3 className="font-heading font-extrabold text-sm sm:text-base text-[#2D160C] flex items-center gap-2 border-b border-[#F2ECE1] pb-2">
                <DollarSign className="w-4 h-4 text-[#16A34A]" />
                <span>{lang === 'bn' ? 'বান্ডেল ও ডিসকাউন্ট পলিসি' : 'Discount Policies'}</span>
              </h3>

              <div className="max-w-sm text-xs">
                <label className="font-bold text-[#2D160C] block mb-1">
                  {lang === 'bn' ? '৩টি বা ততোধিক আইটেমে ছাড়ের হার (%)' : 'Discount for 3+ items (%)'}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    required
                    min={0}
                    max={100}
                    value={editSettings.bundleDiscountPct}
                    onChange={(e) => setEditSettings({ ...editSettings, bundleDiscountPct: Number(e.target.value) })}
                    className="w-full p-2 border border-[#D5C9B8] rounded-lg bg-[#FAF8F5] font-mono font-bold text-sm text-[#EA580C]"
                  />
                  <span className="absolute right-3 top-2 text-[#786154] font-bold">%</span>
                </div>
                <span className="text-[11px] text-[#786154] mt-1 block">
                  কার্টে ৩টি বা তার বেশি খাবার থাকলে গ্রাহক স্বয়ংক্রিয়ভাবে এই শতাংশ ছাড় পাবেন (ডিফল্ট: ১০%)।
                </span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="submit"
                className="bg-[#EA580C] hover:bg-[#C2410C] active:scale-95 text-white font-bold text-xs py-2.5 px-6 rounded-xl flex items-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>{lang === 'bn' ? 'সব সেটিংস সংরক্ষণ করুন' : 'Save All Settings'}</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
