import React from 'react';
import { Dumbbell, Utensils, Wheat, Leaf, Palette } from 'lucide-react';

interface BrandStoryProps {
  lang: 'bn' | 'en';
}

export const BrandStory: React.FC<BrandStoryProps> = ({ lang }) => {
  const elements = [
    {
      icon: Dumbbell,
      color: 'text-[#EA580C] bg-[#EA580C]/10',
      title: lang === 'bn' ? 'শক্তিশালী বাইসেপ (Strength & Fuel)' : 'Muscular Arm (Strength & Fuel)',
      desc: lang === 'bn'
        ? 'শরীরচর্চা, অ্যাথলেটিক্স ও পেশিবহুল সুঠাম স্বাস্থ্যের জন্য উচ্চমানের প্রোটিনের প্রতীক।'
        : 'Symbolizes physical power, fitness dedication, and high-protein nutrition for athletes.',
    },
    {
      icon: Utensils,
      color: 'text-[#2D160C] bg-[#2D160C]/10',
      title: lang === 'bn' ? 'পুষ্টিকর খাবারের বাওল ও কাঁটাচামচ' : 'Gourmet Food Bowl & Fork',
      desc: lang === 'bn'
        ? 'শুধু ডায়েট নয়, বরং অত্যন্ত সুস্বাদু, শেফ-প্রস্তুতকৃত ভারসাম্যপূর্ণ পুষ্টিকর মিল।'
        : 'Proves healthy food can be culinary art—delicious, hearty, and meticulously macro-balanced.',
    },
    {
      icon: Wheat,
      color: 'text-[#D97706] bg-[#D97706]/10',
      title: lang === 'bn' ? 'সোনালী গমের শিষ (Whole Grains)' : 'Golden Wheat Ear (Whole Grains)',
      desc: lang === 'bn'
        ? 'প্রাকৃতিক জটিল শর্করা (complex carbs), ফাইবার ও দীর্ঘস্থায়ী শক্তির উৎস।'
        : 'Represents slow-burning energy from unrefined whole grains, oats, and superfood seeds.',
    },
    {
      icon: Leaf,
      color: 'text-[#16A34A] bg-[#16A34A]/10',
      title: lang === 'bn' ? 'সবুজ পাতা (১০০% অর্গানিক পিউরিটি)' : 'Green Leaf (100% Organic Purity)',
      desc: lang === 'bn'
        ? 'কোনো প্রিজারভেটিভ বা কেমিক্যাল ছাড়া প্রাকৃতিক বিশুদ্ধতার নিশ্চয়তা।'
        : 'Guarantees unadulterated freshness, zero artificial chemicals, and farm-to-table cleanliness.',
    },
  ];

  return (
    <section id="story" className="py-14 bg-[#FAF8F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-2">
          <div className="text-xs font-bold text-[#EA580C] uppercase tracking-wider">
            {lang === 'bn' ? 'লোগো ও ব্র্যান্ড ফিলোসফি' : 'Logo & Brand Identity'}
          </div>
          <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-[#2D160C]">
            {lang === 'bn' ? 'মুতাযযি ফুডস লোগোর পেছনের তাৎপর্য' : 'The Meaning Behind the Mutazzi Foods Identity'}
          </h2>
          <p className="text-xs sm:text-sm text-[#786154] leading-relaxed">
            {lang === 'bn'
              ? 'লোগোটিতে শারীরিক শক্তি এবং প্রাকৃতিক বিশুদ্ধ খাবারকে একত্রিত করে একটি পেশাদার ব্র্যান্ড হিসেবে উপস্থাপন করা হয়েছে।'
              : 'Our mark unites raw athletic strength with wholesome organic nourishment in a harmonious, memorable emblem.'}
          </p>
        </div>

        {/* 2-Column Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Logo Showcase Left (5 cols) */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-3xl bg-white border border-[#E0D5C5] shadow-xl p-6 flex flex-col items-center justify-center group">
              <img
                src="/assets/aistudio/IMG_20261027_161503_c549d1c8.png"
                alt="Mutazzi Foods Brand Mark"
                className="w-full h-full object-contain transition-transform duration-300 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-3 bg-[#2D160C] text-[#FAF8F5] text-[11px] font-bold px-3 py-1 rounded-full shadow-md">
                Official Brand Seal
              </div>
            </div>

            {/* Professional Color Palette Bar */}
            <div className="w-full max-w-xs mt-8 bg-white p-3 rounded-xl border border-[#EAE4D9] shadow-xs space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#2D160C]">
                <Palette className="w-3.5 h-3.5 text-[#EA580C]" />
                <span>{lang === 'bn' ? 'ব্র্যান্ড কালার প্যালেট' : 'Brand Color Palette'}</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5 text-center text-[10px] font-mono">
                <div className="p-1.5 rounded bg-[#2D160C] text-white font-bold">
                  <div>Espresso</div>
                  <div className="opacity-75 text-[8px]">#2D160C</div>
                </div>
                <div className="p-1.5 rounded bg-[#EA580C] text-white font-bold">
                  <div>Orange</div>
                  <div className="opacity-75 text-[8px]">#EA580C</div>
                </div>
                <div className="p-1.5 rounded bg-[#16A34A] text-white font-bold">
                  <div>Leaf</div>
                  <div className="opacity-75 text-[8px]">#16A34A</div>
                </div>
                <div className="p-1.5 rounded bg-[#D97706] text-white font-bold">
                  <div>Wheat</div>
                  <div className="opacity-75 text-[8px]">#D97706</div>
                </div>
              </div>
            </div>
          </div>

          {/* 4 Pillars Grid Right (7 cols) */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {elements.map((item, idx) => {
              const Icon = item.icon;
              return (
                <div
                  key={idx}
                  className="bg-white p-4 sm:p-5 rounded-2xl border border-[#EAE4D9] shadow-xs space-y-2 hover:border-[#EA580C]/40 transition-colors"
                >
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${item.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-heading font-bold text-sm text-[#2D160C]">
                    {item.title}
                  </h3>
                  <p className="text-xs text-[#5C4537] leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              );
            })}
          </div>

        </div>

      </div>
    </section>
  );
};
