import React from 'react';
import { ArrowRight, Flame, ShieldCheck, Truck, Sparkles } from 'lucide-react';

interface HeroProps {
  lang: 'bn' | 'en';
  onExploreClick: () => void;
  onCalculatorClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ lang, onExploreClick, onCalculatorClick }) => {
  return (
    <section className="relative overflow-hidden pt-6 pb-12 lg:pt-10 lg:pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Responsive Grid: 1 col on mobile, 2 cols on lg desktop */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column (Content & Action) - 7 cols on lg */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Unboxed Metadata (Zero-Pill discipline) */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-[#786154]">
              <span className="flex items-center gap-1 text-[#EA580C]">
                <Flame className="w-3.5 h-3.5 fill-[#EA580C]" />
                {lang === 'bn' ? 'হাই-প্রোটিন ফিটনেস ডায়েট' : 'High-Protein Fitness Nutrition'}
              </span>
              <span aria-hidden="true" className="text-[#C5B8A8]">·</span>
              <span>{lang === 'bn' ? '১০০% অর্গানিক উপাদান' : '100% Clean Ingredients'}</span>
              <span aria-hidden="true" className="text-[#C5B8A8]">·</span>
              <span>{lang === 'bn' ? 'কোনো রিফাইন্ড সুগার নেই' : '0% Refined Sugar'}</span>
            </div>

            {/* Display Headline */}
            <h1 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl tracking-tight text-[#2D160C] leading-[1.15]" style={{ textWrap: 'balance' }}>
              {lang === 'bn' ? (
                <>
                  পেশির দৃঢ় শক্তি ও খাঁটি স্বাস্থ্য—
                  <span className="text-[#EA580C] underline decoration-[#EA580C]/30 decoration-wavy">
                    মুতাযযি ফুডস
                  </span>
                  -এর সাথে
                </>
              ) : (
                <>
                  Power Your Strength with Pure{' '}
                  <span className="text-[#EA580C] underline decoration-[#EA580C]/30 decoration-wavy">
                    Organic Nutrition
                  </span>
                </>
              )}
            </h1>

            {/* Body Description */}
            <p className="text-base sm:text-lg text-[#5C4537] leading-relaxed max-w-2xl font-normal">
              {lang === 'bn'
                ? 'ব্যায়ামবীর, অ্যাথলেট এবং স্বাস্থ্যসচেতন প্রতিটি মানুষের জন্য প্রস্তুতকৃত পুষ্টিকর পাওয়ার মিলস, প্রোটিন নাট বাটার, সুপারফুড গ্রানোলা ও সুন্দরবনের বুনো র মধু। খাঁটি উপাদানে স্বাস্থ্যকর জীবনের অঙ্গীকার।'
                : 'Formulated for athletes, fitness enthusiasts, and conscious eaters. Chef-prepared gourmet protein power bowls, stone-ground nut butters, superfood granola, and raw forest honey.'}
            </p>

            {/* CTA Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <button
                onClick={onExploreClick}
                className="bg-[#EA580C] hover:bg-[#C2410C] active:scale-95 text-white font-bold py-3.5 px-6 rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer group"
              >
                <span>{lang === 'bn' ? 'পণ্য দেখুন ও অর্ডার দিন' : 'Order Power Foods'}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              <button
                onClick={onCalculatorClick}
                className="bg-white hover:bg-[#F5EFE6] text-[#2D160C] border border-[#D5C9B8] font-bold py-3.5 px-6 rounded-xl shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-[#EA580C]" />
                <span>{lang === 'bn' ? 'ম্যাক্রো পুষ্টি পরিমাপ' : 'Calculate My Macros'}</span>
              </button>
            </div>

            {/* Trust Markers Bar (Zero horizontal scroll, responsive 3-column layout) */}
            <div className="grid grid-cols-3 gap-2 sm:gap-4 pt-6 border-t border-[#EAE4D9] w-full max-w-full overflow-hidden">
              <div className="space-y-0.5 min-w-0">
                <div className="font-heading font-extrabold text-base sm:text-xl text-[#2D160C] truncate">
                  42g+
                </div>
                <div className="text-[11px] sm:text-xs text-[#786154] font-medium leading-tight">
                  {lang === 'bn' ? 'প্রতি মিলে প্রোটিন' : 'Protein per Meal'}
                </div>
              </div>

              <div className="space-y-0.5 min-w-0">
                <div className="font-heading font-extrabold text-base sm:text-xl text-[#16A34A] truncate">
                  100%
                </div>
                <div className="text-[11px] sm:text-xs text-[#786154] font-medium leading-tight">
                  {lang === 'bn' ? 'অর্গানিক ও ফ্রেশ' : 'Organic & Fresh'}
                </div>
              </div>

              <div className="space-y-0.5 min-w-0">
                <div className="font-heading font-extrabold text-base sm:text-xl text-[#D97706] truncate">
                  ১০০/১২০৳
                </div>
                <div className="text-[11px] sm:text-xs text-[#786154] font-medium leading-tight">
                  {lang === 'bn' ? 'হোম ডেলিভারি' : 'Fast Delivery'}
                </div>
              </div>
            </div>

          </div>

          {/* Right Column (Hero Visual Anchor) - 5 cols on lg */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#E0D5C5] shadow-xl bg-white group">
              <img
                src="/src/assets/images/hero_mutazzi_healthy_bowl_1793165771441.jpg"
                alt="Mutazzi Foods Gourmet High-Protein Bowl"
                className="w-full h-80 sm:h-96 lg:h-[420px] object-cover transition-transform duration-500 group-hover:scale-102"
                referrerPolicy="no-referrer"
              />
              
              {/* Subtle Gradient Scrim at bottom */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

              {/* Bottom Caption Overlay */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-white">
                <div>
                  <div className="text-xs font-semibold text-[#FB923C] uppercase tracking-wider">
                    {lang === 'bn' ? 'সিগনেচার বাওল' : 'Signature Bowl'}
                  </div>
                  <div className="font-heading font-bold text-base sm:text-lg">
                    {lang === 'bn' ? 'গ্রিলড হার্ব চিকেন ও কিনোয়া' : 'Grilled Herb Chicken & Quinoa'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-white/80">{lang === 'bn' ? 'ক্যালোরি' : 'Energy'}</div>
                  <div className="font-mono font-bold text-sm text-[#FB923C]">540 kcal</div>
                </div>
              </div>

            </div>

            {/* Background subtle warm glow */}
            <div className="absolute -z-10 -bottom-6 -right-6 w-64 h-64 bg-[#EA580C]/10 rounded-full blur-3xl pointer-events-none" />
          </div>

        </div>

      </div>
    </section>
  );
};
