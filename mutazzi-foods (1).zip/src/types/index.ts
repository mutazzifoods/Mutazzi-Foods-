export interface Product {
  id: string;
  name: string;
  nameBn: string;
  category: 'bowls' | 'butters' | 'granola' | 'honey' | 'drinks';
  categoryLabel: string;
  categoryLabelBn: string;
  price: number;
  originalPrice?: number;
  image: string;
  description: string;
  descriptionBn: string;
  protein: number; // in grams
  calories: number; // kcal
  carbs: number; // grams
  fats: number; // grams
  weight: string;
  isPopular?: boolean;
  isNew?: boolean;
  ingredients: string[];
  ingredientsBn: string[];
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  date: string;
  customerName: string;
  phone: string;
  address: string;
  deliveryZone: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  deliveryFee: number;
  total: number;
  paymentMethod: 'cod' | 'bkash' | 'nagad';
  status: 'Pending' | 'Confirmed' | 'Processing' | 'Delivering' | 'Delivered' | 'Cancelled';
  userId?: string;
  userEmail?: string;
  isGuest?: boolean;
  estimatedDelivery?: string;
  cancelledAt?: string;
  updatedAt?: string;
}
