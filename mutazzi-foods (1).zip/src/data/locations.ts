export interface DistrictOption {
  id: string;
  name: string;
  nameBn: string;
}

export interface ThanaOption {
  id: string;
  districtId: string;
  name: string;
  nameBn: string;
  deliveryFee: number;
}

export const DISTRICTS: DistrictOption[] = [
  { id: 'dinajpur', name: 'Dinajpur', nameBn: 'দিনাজপুর' },
  { id: 'dhaka', name: 'Dhaka', nameBn: 'ঢাকা' },
  { id: 'rangpur', name: 'Rangpur', nameBn: 'রংপুর' },
  { id: 'nilphamari', name: 'Nilphamari', nameBn: 'নীলফামারী' },
  { id: 'bogura', name: 'Bogura', nameBn: 'বগুড়া' },
  { id: 'rajshahi', name: 'Rajshahi', nameBn: 'রাজশাহী' },
  { id: 'chattogram', name: 'Chattogram', nameBn: 'চট্টগ্রাম' },
  { id: 'sylhet', name: 'Sylhet', nameBn: 'সিলেট' },
  { id: 'kurigram', name: 'Kurigram', nameBn: 'কুড়িগ্রাম' },
  { id: 'lalmonirhat', name: 'Lalmonirhat', nameBn: 'লালমনিরহাট' },
  { id: 'panchagarh', name: 'Panchagarh', nameBn: 'পঞ্চগড়' },
  { id: 'thakurgaon', name: 'Thakurgaon', nameBn: 'ঠাকুরগাঁও' },
  { id: 'other', name: 'Other Districts', nameBn: 'অন্যান্য জেলা' },
];

export const THANAS: ThanaOption[] = [
  // Dinajpur
  { id: 'parbatipur', districtId: 'dinajpur', name: 'Parbatipur', nameBn: 'পার্বতীপুর', deliveryFee: 100 },
  { id: 'chirirbandar', districtId: 'dinajpur', name: 'Chirirbandar', nameBn: 'চিরিরবন্দর', deliveryFee: 120 },
  { id: 'dinajpur_sadar', districtId: 'dinajpur', name: 'Dinajpur Sadar', nameBn: 'দিনাজপুর সদর', deliveryFee: 120 },
  { id: 'fulbari', districtId: 'dinajpur', name: 'Fulbari', nameBn: 'ফুলবাড়ী', deliveryFee: 120 },
  { id: 'birganj', districtId: 'dinajpur', name: 'Birganj', nameBn: 'বীরগঞ্জ', deliveryFee: 120 },
  { id: 'birampur', districtId: 'dinajpur', name: 'Birampur', nameBn: 'বিরামপুর', deliveryFee: 120 },
  { id: 'nawabganj', districtId: 'dinajpur', name: 'Nawabganj', nameBn: 'নবাবগঞ্জ', deliveryFee: 120 },
  { id: 'hakimpur', districtId: 'dinajpur', name: 'Hakimpur (Hili)', nameBn: 'হাকিমপুর (হিলি)', deliveryFee: 120 },
  { id: 'kaharole', districtId: 'dinajpur', name: 'Kaharole', nameBn: 'কাহারোল', deliveryFee: 120 },
  { id: 'khansama', districtId: 'dinajpur', name: 'Khansama', nameBn: 'খানসামা', deliveryFee: 120 },
  { id: 'ghoraghat', districtId: 'dinajpur', name: 'Ghoraghat', nameBn: 'ঘোড়াঘাট', deliveryFee: 120 },
  { id: 'bochaganj', districtId: 'dinajpur', name: 'Bochaganj', nameBn: 'বোচাগঞ্জ', deliveryFee: 120 },

  // Dhaka
  { id: 'dhaka_dhanmondi', districtId: 'dhaka', name: 'Dhanmondi', nameBn: 'ধানমন্ডি', deliveryFee: 120 },
  { id: 'dhaka_mirpur', districtId: 'dhaka', name: 'Mirpur', nameBn: 'মিরপুর', deliveryFee: 120 },
  { id: 'dhaka_gulshan', districtId: 'dhaka', name: 'Gulshan / Banani', nameBn: 'গুলশান / বনানী', deliveryFee: 120 },
  { id: 'dhaka_uttara', districtId: 'dhaka', name: 'Uttara', nameBn: 'উত্তরা', deliveryFee: 120 },
  { id: 'dhaka_mohammadpur', districtId: 'dhaka', name: 'Mohammadpur', nameBn: 'মোহাম্মদপুর', deliveryFee: 120 },
  { id: 'dhaka_motijheel', districtId: 'dhaka', name: 'Motijheel / Old Dhaka', nameBn: 'মতিঝিল / পুরান ঢাকা', deliveryFee: 120 },
  { id: 'dhaka_savar', districtId: 'dhaka', name: 'Savar', nameBn: 'সাভার', deliveryFee: 120 },
  { id: 'dhaka_other', districtId: 'dhaka', name: 'Other Thana in Dhaka', nameBn: 'ঢাকার অন্যান্য থানা', deliveryFee: 120 },

  // Rangpur
  { id: 'rangpur_sadar', districtId: 'rangpur', name: 'Rangpur Sadar', nameBn: 'রংপুর সদর', deliveryFee: 120 },
  { id: 'badarganj', districtId: 'rangpur', name: 'Badarganj', nameBn: 'বদরগঞ্জ', deliveryFee: 120 },
  { id: 'pirganj', districtId: 'rangpur', name: 'Pirganj', nameBn: 'পীরগঞ্জ', deliveryFee: 120 },
  { id: 'taraganj', districtId: 'rangpur', name: 'Taraganj', nameBn: 'তারাগঞ্জ', deliveryFee: 120 },
  { id: 'mithapukur', districtId: 'rangpur', name: 'Mithapukur', nameBn: 'মিঠাপুকুর', deliveryFee: 120 },

  // Nilphamari
  { id: 'nilphamari_sadar', districtId: 'nilphamari', name: 'Nilphamari Sadar', nameBn: 'নীলফামারী সদর', deliveryFee: 120 },
  { id: 'saidpur', districtId: 'nilphamari', name: 'Saidpur', nameBn: 'সৈয়দপুর', deliveryFee: 120 },
  { id: 'kishorganj_nil', districtId: 'nilphamari', name: 'Kishorganj', nameBn: 'কিশোরগঞ্জ (নীলফামারী)', deliveryFee: 120 },

  // Bogura
  { id: 'bogura_sadar', districtId: 'bogura', name: 'Bogura Sadar', nameBn: 'বগুড়া সদর', deliveryFee: 120 },
  { id: 'sherpur_bog', districtId: 'bogura', name: 'Sherpur', nameBn: 'শেরপুর (বগুড়া)', deliveryFee: 120 },

  // Other Districts generic thana
  { id: 'other_sadar', districtId: 'other', name: 'Sadar Thana', nameBn: 'সদর উপজেলা / থানা', deliveryFee: 120 },
  { id: 'other_upazila', districtId: 'other', name: 'Other Upazila', nameBn: 'অন্যান্য উপজেলা', deliveryFee: 120 },
];

export const POPULAR_VILLAGES: Record<string, string[]> = {
  parbatipur: [
    'মনমথপুর চাকলা বাজার',
    'ভবের বাজার বট গাছ',
    'অন্তরের বাজার',
    'সাবিলুস সালাম মাদ্রাসা',
    'যশাইর মোড়',
    'বানিয়া পাড়া',
    'মিশন বাজার',
    'তাজনগর ডাঙ্গাপাড়া মাদ্রাসা',
    'জামতলী স্কুল',
    'মনমথপুর স্টেশন',
    'নতুন বাজার',
    'পার্বতীপুর রেলওয়ে স্টেশন মোড়',
    'খোলাহাটি বাজার / ক্যান্টনমেন্ট',
    'হাবড়া বাজার',
    'ভবানীপুর',
    'বেলাইচণ্ডী',
    'রামপুর',
    'অন্যান্য গ্রাম / বাজার (নিচে লিখুন)',
  ],
  chirirbandar: [
    'সিমলতলী বাজার',
    'আমতলী',
    'বেলতলী বাজার আব্দুর রহমান হোটেল',
    'মাহমুদপুর রসুলপুর হামিদিয়া মাদরাসা',
    'সুখীকিপির বাজার',
    'হাজির মোড়',
    'ঘুঘিরাতলী বট গাছ',
    'চিরিরবন্দর স্টেশন মসজিদ',
    'রাণীরবন্দর বাজার',
    'বিন্যাকুড়ি বাজার',
    'অন্যান্য গ্রাম / বাজার (নিচে লিখুন)',
  ],
};
