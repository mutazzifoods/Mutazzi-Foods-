import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  updateDoc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { Order } from '../types';

const firebaseConfig = {
  apiKey: "AIzaSyAqcS_ejUVQOHtwslHIde2Yztgil208TrQ",
  authDomain: "furqanblogbd.firebaseapp.com",
  databaseURL: "https://furqanblogbd-default-rtdb.firebaseio.com",
  projectId: "furqanblogbd",
  storageBucket: "furqanblogbd.firebasestorage.app",
  messagingSenderId: "1042195955052",
  appId: "1:1042195955052:web:5d58dafa11dcf457734749",
};

// Initialize Firebase safely
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

/**
 * Sign in with Google Popup
 */
export async function loginWithGoogle(): Promise<User> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error: any) {
    console.error('Google Sign-In Error:', error);
    let msg = error.message || 'Login failed';
    if (error.code === 'auth/popup-blocked') {
      msg = 'পপ-আপ উইন্ডোটি ব্লক করা হয়েছে। দয়া করে ব্রাউজারের পপ-আপ অনুমোদন করুন।';
    } else if (error.code === 'auth/unauthorized-domain') {
      msg = 'এই ডোমেইনটি ফায়ারবেসে অনুমোদিত নয়। Firebase Console > Authentication-এ ডোমেইনটি যুক্ত করতে হবে।';
    } else if (error.code === 'auth/cancelled-popup-request') {
      msg = 'লগইন রিকোয়েস্ট বাতিল করা হয়েছে।';
    }
    throw new Error(msg);
  }
}

/**
 * Log out current user
 */
export async function logoutUser(): Promise<void> {
  await signOut(auth);
}

/**
 * Convert raw Firestore doc to Order object
 */
function docToOrder(data: any, docId: string): Order {
  return {
    id: data.id || docId,
    date: data.date || new Date().toISOString(),
    customerName: data.customerName || 'সম্মানিত ক্রেতা',
    phone: data.phone || '',
    address: data.address || '',
    deliveryZone: data.deliveryZone || 'Parbatipur',
    items: data.items || [],
    subtotal: data.subtotal || 0,
    discount: data.discount || 0,
    deliveryFee: data.deliveryFee || 0,
    total: data.total || 0,
    paymentMethod: data.paymentMethod || 'cod',
    status: (data.status as Order['status']) || 'Confirmed',
    userId: data.userId,
    userEmail: data.userEmail,
    isGuest: Boolean(data.isGuest),
    estimatedDelivery: data.estimatedDelivery,
    cancelledAt: data.cancelledAt,
    updatedAt: data.updatedAt,
  };
}

/**
 * Save order to Firestore (with document ID equal to order.id)
 */
export async function saveOrderToFirestore(order: Order, userId?: string, userEmail?: string) {
  try {
    const orderRef = doc(db, 'orders', order.id);
    await setDoc(orderRef, {
      ...order,
      userId: userId || order.userId || 'guest',
      userEmail: userEmail || order.userEmail || 'guest@mutazzifoods.com',
      updatedAt: new Date().toISOString(),
      createdAtServer: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    // Non-blocking: local storage is primary resilient fallback
    console.warn('Firestore sync note:', err);
  }
}

/**
 * Update order status in Firestore (Admin action)
 */
export async function updateOrderStatusInFirestore(orderId: string, status: Order['status']) {
  try {
    const orderRef = doc(db, 'orders', orderId);
    await updateDoc(orderRef, {
      status,
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('Firestore status update note:', err);
  }
}

/**
 * Fetch all orders from Firestore (for Admin)
 */
export async function fetchAllOrdersFromFirestore(): Promise<Order[]> {
  try {
    const ordersCol = collection(db, 'orders');
    const snapshot = await getDocs(ordersCol);
    const orders: Order[] = [];
    snapshot.forEach((docSnap) => {
      orders.push(docToOrder(docSnap.data(), docSnap.id));
    });
    // Sort descending by date
    orders.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    return orders;
  } catch (err) {
    console.warn('Could not fetch all orders from Firestore:', err);
    return [];
  }
}

/**
 * Subscribe to all orders in real-time (for Admin live updates)
 */
export function subscribeToAllOrders(callback: (orders: Order[]) => void): () => void {
  try {
    const ordersCol = collection(db, 'orders');
    const unsubscribe = onSnapshot(ordersCol, (snapshot) => {
      const orders: Order[] = [];
      snapshot.forEach((docSnap) => {
        orders.push(docToOrder(docSnap.data(), docSnap.id));
      });
      orders.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      callback(orders);
    }, (error) => {
      console.warn('Orders subscription note:', error);
    });
    return unsubscribe;
  } catch (err) {
    console.warn('Subscription setup error:', err);
    return () => {};
  }
}

/**
 * Fetch orders for a user from Firestore
 */
export async function fetchUserOrdersFromFirestore(userId: string, email?: string): Promise<Order[]> {
  try {
    if (!userId || userId === 'guest') return [];
    const ordersCol = collection(db, 'orders');
    const q = query(ordersCol, where('userId', '==', userId));
    const snapshot = await getDocs(q);
    const orders: Order[] = [];
    snapshot.forEach((docSnap) => {
      orders.push(docToOrder(docSnap.data(), docSnap.id));
    });
    orders.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    return orders;
  } catch (err) {
    console.warn('Could not fetch user orders from Firestore:', err);
    return [];
  }
}
