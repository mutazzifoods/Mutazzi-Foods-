import React, { useState, useEffect, useMemo } from 'react';
import { Product, CartItem, Order } from './types';
import { PRODUCTS, CATEGORIES } from './data/products';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { OrdersModal } from './components/OrdersModal';
import { MacroCalculator } from './components/MacroCalculator';
import { BrandStory } from './components/BrandStory';
import { Footer } from './components/Footer';
import { AdminModal, AppSettings } from './components/AdminModal';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { Dumbbell, ShieldCheck, Truck, Sparkles, Filter, CheckCircle2, ShoppingBag, X, Heart } from 'lucide-react';
import { 
  auth, 
  loginWithGoogle, 
  logoutUser, 
  saveOrderToFirestore, 
  fetchUserOrdersFromFirestore, 
  updateOrderStatusInFirestore, 
  subscribeToAllOrders 
} from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';

export default function App() {
  const [lang, setLang] = useState<'bn' | 'en'>('bn');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);

  // Dynamic products list (Admin editable, persisted in localStorage with PRODUCTS fallback)
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('mutazzi_products');
      return saved ? JSON.parse(saved) : PRODUCTS;
    } catch {
      return PRODUCTS;
    }
  });

  // App settings for delivery fees, free delivery threshold, and bundle discounts
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('mutazzi_settings');
      return saved ? JSON.parse(saved) : {
        parbatipurDelivery: 100,
        outsideDelivery: 120,
        freeDeliveryThreshold: 1500,
        bundleDiscountPct: 10,
        bannerNoticeBn: 'পার্বতীপুরে হোম ডেলিভারি মাত্র ১০০ টাকা · ১৫০০ টাকার অর্ডারে ফ্রি ডেলিভারি!',
        bannerNoticeEn: 'Parbatipur delivery ৳100 · FREE delivery on orders over ৳1500!'
      };
    } catch {
      return {
        parbatipurDelivery: 100,
        outsideDelivery: 120,
        freeDeliveryThreshold: 1500,
        bundleDiscountPct: 10,
        bannerNoticeBn: 'পার্বতীপুরে হোম ডেলিভারি মাত্র ১০০ টাকা · ১৫০০ টাকার অর্ডারে ফ্রি ডেলিভারি!',
        bannerNoticeEn: 'Parbatipur delivery ৳100 · FREE delivery on orders over ৳1500!'
      };
    }
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('mutazzi_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('mutazzi_orders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('mutazzi_favorites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [sortBy, setSortBy] = useState<'featured' | 'protein' | 'price-asc' | 'price-desc'>('featured');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [lastCompletedOrder, setLastCompletedOrder] = useState<Order | null>(null);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Admin access validation - specifically for mdlabiburrahman26@gmail.com
  const isAdmin = useMemo(() => {
    if (!currentUser?.email) return false;
    return currentUser.email.toLowerCase().trim() === 'mdlabiburrahman26@gmail.com';
  }, [currentUser]);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const cloudOrders = await fetchUserOrdersFromFirestore(user.uid, user.email || undefined);
          if (cloudOrders.length > 0) {
            setOrders((prev) => {
              const map = new Map<string, Order>();
              cloudOrders.forEach((o) => map.set(o.id, o));
              prev.forEach((o) => map.set(o.id, o));
              return Array.from(map.values());
            });
          }
        } catch (e) {
          console.warn('Orders sync info:', e);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Live real-time subscription to orders in Firestore
  useEffect(() => {
    const unsubscribe = subscribeToAllOrders((liveOrders) => {
      if (liveOrders && liveOrders.length > 0) {
        setOrders((prev) => {
          const map = new Map<string, Order>();
          prev.forEach((o) => map.set(o.id, o));
          liveOrders.forEach((o) => map.set(o.id, o));
          const list = Array.from(map.values());
          list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
          return list;
        });
      }
    });

    return () => unsubscribe();
  }, []);

  // Sync cart to localStorage
  useEffect(() => {
    localStorage.setItem('mutazzi_cart', JSON.stringify(cart));
  }, [cart]);

  // Sync orders to localStorage
  useEffect(() => {
    localStorage.setItem('mutazzi_orders', JSON.stringify(orders));
  }, [orders]);

  // Sync favorites to localStorage
  useEffect(() => {
    localStorage.setItem('mutazzi_favorites', JSON.stringify(favorites));
  }, [favorites]);

  // Sync admin products to localStorage
  useEffect(() => {
    localStorage.setItem('mutazzi_products', JSON.stringify(products));
  }, [products]);

  // Sync admin settings to localStorage
  useEffect(() => {
    localStorage.setItem('mutazzi_settings', JSON.stringify(settings));
  }, [settings]);

  const handleToggleFavorite = (productId: string) => {
    setFavorites((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
    const prod = products.find((p) => p.id === productId);
    const isNowFav = !favorites.includes(productId);
    showNotification(
      isNowFav
        ? (lang === 'bn' ? `"${prod?.nameBn || 'খাবার'}" পছন্দের তালিকায় যুক্ত হয়েছে!` : `Added to favorites!`)
        : (lang === 'bn' ? `"${prod?.nameBn || 'খাবার'}" পছন্দ তালিকা থেকে সরানো হয়েছে।` : `Removed from favorites.`)
    );
  };

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 3500);
  };

  // Product CRUD Handlers (Admin Panel)
  const handleAddProduct = (newProd: Product) => {
    setProducts((prev) => [newProd, ...prev]);
    showNotification(
      lang === 'bn' ? 'নতুন খাবার সফলভাবে মেনুতে যুক্ত হয়েছে!' : 'New meal added to menu!'
    );
  };

  const handleUpdateProduct = (updatedProd: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updatedProd.id ? updatedProd : p)));
    if (selectedProduct?.id === updatedProd.id) {
      setSelectedProduct(updatedProd);
    }
    showNotification(
      lang === 'bn' ? 'খাবারের তথ্য সফলভাবে আপডেট হয়েছে!' : 'Meal updated successfully!'
    );
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    if (selectedProduct?.id === productId) {
      setSelectedProduct(null);
    }
    showNotification(
      lang === 'bn' ? 'খাবারটি মেনু থেকে ডিলিট করা হয়েছে।' : 'Meal removed from menu.'
    );
  };

  const handleResetProducts = () => {
    setProducts(PRODUCTS);
    localStorage.setItem('mutazzi_products', JSON.stringify(PRODUCTS));
    showNotification(
      lang === 'bn' ? 'ডিফল্ট খাবার তালিকা সফলভাবে রিস্টোর হয়েছে।' : 'Default meals restored.'
    );
  };

  const handleUpdateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    showNotification(
      lang === 'bn' ? 'ডেলিভারি চার্জ ও ডিসকাউন্ট সেটিংস আপডেট হয়েছে!' : 'Delivery settings updated!'
    );
  };

  const handleLoginWithGoogle = async () => {
    try {
      setIsAuthLoading(true);
      const user = await loginWithGoogle();
      showNotification(
        lang === 'bn'
          ? `স্বাগতম, ${user.displayName || user.email}! গুগল অ্যাকাউন্ট সফলভাবে যুক্ত হয়েছে।`
          : `Welcome, ${user.displayName || user.email}! Google account connected.`
      );
    } catch (err: any) {
      showNotification(err.message || 'Login error occurred');
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
      showNotification(
        lang === 'bn' ? 'সফলভাবে লগআউট করা হয়েছে।' : 'Logged out successfully.'
      );
    } catch (err: any) {
      console.error(err);
    }
  };

  const handleAddToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { ...product, quantity }];
    });

    showNotification(
      lang === 'bn'
        ? `"${product.nameBn}" কার্টে যোগ করা হয়েছে!`
        : `Added "${product.name}" to cart!`
    );
  };

  const handleAddBundleToCart = (productsToAdd: Product[]) => {
    setCart((prev) => {
      let newCart = [...prev];
      productsToAdd.forEach((prod) => {
        const idx = newCart.findIndex((item) => item.id === prod.id);
        if (idx >= 0) {
          newCart[idx] = { ...newCart[idx], quantity: newCart[idx].quantity + 1 };
        } else {
          newCart.push({ ...prod, quantity: 1 });
        }
      });
      return newCart;
    });

    showNotification(
      lang === 'bn'
        ? 'মুতাযযি হাই-প্রোটিন কম্বো কার্টে যোগ করা হয়েছে!'
        : 'Mutazzi Power Pack added to cart!'
    );
  };

  const handleUpdateQty = (productId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleOrderSuccess = async (newOrder: Order) => {
    // Save to local state (and automatically to localStorage via useEffect)
    setOrders((prev) => [newOrder, ...prev]);
    setLastCompletedOrder(newOrder);
    setIsSuccessModalOpen(true);

    // Save to Firestore in background
    await saveOrderToFirestore(newOrder, currentUser?.uid, currentUser?.email || undefined);

    showNotification(
      lang === 'bn'
        ? `ধন্যবাদ! অর্ডার #${newOrder.id} সফলভাবে গ্রহণ করা হয়েছে!`
        : `Thank you! Order #${newOrder.id} placed successfully!`
    );
  };

  const handleCancelOrder = async (orderId: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? { ...o, status: 'Cancelled' as const, cancelledAt: new Date().toISOString() }
          : o
      )
    );
    showNotification(
      lang === 'bn'
        ? `অর্ডার #${orderId} সফলভাবে বাতিল করা হয়েছে।`
        : `Order #${orderId} has been cancelled.`
    );
    await updateOrderStatusInFirestore(orderId, 'Cancelled');
  };

  const handleUpdateOrderStatus = async (orderId: string, status: Order['status']) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? { ...o, status, updatedAt: new Date().toISOString() }
          : o
      )
    );
    await updateOrderStatusInFirestore(orderId, status);
  };

  // Filtered & Sorted Products from dynamic Admin-managed products list
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesCategory =
        activeCategory === 'all'
          ? true
          : activeCategory === 'favorites'
          ? favorites.includes(p.id)
          : p.category === activeCategory;
      const q = searchTerm.toLowerCase().trim();
      const matchesSearch =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.nameBn.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.descriptionBn.toLowerCase().includes(q) ||
        p.categoryLabel.toLowerCase().includes(q);

      return matchesCategory && matchesSearch;
    }).sort((a, b) => {
      if (sortBy === 'protein') return b.protein - a.protein;
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      return 0; // featured default
    });
  }, [products, activeCategory, searchTerm, sortBy, favorites]);

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-[#2D160C] overflow-x-hidden w-full max-w-full pb-20 md:pb-0">
      
      {/* Toast Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#2D160C] text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 border border-white/10 animate-in slide-in-from-bottom duration-200 text-xs sm:text-sm font-semibold max-w-sm">
          <CheckCircle2 className="w-5 h-5 text-[#16A34A] shrink-0" />
          <span className="flex-1">{notification}</span>
          <button onClick={() => setNotification(null)} className="text-white/60 hover:text-white p-0.5">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Bar Navigation */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenOrders={() => setIsOrdersOpen(true)}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        lang={lang}
        onToggleLang={() => setLang(lang === 'bn' ? 'en' : 'bn')}
        ordersCount={orders.length}
        currentUser={currentUser}
        onLoginWithGoogle={handleLoginWithGoogle}
        onLogout={handleLogout}
        isAuthLoading={isAuthLoading}
        favoritesCount={favorites.length}
        onOpenFavorites={() => {
          setActiveCategory('favorites');
          const menuElem = document.getElementById('menu');
          menuElem?.scrollIntoView({ behavior: 'smooth' });
        }}
        isAdmin={isAdmin}
        onOpenAdmin={() => setIsAdminOpen(true)}
        settings={settings}
      />

      {/* Hero Section */}
      <Hero
        lang={lang}
        onExploreClick={() => {
          const menuElem = document.getElementById('menu');
          menuElem?.scrollIntoView({ behavior: 'smooth' });
        }}
        onCalculatorClick={() => {
          const calcElem = document.getElementById('calculator');
          calcElem?.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* Key Brand Pillars Strip (Responsive CSS Grid) */}
      <section className="border-y border-[#EAE4D9] bg-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#EA580C]/10 flex items-center justify-center text-[#EA580C] shrink-0">
                <Dumbbell className="w-5 h-5" />
              </div>
              <div>
                <div className="font-heading font-bold text-xs sm:text-sm text-[#2D160C]">
                  {lang === 'bn' ? 'হাই-প্রোটিন ফর্মুলা' : 'High-Protein Fuel'}
                </div>
                <div className="text-[11px] text-[#786154]">
                  {lang === 'bn' ? 'গড়ে ২৮-৪২ গ্রাম প্রোটিন' : '28-42g Protein / meal'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#16A34A]/10 flex items-center justify-center text-[#16A34A] shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="font-heading font-bold text-xs sm:text-sm text-[#2D160C]">
                  {lang === 'bn' ? '১০০% বিশুদ্ধ অর্গানিক' : '100% Pure Organic'}
                </div>
                <div className="text-[11px] text-[#786154]">
                  {lang === 'bn' ? 'প্রিজারভেটিভ ও কেমিক্যাল মুক্ত' : 'No refined sugars or palm oil'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#D97706]/10 flex items-center justify-center text-[#D97706] shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="font-heading font-bold text-xs sm:text-sm text-[#2D160C]">
                  {lang === 'bn' ? 'শেফ-প্রস্তুতকৃত খাদ্য' : 'Chef-Crafted Daily'}
                </div>
                <div className="text-[11px] text-[#786154]">
                  {lang === 'bn' ? 'প্রতিদিন তাজা প্রস্তুত' : 'Freshly cooked & packaged'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#2D160C]/10 flex items-center justify-center text-[#2D160C] shrink-0">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <div className="font-heading font-bold text-xs sm:text-sm text-[#2D160C]">
                  {lang === 'bn' ? 'দ্রুত হোম ডেলিভারি' : 'Express Delivery'}
                </div>
                <div className="text-[11px] text-[#786154]">
                  {lang === 'bn' ? 'পার্বতীপুর ১০০৳ · বাইরে ১২০৳ (১৫০০৳+ ফ্রি)' : 'Parbatipur ৳100 · Outside ৳120 (Free 1500৳+)'}
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Main Catalog & Menu Section */}
      <section id="menu" className="py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#EAE4D9] pb-6">
            <div>
              <div className="text-xs font-bold text-[#EA580C] uppercase tracking-wider">
                {lang === 'bn' ? 'মুতাযযি ফুডস মেনু' : 'Mutazzi Power Menu'}
              </div>
              <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-[#2D160C] mt-1">
                {lang === 'bn' ? 'ফিটনেস ও সুস্থতার জন্য বাছাইকৃত খাদ্য' : 'Fuel for Strength & Clean Living'}
              </h2>
            </div>

            {/* Sorting Dropdown */}
            <div className="flex items-center gap-2 self-start md:self-auto">
              <span className="text-xs text-[#786154] font-medium flex items-center gap-1">
                <Filter className="w-3.5 h-3.5" />
                {lang === 'bn' ? 'সর্ট করুন:' : 'Sort:'}
              </span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-white border border-[#D5C9B8] rounded-lg text-xs font-semibold text-[#2D160C] py-1.5 px-2.5 focus:outline-none focus:border-[#EA580C] cursor-pointer"
              >
                <option value="featured">{lang === 'bn' ? 'জনপ্রিয় (Featured)' : 'Featured'}</option>
                <option value="protein">{lang === 'bn' ? 'সর্বোচ্চ প্রোটিন (Highest Protein)' : 'Highest Protein'}</option>
                <option value="price-asc">{lang === 'bn' ? 'মূল্য: কম থেকে বেশি' : 'Price: Low to High'}</option>
                <option value="price-desc">{lang === 'bn' ? 'মূল্য: বেশি থেকে কম' : 'Price: High to Low'}</option>
              </select>
            </div>
          </div>

          {/* Interactive Category Filter Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-[#2D160C] text-white shadow-md'
                    : 'bg-white text-[#5C4537] border border-[#EAE4D9] hover:bg-[#F2ECE1] hover:text-[#2D160C]'
                }`}
              >
                {lang === 'bn' ? cat.labelBn : cat.label}
              </button>
            ))}

            {/* My Favorites Tab */}
            <button
              onClick={() => setActiveCategory('favorites')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                activeCategory === 'favorites'
                  ? 'bg-[#DC2626] text-white shadow-md'
                  : 'bg-white text-[#5C4537] border border-[#EAE4D9] hover:bg-red-50 hover:text-[#DC2626]'
              }`}
            >
              <Heart className={`w-3.5 h-3.5 ${activeCategory === 'favorites' || favorites.length > 0 ? 'fill-current' : ''}`} />
              <span>{lang === 'bn' ? 'আমার পছন্দ' : 'My Favorites'}</span>
              {favorites.length > 0 && (
                <span
                  className={`text-xs px-1.5 py-0.2 rounded-full font-bold ${
                    activeCategory === 'favorites' ? 'bg-white text-[#DC2626]' : 'bg-red-100 text-[#DC2626]'
                  }`}
                >
                  {favorites.length}
                </span>
              )}
            </button>
          </div>

          {/* Search Term Notice if searching */}
          {searchTerm && (
            <div className="flex items-center justify-between bg-white px-4 py-2.5 rounded-xl border border-[#EAE4D9] text-xs">
              <span>
                {lang === 'bn' ? 'অনুসন্ধান ফলাফল:' : 'Search results for:'}{' '}
                <strong className="text-[#EA580C]">"{searchTerm}"</strong> ({filteredProducts.length}টি পণ্য)
              </span>
              <button
                onClick={() => setSearchTerm('')}
                className="text-xs text-[#786154] hover:text-[#EA580C] font-semibold cursor-pointer underline"
              >
                {lang === 'bn' ? 'ক্লিয়ার করুন' : 'Clear search'}
              </button>
            </div>
          )}

          {/* Products Grid: Responsive CSS Grid */}
          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-2xl border border-[#EAE4D9] p-10 sm:p-14 text-center space-y-3">
              {activeCategory === 'favorites' ? (
                <>
                  <div className="w-12 h-12 rounded-full bg-red-50 text-[#DC2626] mx-auto flex items-center justify-center">
                    <Heart className="w-6 h-6" />
                  </div>
                  <div className="font-heading font-bold text-lg text-[#2D160C]">
                    {lang === 'bn' ? 'পছন্দের তালিকায় কোনো খাদ্য নেই' : 'No Favorite Foods Yet'}
                  </div>
                  <p className="text-xs text-[#786154] max-w-sm mx-auto">
                    {lang === 'bn'
                      ? 'যেকোনো খাবারের ছবির উপরের ❤️ আইকনে ক্লিক করে সহজেই আপনার ব্যক্তিগত পছন্দের তালিকায় সংরক্ষণ করুন।'
                      : 'Click the ❤️ heart icon on any meal image to save it to your personal favorites.'}
                  </p>
                  <button
                    onClick={() => {
                      setActiveCategory('all');
                      setSearchTerm('');
                    }}
                    className="bg-[#EA580C] text-white text-xs font-bold px-4 py-2 rounded-lg cursor-pointer transition-all active:scale-95"
                  >
                    {lang === 'bn' ? 'সকল খাবার দেখুন' : 'Explore All Foods'}
                  </button>
                </>
              ) : (
                <>
                  <div className="font-heading font-bold text-lg text-[#2D160C]">
                    {lang === 'bn' ? 'কোনো পণ্য পাওয়া যায়নি' : 'No foods found matching criteria'}
                  </div>
                  <p className="text-xs text-[#786154]">
                    {lang === 'bn'
                      ? 'অনুগ্রহ করে ভিন্ন কোনো ক্যাটেগরি নির্বাচন করুন অথবা অনুসন্ধান শব্দ পরিবর্তন করুন।'
                      : 'Try adjusting your search keywords or switching category filters.'}
                  </p>
                  <button
                    onClick={() => {
                      setActiveCategory('all');
                      setSearchTerm('');
                    }}
                    className="bg-[#EA580C] text-white text-xs font-bold px-4 py-2 rounded-lg cursor-pointer"
                  >
                    {lang === 'bn' ? 'সকল পণ্য দেখুন' : 'View All Foods'}
                  </button>
                </>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={(p) => handleAddToCart(p, 1)}
                  onViewDetails={(p) => setSelectedProduct(p)}
                  lang={lang}
                  isFavorite={favorites.includes(product.id)}
                  onToggleFavorite={handleToggleFavorite}
                />
              ))}
            </div>
          )}

        </div>
      </section>

      {/* Interactive Macro Calculator Tool */}
      <MacroCalculator
        products={products}
        onAddBundleToCart={handleAddBundleToCart}
        lang={lang}
      />

      {/* Brand Story & Logo Philosophy Section */}
      <BrandStory lang={lang} />

      {/* Footer */}
      <Footer lang={lang} />

      {/* Product Details Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        lang={lang}
        currentUser={currentUser}
        orders={orders}
        onLoginWithGoogle={handleLoginWithGoogle}
        isFavorite={selectedProduct ? favorites.includes(selectedProduct.id) : false}
        onToggleFavorite={handleToggleFavorite}
      />

      {/* Slide-over Cart & Checkout Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onOrderSuccess={handleOrderSuccess}
        lang={lang}
        currentUser={currentUser}
        onLoginWithGoogle={handleLoginWithGoogle}
        settings={settings}
      />

      {/* Order History Modal */}
      <OrdersModal
        isOpen={isOrdersOpen}
        onClose={() => setIsOrdersOpen(false)}
        orders={orders}
        lang={lang}
        currentUser={currentUser}
        onLoginWithGoogle={handleLoginWithGoogle}
        onCancelOrder={handleCancelOrder}
      />

      {/* Order Success / Thank You Modal with Official Mutazzi Foods Logo */}
      {isSuccessModalOpen && (
        <OrderSuccessModal
          order={lastCompletedOrder}
          onClose={() => setIsSuccessModalOpen(false)}
          onViewOrders={() => {
            setIsSuccessModalOpen(false);
            setIsOrdersOpen(true);
          }}
          lang={lang}
        />
      )}

      {/* Super Admin Control Panel (restricted to mdlabiburrahman26@gmail.com) */}
      <AdminModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        products={products}
        onAddProduct={handleAddProduct}
        onUpdateProduct={handleUpdateProduct}
        onDeleteProduct={handleDeleteProduct}
        onResetProducts={handleResetProducts}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        orders={orders}
        onUpdateOrderStatus={handleUpdateOrderStatus}
        lang={lang}
      />

      {/* Mobile Bottom Sticky Quick Action Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#EAE4D9] p-3 flex items-center justify-between gap-3 shadow-lg">
        <button
          onClick={() => {
            const menuElem = document.getElementById('menu');
            menuElem?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="flex-1 bg-[#FAF8F5] border border-[#D5C9B8] py-2 px-3 rounded-xl text-xs font-bold text-[#2D160C] text-center"
        >
          {lang === 'bn' ? 'মেনু ব্রাউজ' : 'Explore Menu'}
        </button>

        <button
          onClick={() => setIsCartOpen(true)}
          className="flex-1 bg-[#EA580C] text-white py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>{lang === 'bn' ? 'কার্ট' : 'Cart'}</span>
          <span className="bg-white text-[#EA580C] px-1.5 py-0.2 rounded-full font-black text-[10px]">
            {totalCartCount}
          </span>
        </button>
      </div>

    </div>
  );
}
